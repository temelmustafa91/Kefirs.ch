import { createFileRoute } from "@tanstack/react-router";
import { Storefront } from "@/components/store/storefront";
import { getStorefront } from "@/lib/comptoir/api";

export const Route = createFileRoute("/")({
  loader: () => getStorefront(),
  pendingComponent: PendingHome,
  component: Home,
  head: () => ({ meta: [{ title: "Comptoir — commander" }] }),
});

function Home() {
  const data = Route.useLoaderData();
  return <Storefront data={data} />;
}

function PendingHome() {
  return (
    <main className="mx-auto max-w-5xl px-4 py-10">
      <p className="text-sm tracking-widest text-muted-foreground">COMPTOIR</p>
      <h1 className="mt-3 font-display text-4xl tracking-tight">La carte se prépare</h1>
    </main>
  );
}
