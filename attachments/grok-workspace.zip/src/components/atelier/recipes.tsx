import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input, Label, Select, Textarea } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { deleteRecipe, moveRecipe, saveRecipe } from "@/lib/comptoir/api";
import { DISH_KEYS, dishSrc, eurosInput, formatEUR, parseEuros } from "@/lib/comptoir/format";
import type { Recipe } from "@/lib/comptoir/types";
import { cn } from "@/lib/utils";
import { SectionTitle, type DeskProps } from "@/components/atelier/bits";

type LineDraft = { stockItemId: number; quantity: string };
type Draft = {
  id: number | null;
  name: string;
  description: string;
  category: string;
  price: string;
  prepMinutes: string;
  published: boolean;
  image: string;
  lines: LineDraft[];
};

export function RecipesView({ data, pin, busy, run }: DeskProps) {
  const [draft, setDraft] = useState<Draft | null>(null);
  const paid = data.series.reduce((sum, point) => sum + point.paidCents, 0);
  const booked = data.series.reduce((sum, point) => sum + point.bookedCents, 0);

  function openRecipe(recipe?: Recipe) {
    const first = data.stock[0]?.id ?? 0;
    setDraft(
      recipe
        ? {
            id: recipe.id,
            name: recipe.name,
            description: recipe.description,
            category: recipe.category,
            price: eurosInput(recipe.priceCents),
            prepMinutes: String(recipe.prepMinutes),
            published: recipe.published,
            image: recipe.image,
            lines: recipe.lines.map((line) => ({ stockItemId: line.stockItemId, quantity: String(line.quantity) })),
          }
        : {
            id: null,
            name: "",
            description: "",
            category: "Plat",
            price: "",
            prepMinutes: "15",
            published: true,
            image: "",
            lines: first ? [{ stockItemId: first, quantity: "1" }] : [],
          },
    );
  }

  async function save() {
    if (!draft) return;
    const priceCents = parseEuros(draft.price);
    const prepMinutes = Number(draft.prepMinutes);
    if (priceCents == null) {
      toast.error("Prix invalide.");
      return;
    }
    if (!Number.isInteger(prepMinutes) || prepMinutes < 0) {
      toast.error("Temps de préparation invalide.");
      return;
    }
    const lines = draft.lines.map((line) => ({ stockItemId: line.stockItemId, quantity: Number(line.quantity) }));
    if (lines.some((line) => !Number.isInteger(line.quantity) || line.quantity < 1)) {
      toast.error("Quantité d'ingrédient invalide.");
      return;
    }
    try {
      const ok = await run(() =>
        saveRecipe({
          data: {
            pin,
            id: draft.id,
            name: draft.name,
            description: draft.description,
            category: draft.category,
            priceCents,
            prepMinutes,
            published: draft.published,
            image: draft.image,
            lines,
          },
        }),
      );
      if (!ok) return;
      setDraft(null);
      toast.success("Recette enregistrée");
    } catch {
      /* toasted */
    }
  }

  return (
    <div className="space-y-8">
      <section className="lift rounded-3xl bg-card p-4">
        <h2 className="font-display text-2xl tracking-tight">Recettes encaissées</h2>
        <p className="mt-2 text-sm text-muted-foreground">Sur 7 jours, commandes retirées. L'engagé inclut ce qui n'est pas encore passé au comptoir.</p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <p>
            <span className="block text-sm text-muted-foreground">Encaissé</span>
            <span className="font-display text-3xl tabular-nums">{formatEUR(paid)}</span>
          </p>
          <p>
            <span className="block text-sm text-muted-foreground">Engagé</span>
            <span className="font-display text-3xl tabular-nums">{formatEUR(booked)}</span>
          </p>
        </div>
      </section>
      <div className="flex items-end justify-between gap-3">
        <SectionTitle title="Fiches techniques" detail="Ce qui part en cuisine et à la carte" />
        <Button onClick={() => openRecipe()}>Ajouter</Button>
      </div>
      <ul className="space-y-3">
        {data.recipes.map((recipe, index) => {
          const src = dishSrc(recipe.image);
          return (
            <li key={recipe.id} className="lift flex gap-3 rounded-3xl bg-card p-3">
              {src ? (
                <img src={src} alt="" className="h-20 w-24 shrink-0 rounded-xl object-cover" />
              ) : (
                <div className="grid h-20 w-24 shrink-0 place-items-center rounded-xl bg-secondary text-sm text-muted-foreground">
                  {recipe.category}
                </div>
              )}
              <div className="min-w-0 flex-1">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-display text-xl">{recipe.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {recipe.category} · {formatEUR(recipe.priceCents)} · {recipe.published ? "À la carte" : "Masquée"}
                    </p>
                  </div>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">
                  {recipe.lines.length
                    ? recipe.lines.map((line) => `${line.quantity} ${line.unit} ${line.name}`).join(" · ")
                    : "Sans ingrédient lié"}
                </p>
                <div className="mt-2 flex flex-wrap gap-2">
                  <Button variant="ghost" onClick={() => openRecipe(recipe)}>
                    Modifier
                  </Button>
                  <Button
                    variant="ghost"
                    disabled={busy || index === 0}
                    onClick={() => void run(() => moveRecipe({ data: { pin, id: recipe.id, direction: -1 } }))}
                  >
                    Monter
                  </Button>
                  <Button
                    variant="ghost"
                    disabled={busy || index === data.recipes.length - 1}
                    onClick={() => void run(() => moveRecipe({ data: { pin, id: recipe.id, direction: 1 } }))}
                  >
                    Descendre
                  </Button>
                  <Button variant="ghost" disabled={busy} onClick={() => void run(() => deleteRecipe({ data: { pin, id: recipe.id } }))}>
                    Retirer
                  </Button>
                </div>
              </div>
            </li>
          );
        })}
      </ul>
      <Modal open={draft != null} onOpenChange={(next) => !next && setDraft(null)} title={draft?.id ? "Recette" : "Nouvelle recette"}>
        {draft ? (
          <form
            className="space-y-3"
            onSubmit={(event) => {
              event.preventDefault();
              void save();
            }}
          >
            <div>
              <Label htmlFor="recipe-name">Nom</Label>
              <Input id="recipe-name" className="mt-1" value={draft.name} onChange={(event) => setDraft({ ...draft, name: event.target.value })} />
            </div>
            <div>
              <Label htmlFor="recipe-category">Catégorie</Label>
              <Input id="recipe-category" className="mt-1" list="recipe-categories" value={draft.category} onChange={(event) => setDraft({ ...draft, category: event.target.value })} />
              <datalist id="recipe-categories">
                {["Entrée", "Soupe", "Tarte", "Plat", "Cake", "Dessert"].map((category) => (
                  <option key={category} value={category} />
                ))}
              </datalist>
            </div>
            <div>
              <Label htmlFor="recipe-description">Description</Label>
              <Textarea id="recipe-description" className="mt-1" value={draft.description} onChange={(event) => setDraft({ ...draft, description: event.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="recipe-price">Prix (€)</Label>
                <Input id="recipe-price" className="mt-1" inputMode="decimal" value={draft.price} onChange={(event) => setDraft({ ...draft, price: event.target.value })} />
              </div>
              <div>
                <Label htmlFor="recipe-prep">Préparation (min)</Label>
                <Input id="recipe-prep" className="mt-1" inputMode="numeric" value={draft.prepMinutes} onChange={(event) => setDraft({ ...draft, prepMinutes: event.target.value })} />
              </div>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={draft.published}
              onClick={() => setDraft({ ...draft, published: !draft.published })}
              className={cn("h-11 rounded-lg px-4 text-sm", draft.published ? "bg-primary text-primary-foreground" : "bg-secondary")}
            >
              {draft.published ? "À la carte" : "Masquée"}
            </button>
            <div className="scroll-x flex gap-2">
              <button
                type="button"
                onClick={() => setDraft({ ...draft, image: "" })}
                className={cn("h-16 shrink-0 rounded-lg px-3 text-sm", draft.image === "" ? "bg-primary text-primary-foreground" : "bg-secondary")}
              >
                Sans photo
              </button>
              {DISH_KEYS.map((key) => (
                <button
                  key={key}
                  type="button"
                  aria-label={key}
                  onClick={() => setDraft({ ...draft, image: key })}
                  className={cn("h-16 w-20 shrink-0 overflow-hidden rounded-lg", draft.image === key && "ring-2 ring-ring")}
                >
                  <img src={dishSrc(key) ?? ""} alt="" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
            <div className="space-y-2">
              {draft.lines.map((line, index) => (
                <div key={index} className="flex gap-2">
                  <Select
                    aria-label="Ingrédient"
                    value={line.stockItemId}
                    onChange={(event) => {
                      const lines = draft.lines.slice();
                      lines[index] = { ...line, stockItemId: Number(event.target.value) };
                      setDraft({ ...draft, lines });
                    }}
                  >
                    {data.stock.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.name} ({item.unit})
                      </option>
                    ))}
                  </Select>
                  <Input
                    aria-label="Quantité pour une portion"
                    className="w-24"
                    inputMode="numeric"
                    value={line.quantity}
                    onChange={(event) => {
                      const lines = draft.lines.slice();
                      lines[index] = { ...line, quantity: event.target.value };
                      setDraft({ ...draft, lines });
                    }}
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    aria-label="Retirer l'ingrédient"
                    onClick={() => setDraft({ ...draft, lines: draft.lines.filter((_, lineIndex) => lineIndex !== index) })}
                  >
                    –
                  </Button>
                </div>
              ))}
              <Button
                variant="secondary"
                disabled={data.stock.length === 0}
                onClick={() =>
                  setDraft({
                    ...draft,
                    lines: [...draft.lines, { stockItemId: data.stock[0]?.id ?? 0, quantity: "1" }],
                  })
                }
              >
                Ajouter un ingrédient
              </Button>
            </div>
            <Button type="submit" className="w-full" disabled={busy}>
              Enregistrer
            </Button>
          </form>
        ) : null}
      </Modal>
    </div>
  );
}
