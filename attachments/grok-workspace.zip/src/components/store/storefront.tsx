import { useEffect, useMemo, useState } from "react";
import { useNavigate, useRouter } from "@tanstack/react-router";
import { Clock, MapPin, Minus, Plus } from "lucide-react";
import { toast } from "sonner";
import { SiteHeader } from "@/components/site-header";
import { Button } from "@/components/ui/button";
import { Modal } from "@/components/ui/modal";
import { getSlots, placeOrder } from "@/lib/comptoir/api";
import { useCart } from "@/lib/comptoir/cart";
import { NOTE_PRESETS, dishSrc, formatEUR, messageOf } from "@/lib/comptoir/format";
import type { MenuItem, SlotsData, StorefrontData } from "@/lib/comptoir/types";
import { cn } from "@/lib/utils";

export function Storefront({ data }: { data: StorefrontData }) {
  const router = useRouter();
  const navigate = useNavigate();
  const lines = useCart((state) => state.lines);
  const setQty = useCart((state) => state.setQty);
  const clear = useCart((state) => state.clear);
  const [category, setCategory] = useState("Tout");
  const [open, setOpen] = useState(false);
  const [date, setDate] = useState(data.days[0]?.date ?? "");
  const [time, setTime] = useState("");
  const [notes, setNotes] = useState<string[]>([]);
  const [slots, setSlots] = useState<SlotsData | null>(null);
  const [pending, setPending] = useState(false);
  const [nonce, setNonce] = useState(0);
  const [code, setCode] = useState("");

  useEffect(() => {
    void useCart.persist.rehydrate();
  }, []);

  useEffect(() => {
    if (!data.days.some((day) => day.date === date)) {
      setDate(data.days[0]?.date ?? "");
      setTime("");
    }
  }, [data.days, date]);

  useEffect(() => {
    if (!open || !date) return;
    let cancel = false;
    setSlots(null);
    getSlots({ data: date })
      .then((next) => {
        if (!cancel) setSlots(next);
      })
      .catch((error: unknown) => {
        if (!cancel) toast.error(messageOf(error));
      });
    return () => {
      cancel = true;
    };
  }, [open, date, nonce]);

  const categories = useMemo(() => ["Tout", ...new Set(data.menu.map((item) => item.category))], [data.menu]);
  const visible = data.menu.filter((item) => category === "Tout" || item.category === category);
  const detailed = lines
    .map((line) => {
      const item = data.menu.find((entry) => entry.id === line.recipeId);
      if (!item) return null;
      const qty = Math.min(line.qty, item.available);
      return qty > 0 ? { item, qty } : null;
    })
    .filter((line): line is { item: MenuItem; qty: number } => line != null);
  const portions = detailed.reduce((sum, line) => sum + line.qty, 0);
  const total = detailed.reduce((sum, line) => sum + line.qty * line.item.priceCents, 0);

  async function confirm() {
    if (!date || !time || detailed.length === 0) return;
    setPending(true);
    try {
      const order = await placeOrder({
        data: {
          slotDate: date,
          slotTime: time,
          notes: notes.filter((note): note is (typeof NOTE_PRESETS)[number] =>
            (NOTE_PRESETS as readonly string[]).includes(note),
          ),
          lines: detailed.map((line) => ({ recipeId: line.item.id, qty: line.qty })),
        },
      });
      clear();
      setOpen(false);
      await router.invalidate();
      await navigate({ to: "/suivi", search: { code: order.code } });
    } catch (error) {
      toast.error(messageOf(error));
      setNonce((value) => value + 1);
      await router.invalidate();
    } finally {
      setPending(false);
    }
  }

  return (
    <div className={portions > 0 ? "pb-28" : ""}>
      <SiteHeader />
      <main className="mx-auto max-w-5xl px-4 py-8">
        <p className="text-sm tracking-widest text-muted-foreground">COMPTOIR</p>
        <h1 className="mt-2 max-w-xl font-display text-4xl tracking-tight sm:text-5xl">{data.shop.name}</h1>
        <p className="mt-3 max-w-xl text-lg text-muted-foreground">{data.shop.tagline}</p>
        <p className="mt-4 flex flex-wrap gap-x-4 gap-y-2 text-sm text-muted-foreground">
          <span className="inline-flex items-center gap-2">
            <MapPin className="size-4" aria-hidden="true" />
            {data.shop.address}
          </span>
          <span className="inline-flex items-center gap-2">
            <Clock className="size-4" aria-hidden="true" />
            {data.shop.hoursLabel}
          </span>
        </p>
        {data.shop.announcement ? (
          <p className="mt-6 max-w-xl border-l-2 border-foreground pl-4">{data.shop.announcement}</p>
        ) : null}

        <div className="scroll-x mt-8 flex gap-2">
          {categories.map((entry) => (
            <button
              key={entry}
              type="button"
              onClick={() => setCategory(entry)}
              className={cn(
                "h-11 shrink-0 rounded-full px-4 text-sm font-medium",
                category === entry ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground",
              )}
            >
              {entry}
            </button>
          ))}
        </div>

        {visible.length === 0 ? (
          <p className="mt-10 text-muted-foreground">Rien à la carte pour le moment.</p>
        ) : (
          <ul className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {visible.map((item, index) => {
              const qty = lines.find((line) => line.recipeId === item.id)?.qty ?? 0;
              const src = dishSrc(item.image);
              return (
                <li key={item.id}>
                  <article className="lift flex h-full flex-col overflow-hidden rounded-3xl bg-card">
                    {src ? (
                      <img
                        src={src}
                        alt={item.name}
                        className="aspect-[4/3] w-full object-cover"
                        loading={index < 2 ? "eager" : "lazy"}
                      />
                    ) : (
                      <div className="flex aspect-[4/3] items-end bg-secondary p-4">
                        <p className="font-display text-2xl tracking-tight">{item.name}</p>
                      </div>
                    )}
                    <div className="flex flex-1 flex-col p-4">
                      <p className="text-sm text-muted-foreground">{item.category}</p>
                      <h2 className="mt-1 font-display text-2xl tracking-tight">{item.name}</h2>
                      <p className="mt-2 flex-1 text-sm text-muted-foreground">{item.description}</p>
                      {item.available === 0 ? (
                        <p className="mt-3 text-sm text-destructive">Épuisé</p>
                      ) : item.available <= 4 ? (
                        <p className="mt-3 text-sm text-warn">Plus que {item.available}</p>
                      ) : null}
                      <div className="mt-4 flex items-center justify-between gap-3">
                        <p className="font-medium tabular-nums">{formatEUR(item.priceCents)}</p>
                        {qty > 0 ? (
                          <Stepper value={qty} max={item.available} onChange={(next) => setQty(item.id, next)} />
                        ) : (
                          <Button disabled={item.available === 0} onClick={() => setQty(item.id, 1)}>
                            Ajouter
                          </Button>
                        )}
                      </div>
                    </div>
                  </article>
                </li>
              );
            })}
          </ul>
        )}

        <form
          className="mt-16 max-w-md border-t border-border pt-8"
          onSubmit={(event) => {
            event.preventDefault();
            const next = code.trim().toUpperCase();
            if (next) void navigate({ to: "/suivi", search: { code: next } });
          }}
        >
          <h2 className="font-display text-2xl tracking-tight">Déjà commandé</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Le code reçu à la commande est le ticket de retrait. Comptoir est la seule porte.
          </p>
          <div className="mt-4 flex gap-2">
            <input
              value={code}
              onChange={(event) => setCode(event.target.value.toUpperCase())}
              placeholder="BR-1842"
              aria-label="Code de commande"
              className="h-11 min-w-0 flex-1 rounded-lg border border-border bg-card px-3 text-base uppercase outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
            <Button type="submit">Suivre</Button>
          </div>
        </form>
      </main>

      {portions > 0 ? (
        <div className="dock fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background">
          <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3">
            <div>
              <p className="text-sm text-muted-foreground">
                {portions} portion{portions > 1 ? "s" : ""}
              </p>
              <p className="font-medium tabular-nums">{formatEUR(total)}</p>
            </div>
            <Button onClick={() => setOpen(true)}>Choisir un créneau</Button>
          </div>
        </div>
      ) : null}

      <Modal
        open={open}
        onOpenChange={setOpen}
        title="Retrait"
        description="Choisissez un créneau. Aucun nom n'est demandé : le code suffit au comptoir."
      >
        <ul className="space-y-2 text-sm">
          {detailed.map((line) => (
            <li key={line.item.id} className="flex items-center justify-between gap-3">
              <span>
                {line.qty} × {line.item.name}
              </span>
              <span className="tabular-nums">{formatEUR(line.qty * line.item.priceCents)}</span>
            </li>
          ))}
        </ul>
        {data.days.length === 0 ? (
          <p className="mt-4 text-sm text-muted-foreground">Aucun créneau ouvert pour le moment.</p>
        ) : (
          <>
            <div className="scroll-x mt-4 flex gap-2">
              {data.days.map((day) => (
                <button
                  key={day.date}
                  type="button"
                  onClick={() => {
                    setDate(day.date);
                    setTime("");
                  }}
                  className={cn(
                    "h-11 shrink-0 rounded-full px-4 text-sm",
                    date === day.date ? "bg-primary text-primary-foreground" : "bg-secondary",
                  )}
                >
                  {day.label}
                </button>
              ))}
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              {slots == null ? (
                <p className="col-span-2 text-sm text-muted-foreground">Créneaux…</p>
              ) : slots.closed || slots.slots.length === 0 ? (
                <p className="col-span-2 text-sm text-muted-foreground">Plus de créneau ce jour-là.</p>
              ) : (
                slots.slots.map((slot) => (
                  <button
                    key={slot.time}
                    type="button"
                    disabled={slot.remaining <= 0}
                    onClick={() => setTime(slot.time)}
                    className={cn(
                      "flex h-11 items-center justify-between rounded-lg px-3 text-sm disabled:opacity-40",
                      time === slot.time ? "bg-primary text-primary-foreground" : "bg-secondary",
                    )}
                  >
                    <span className="tabular-nums">{slot.time}</span>
                    <span>{slot.remaining > 0 ? slot.remaining : "complet"}</span>
                  </button>
                ))
              )}
            </div>
          </>
        )}
        <div className="mt-4 flex flex-wrap gap-2">
          {NOTE_PRESETS.map((note) => {
            const active = notes.includes(note);
            return (
              <button
                key={note}
                type="button"
                aria-pressed={active}
                onClick={() => setNotes((current) => (active ? current.filter((item) => item !== note) : [...current, note]))}
                className={cn("h-11 rounded-full px-3 text-sm", active ? "bg-primary text-primary-foreground" : "bg-secondary")}
              >
                {note}
              </button>
            );
          })}
        </div>
        <div className="sticky bottom-0 -mx-4 mt-4 border-t border-border bg-background px-4 py-3">
          <Button className="w-full" disabled={pending || !time || detailed.length === 0} onClick={() => void confirm()}>
            {pending ? "Enregistrement…" : `Confirmer · ${formatEUR(total)}`}
          </Button>
        </div>
      </Modal>
    </div>
  );
}

function Stepper({ value, max, onChange }: { value: number; max: number; onChange: (qty: number) => void }) {
  return (
    <div className="flex items-center">
      <button
        type="button"
        className="grid size-11 place-items-center rounded-lg bg-secondary"
        aria-label="Retirer une portion"
        onClick={() => onChange(Math.max(0, value - 1))}
      >
        <Minus className="size-4" />
      </button>
      <span className="w-8 text-center tabular-nums">{value}</span>
      <button
        type="button"
        className="grid size-11 place-items-center rounded-lg bg-secondary disabled:opacity-40"
        aria-label="Ajouter une portion"
        disabled={value >= max}
        onClick={() => onChange(Math.min(max, value + 1))}
      >
        <Plus className="size-4" />
      </button>
    </div>
  );
}
