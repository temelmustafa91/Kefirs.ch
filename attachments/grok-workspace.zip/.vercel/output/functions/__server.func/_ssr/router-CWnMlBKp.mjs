import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as createFileRoute, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRoute, x as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as number, c as union, i as literal, n as array, o as object, r as boolean, s as string, t as _enum } from "../_libs/zod.mjs";
import { n as TriangleAlert } from "../_libs/lucide-react.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-B8w_puDl.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var pinSchema = string().regex(/^\d{4}$/);
var orderSchema = object({
	slotDate: string().regex(/^\d{4}-\d{2}-\d{2}$/),
	slotTime: string().regex(/^\d{2}:\d{2}$/),
	notes: array(_enum([
		"Sans couverts",
		"Bien chaud",
		"Sauces à part",
		"Découpé"
	])).max(4),
	lines: array(object({
		recipeId: number().int().positive(),
		qty: number().int().min(1).max(12)
	})).min(1).max(8)
});
var shopSchema = object({
	pin: pinSchema,
	name: string(),
	tagline: string(),
	announcement: string(),
	address: string(),
	openTime: string(),
	closeTime: string(),
	eveningOpen: string(),
	eveningClose: string(),
	slotMinutes: union([
		literal(15),
		literal(30),
		literal(60)
	]),
	slotCapacity: number().int().min(1).max(40),
	closedDows: array(number().int().min(0).max(6)).max(7),
	newPin: string()
});
var recipeSchema = object({
	pin: pinSchema,
	id: number().int().positive().nullable(),
	name: string(),
	description: string(),
	category: string(),
	priceCents: number().int().min(50).max(5e4),
	prepMinutes: number().int().min(0).max(240),
	published: boolean(),
	image: string(),
	lines: array(object({
		stockItemId: number().int().positive(),
		quantity: number().int().min(1).max(2e4)
	})).max(12)
});
var stockSchema = object({
	pin: pinSchema,
	id: number().int().positive().nullable(),
	name: string(),
	unit: _enum([
		"g",
		"ml",
		"pièce"
	]),
	quantity: number().int().min(0).max(1e6),
	threshold: number().int().min(0).max(1e6)
});
var adjustSchema = object({
	pin: pinSchema,
	id: number().int().positive(),
	delta: number().int().min(-1e5).max(1e5),
	reason: string()
});
var statusSchema = object({
	pin: pinSchema,
	id: number().int().positive(),
	status: _enum([
		"preparation",
		"prete",
		"retiree",
		"annulee"
	])
});
var idSchema = object({
	pin: pinSchema,
	id: number().int().positive()
});
var moveSchema = object({
	pin: pinSchema,
	id: number().int().positive(),
	direction: union([literal(-1), literal(1)])
});
var closureSchema = object({
	pin: pinSchema,
	date: string().regex(/^\d{4}-\d{2}-\d{2}$/),
	closed: boolean()
});
function parse(schema, value) {
	const result = schema.safeParse(value);
	if (!result.success) throw new Error("Demande invalide.");
	return result.data;
}
var getLockState = createServerFn({ method: "GET" }).handler(createSsrRpc("6ccd828cceeed61e1cebe2fa5a6e329b8c7ecb2f26c4b9503053ccb0e4c8f9e2"));
var getStorefront = createServerFn({ method: "GET" }).handler(createSsrRpc("54b5a3873cc350a7ec788d8a70f0eecce658812f0383df6404cdb34ab7835c67"));
var getSlots = createServerFn({ method: "GET" }).validator((date) => {
	if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error("Date invalide.");
	return date;
}).handler(createSsrRpc("22774888c2ba2bd487e7f672d7f011397edca7dd62b335e9bd691e8b5ac6a954"));
var placeOrder = createServerFn({ method: "POST" }).validator((input) => parse(orderSchema, input)).handler(createSsrRpc("d8c2838f0e5e26cac2dd741775103008e580f254037ef53c1ba429c516c172c8"));
var getOrderByCode = createServerFn({ method: "GET" }).validator((code) => code.trim().toUpperCase()).handler(createSsrRpc("ebecdc6f54d177b4d03e54cf515eecdc14a3ddd9524d8be7de817d7d66569c4a"));
var loadAtelier = createServerFn({ method: "POST" }).validator((input) => parse(object({ pin: pinSchema }), input)).handler(createSsrRpc("1c3f104ca6b57dc749d47719f76d0513f0e3588e7debf3c32407e8214ee3c40f"));
var setOrderStatus = createServerFn({ method: "POST" }).validator((input) => parse(statusSchema, input)).handler(createSsrRpc("f9f6ea229a85e66718858196333b50b10f9e54ea258527c3ae487c230eda1819"));
var saveStock = createServerFn({ method: "POST" }).validator((input) => parse(stockSchema, input)).handler(createSsrRpc("c81d0994fd7ad44861641502b3b27bd01a1314497b11aa1318eba7d05da7135b"));
var adjustStock = createServerFn({ method: "POST" }).validator((input) => parse(adjustSchema, input)).handler(createSsrRpc("f5791dbf59b810d9bdcf0a87dcb2ec280d097cd009c24217e4955b408891b9bb"));
var deleteStock = createServerFn({ method: "POST" }).validator((input) => parse(idSchema, input)).handler(createSsrRpc("726e8d662e444a2fbd68f27350c582e1b76e5d66d82fe7f49bcf845183737dec"));
var saveRecipe = createServerFn({ method: "POST" }).validator((input) => parse(recipeSchema, input)).handler(createSsrRpc("aefddfbc03a7439c4b1ebb60bdd189429da3e213da2f6cab79819b4ef52b0112"));
var deleteRecipe = createServerFn({ method: "POST" }).validator((input) => parse(idSchema, input)).handler(createSsrRpc("5e6a2873021f6d4c13f6d6ba1c47d160104a0b7a915fc683d1713d528a9e1d9f"));
var moveRecipe = createServerFn({ method: "POST" }).validator((input) => parse(moveSchema, input)).handler(createSsrRpc("9d1e5dae6b6d6c18aebf39a69b509f04478e154cd6fbab412a5fdde5ac7b0371"));
var saveShop = createServerFn({ method: "POST" }).validator((input) => parse(shopSchema, input)).handler(createSsrRpc("94138967321fc98d54ac4489dc6e998c90aa1f07eab91a5ba486d2b2c3b68ba8"));
var setClosure = createServerFn({ method: "POST" }).validator((input) => parse(closureSchema, input)).handler(createSsrRpc("13826f8d8846bc7a8aa32086aeabb637d0396bbc6c8e1c00ed63921925561a2e"));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-CWnMlBKp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-3 bg-background px-6 text-center text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
				className: "size-8 text-destructive",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl tracking-tight",
				children: "Quelque chose s'est mal passé"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-muted-foreground",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-Rk2z5i_B.css";
var Route$3 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Comptoir" },
			{
				name: "theme-color",
				content: "#f3efe7"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "fr",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "top-center",
				toastOptions: { style: {
					background: "var(--color-card)",
					color: "var(--color-foreground)",
					border: "1px solid var(--color-border)",
					boxShadow: "none"
				} }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$2 = () => import("./routes-CrZ7v2iq.mjs");
var Route$2 = createFileRoute("/")({
	loader: () => getStorefront(),
	pendingComponent: PendingHome,
	component: lazyRouteComponent($$splitComponentImporter$2, "component"),
	head: () => ({ meta: [{ title: "Comptoir — commander" }] })
});
function PendingHome() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-5xl px-4 py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm tracking-widest text-muted-foreground",
			children: "COMPTOIR"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-3 font-display text-4xl tracking-tight",
			children: "La carte se prépare"
		})]
	});
}
var SECTIONS = [
	"jour",
	"commandes",
	"planning",
	"stocks",
	"recettes",
	"application"
];
function isSection(value) {
	return typeof value === "string" && SECTIONS.includes(value);
}
var $$splitComponentImporter$1 = () => import("./atelier-CioSOuiC.mjs");
var Route$1 = createFileRoute("/atelier")({
	validateSearch: (search) => ({ section: isSection(search.section) ? search.section : "jour" }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component"),
	head: () => ({ meta: [{ title: "Atelier — Comptoir" }] })
});
var $$splitComponentImporter = () => import("./suivi-Bb7dvLTw.mjs");
var Route = createFileRoute("/suivi")({
	validateSearch: (search) => ({ code: typeof search.code === "string" ? search.code : "" }),
	loaderDeps: ({ search }) => ({ code: search.code }),
	loader: ({ deps }) => deps.code ? getOrderByCode({ data: deps.code }) : null,
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	head: () => ({ meta: [{ title: "Suivi — Comptoir" }] })
});
var rootRouteChildren = {
	IndexRoute: Route$2.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$3
	}),
	AtelierRoute: Route$1.update({
		id: "/atelier",
		path: "/atelier",
		getParentRoute: () => Route$3
	}),
	SuiviRoute: Route.update({
		id: "/suivi",
		path: "/suivi",
		getParentRoute: () => Route$3
	})
};
var routeTree = Route$3._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { setOrderStatus as _, adjustStock as a, getLockState as c, moveRecipe as d, placeOrder as f, setClosure as g, saveStock as h, Route$2 as i, getSlots as l, saveShop as m, Route as n, deleteRecipe as o, saveRecipe as p, Route$1 as r, deleteStock as s, router_exports as t, loadAtelier as u };
