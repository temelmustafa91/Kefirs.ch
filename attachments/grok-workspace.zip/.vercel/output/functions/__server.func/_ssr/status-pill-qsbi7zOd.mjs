import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { r as STATUS_LABEL } from "./format-DcnPm31r.mjs";
import { n as cn } from "./button-CqtuPLNw.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/status-pill-qsbi7zOd.js
var import_jsx_runtime = require_jsx_runtime();
var tone = {
	recue: "bg-foreground",
	preparation: "bg-warn",
	prete: "bg-ok",
	retiree: "bg-muted-foreground",
	annulee: "bg-destructive"
};
function StatusPill({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex h-8 items-center gap-2 rounded-full bg-secondary px-3 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-1.5 rounded-full", tone[status]) }), STATUS_LABEL[status]]
	});
}
//#endregion
export { StatusPill as t };
