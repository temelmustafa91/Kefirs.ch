//#region node_modules/.nitro/vite/services/ssr/assets/format-DcnPm31r.js
var NOTE_PRESETS = [
	"Sans couverts",
	"Bien chaud",
	"Sauces à part",
	"Découpé"
];
var DISH_KEYS = [
	"potimarron",
	"poireaux",
	"poulet",
	"citron",
	"lentilles",
	"cake"
];
var UNITS = [
	"g",
	"ml",
	"pièce"
];
var STATUS_LABEL = {
	recue: "Reçue",
	preparation: "En préparation",
	prete: "Prête",
	retiree: "Retirée",
	annulee: "Annulée"
};
var DAY_NAMES = [
	"dim",
	"lun",
	"mar",
	"mer",
	"jeu",
	"ven",
	"sam"
];
function dishSrc(key) {
	return DISH_KEYS.includes(key) ? `/menu/${key}.jpg` : null;
}
function formatEUR(cents) {
	return new Intl.NumberFormat("fr-FR", {
		style: "currency",
		currency: "EUR"
	}).format(cents / 100);
}
function formatQty(value) {
	return new Intl.NumberFormat("fr-FR").format(value);
}
function eurosInput(cents) {
	return (cents / 100).toFixed(2).replace(".", ",");
}
function parseEuros(value) {
	const cleaned = value.trim().replace(/\s/g, "").replace(",", ".");
	if (!/^\d+(\.\d{1,2})?$/.test(cleaned)) return null;
	const cents = Math.round(Number(cleaned) * 100);
	if (cents < 50 || cents > 5e4) return null;
	return cents;
}
function parisNow() {
	const parts = Object.fromEntries(new Intl.DateTimeFormat("en-GB", {
		timeZone: "Europe/Paris",
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
		hour: "2-digit",
		minute: "2-digit",
		hourCycle: "h23"
	}).formatToParts(/* @__PURE__ */ new Date()).map((part) => [part.type, part.value]));
	return {
		date: `${parts.year}-${parts.month}-${parts.day}`,
		minutes: Number(parts.hour) * 60 + Number(parts.minute)
	};
}
function utcDate(iso) {
	const [year, month, day] = iso.split("-").map(Number);
	return new Date(Date.UTC(year, (month ?? 1) - 1, day ?? 1));
}
function addDays(date, days) {
	const next = new Date(date);
	next.setUTCDate(next.getUTCDate() + days);
	return next;
}
function formatIso(date) {
	return date.toISOString().slice(0, 10);
}
function formatDay(iso) {
	return new Intl.DateTimeFormat("fr-FR", {
		weekday: "short",
		day: "numeric",
		month: "short",
		timeZone: "UTC"
	}).format(utcDate(iso));
}
function axisDay(iso) {
	const [, month, day] = iso.split("-");
	return `${day}/${month}`;
}
function formatStamp(value) {
	const date = new Date(value);
	if (Number.isNaN(date.getTime())) return "";
	return new Intl.DateTimeFormat("fr-FR", {
		timeZone: "Europe/Paris",
		day: "2-digit",
		month: "2-digit",
		hour: "2-digit",
		minute: "2-digit"
	}).format(date);
}
function toMinutes(time) {
	const [hour, minute] = time.split(":").map(Number);
	return hour * 60 + minute;
}
function fromMinutes(value) {
	const hour = Math.floor(value / 60);
	const minute = value % 60;
	return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
}
function timesBetween(start, end, step) {
	const out = [];
	for (let cursor = toMinutes(start); cursor <= toMinutes(end); cursor += step) out.push(fromMinutes(cursor));
	return out;
}
function slotTimes(shop) {
	const morning = timesBetween(shop.openTime, shop.closeTime, shop.slotMinutes);
	if (!shop.eveningOpen || !shop.eveningClose) return morning;
	return [.../* @__PURE__ */ new Set([...morning, ...timesBetween(shop.eveningOpen, shop.eveningClose, shop.slotMinutes)])];
}
function hoursLabel(shop) {
	const open = [
		0,
		1,
		2,
		3,
		4,
		5,
		6
	].filter((day) => !shop.closedDows.includes(day));
	const groups = [];
	for (const day of open) {
		const last = groups.at(-1);
		if (last && day === last.at(-1) + 1) last.push(day);
		else groups.push([day]);
	}
	const days = groups.length === 0 ? "fermé" : groups.map((group) => group.length === 1 ? DAY_NAMES[group[0]] : `${DAY_NAMES[group[0]]}–${DAY_NAMES[group.at(-1)]}`).join(", ");
	const evening = shop.eveningOpen && shop.eveningClose ? ` · ${shop.eveningOpen}–${shop.eveningClose}` : "";
	return `${days} · ${shop.openTime}–${shop.closeTime}${evening}`;
}
function dowOf(iso) {
	return utcDate(iso).getUTCDay();
}
function weekStart(iso) {
	const date = utcDate(iso);
	const dow = date.getUTCDay();
	return formatIso(addDays(date, dow === 0 ? -6 : 1 - dow));
}
function messageOf(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return "Une erreur est survenue.";
}
function isBookableSlot(shop, closures, date, time) {
	if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^\d{2}:\d{2}$/.test(time)) return false;
	if (shop.closedDows.includes(dowOf(date)) || closures.includes(date)) return false;
	if (!slotTimes(shop).includes(time)) return false;
	const now = parisNow();
	if (date < now.date) return false;
	if (date === now.date && toMinutes(time) < now.minutes + 40) return false;
	return true;
}
function upcomingDays(shop, closures, count) {
	const now = parisNow();
	const closed = new Set(closures);
	const out = [];
	const start = utcDate(now.date);
	for (let index = 0; index < 28 && out.length < count; index += 1) {
		const date = formatIso(addDays(start, index));
		if (shop.closedDows.includes(dowOf(date)) || closed.has(date)) continue;
		if (slotTimes(shop).filter((time) => date !== now.date || toMinutes(time) >= now.minutes + 40).length === 0) continue;
		out.push({
			date,
			label: formatDay(date)
		});
	}
	return out;
}
//#endregion
export { utcDate as C, upcomingDays as S, messageOf as _, addDays as a, slotTimes as b, dowOf as c, formatEUR as d, formatIso as f, isBookableSlot as g, hoursLabel as h, UNITS as i, eurosInput as l, formatStamp as m, NOTE_PRESETS as n, axisDay as o, formatQty as p, STATUS_LABEL as r, dishSrc as s, DISH_KEYS as t, formatDay as u, parisNow as v, weekStart as w, toMinutes as x, parseEuros as y };
