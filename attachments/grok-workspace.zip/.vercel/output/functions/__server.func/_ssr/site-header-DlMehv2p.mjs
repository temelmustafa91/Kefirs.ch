import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/site-header-DlMehv2p.js
var import_jsx_runtime = require_jsx_runtime();
function SiteHeader() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "safe-top border-b border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-5xl items-center justify-between px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "font-display text-2xl tracking-tight",
				children: "Comptoir"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex items-center gap-1 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/suivi",
					search: { code: "" },
					className: "inline-flex h-11 items-center rounded-lg px-3 hover:bg-secondary",
					children: "Suivre"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/atelier",
					search: { section: "jour" },
					className: "inline-flex h-11 items-center rounded-lg px-3 hover:bg-secondary",
					children: "Atelier"
				})]
			})]
		})
	});
}
//#endregion
export { SiteHeader as t };
