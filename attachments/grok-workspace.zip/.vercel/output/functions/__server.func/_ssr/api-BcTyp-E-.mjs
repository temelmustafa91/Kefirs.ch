import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { C as utcDate, S as upcomingDays, a as addDays, b as slotTimes, f as formatIso, g as isBookableSlot, h as hoursLabel, m as formatStamp, o as axisDay, t as DISH_KEYS, v as parisNow, x as toMinutes } from "./format-DcnPm31r.mjs";
import { a as number, c as union, i as literal, n as array, o as object, r as boolean, s as string, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-BcTyp-E-.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var _0002_comptoir_default = "-- Comptoir: carte, stocks, recettes, commandes, planning.\n\ncreate table shop (\n  id integer primary key check (id = 1),\n  name text not null,\n  tagline text not null,\n  announcement text not null default '',\n  address text not null default '',\n  pin_code text not null check (pin_code ~ '^[0-9]{4}$'),\n  open_time text not null,\n  close_time text not null,\n  evening_open text,\n  evening_close text,\n  slot_minutes integer not null default 30 check (slot_minutes in (15, 30, 60)),\n  slot_capacity integer not null default 10 check (slot_capacity > 0),\n  closed_dows text not null default '0,1'\n);\n\ncreate table stock_items (\n  id serial primary key,\n  name text not null,\n  unit text not null check (unit in ('g', 'ml', 'pièce')),\n  quantity integer not null check (quantity >= 0),\n  threshold integer not null default 0 check (threshold >= 0)\n);\n\ncreate table recipes (\n  id serial primary key,\n  name text not null,\n  description text not null default '',\n  category text not null,\n  price_cents integer not null check (price_cents > 0),\n  prep_minutes integer not null default 15 check (prep_minutes >= 0),\n  published boolean not null default true,\n  image text not null default '',\n  sort_order integer not null default 0\n);\n\ncreate table recipe_lines (\n  id serial primary key,\n  recipe_id integer not null references recipes (id) on delete cascade,\n  stock_item_id integer not null references stock_items (id),\n  quantity integer not null check (quantity > 0)\n);\n\ncreate table orders (\n  id serial primary key,\n  code text not null unique,\n  slot_date date not null,\n  slot_time text not null,\n  status text not null default 'recue' check (status in ('recue', 'preparation', 'prete', 'retiree', 'annulee')),\n  notes text not null default '',\n  total_cents integer not null check (total_cents >= 0),\n  created_at timestamptz not null default now()\n);\n\ncreate table order_lines (\n  id serial primary key,\n  order_id integer not null references orders (id) on delete cascade,\n  recipe_id integer references recipes (id) on delete set null,\n  name text not null,\n  qty integer not null check (qty > 0),\n  unit_cents integer not null check (unit_cents >= 0)\n);\n\ncreate table order_stock (\n  id serial primary key,\n  order_id integer not null references orders (id) on delete cascade,\n  stock_item_id integer not null references stock_items (id),\n  quantity integer not null check (quantity > 0)\n);\n\ncreate table stock_moves (\n  id serial primary key,\n  stock_item_id integer not null references stock_items (id) on delete cascade,\n  delta integer not null,\n  reason text not null,\n  created_at timestamptz not null default now()\n);\n\ncreate table closures (\n  day date primary key,\n  reason text not null default ''\n);\n\ncreate index orders_slot_idx on orders (slot_date, slot_time);\ncreate index order_lines_order_idx on order_lines (order_id);\ncreate index recipe_lines_recipe_idx on recipe_lines (recipe_id);\n\ncreate or replace function place_comptoir_order(\n  payload jsonb,\n  order_code text,\n  p_date date,\n  p_time text,\n  order_notes text\n) returns table (\n  order_id integer,\n  total_cents integer,\n  placed_code text,\n  recipes_ok boolean,\n  published_ok boolean,\n  stock_ok boolean,\n  capacity_ok boolean,\n  open_ok boolean,\n  short_names text\n)\nlanguage plpgsql\nas $$\ndeclare\n  v_lines integer;\n  v_found integer;\n  v_recipes_ok boolean := false;\n  v_published_ok boolean := false;\n  v_stock_ok boolean := true;\n  v_capacity_ok boolean := false;\n  v_open_ok boolean := false;\n  v_short text := null;\n  v_total integer := 0;\n  v_id integer := null;\n  v_cap integer := 0;\n  v_used integer := 0;\n  v_add integer := 0;\n  rec record;\nbegin\n  perform 1 from shop where id = 1 for update;\n\n  perform id\n  from stock_items\n  where id in (\n    select rl.stock_item_id\n    from jsonb_array_elements(payload) as line\n    join recipe_lines rl on rl.recipe_id = (line->>'recipeId')::integer\n  )\n  order by id\n  for update;\n\n  select count(*)::integer into v_lines from jsonb_array_elements(payload) as line;\n\n  select count(*)::integer into v_found\n  from jsonb_array_elements(payload) as line\n  join recipes r on r.id = (line->>'recipeId')::integer;\n\n  v_recipes_ok := v_lines > 0 and v_lines = v_found;\n\n  select coalesce(bool_and(r.published), false) into v_published_ok\n  from jsonb_array_elements(payload) as line\n  join recipes r on r.id = (line->>'recipeId')::integer;\n\n  for rec in\n    select s.name as item_name,\n           s.quantity as have,\n           sum(rl.quantity * (line->>'qty')::integer)::integer as need\n    from jsonb_array_elements(payload) as line\n    join recipe_lines rl on rl.recipe_id = (line->>'recipeId')::integer\n    join stock_items s on s.id = rl.stock_item_id\n    group by s.id, s.name, s.quantity\n  loop\n    if rec.have < rec.need then\n      v_stock_ok := false;\n      v_short := concat_ws(', ', v_short, rec.item_name);\n    end if;\n  end loop;\n\n  select slot_capacity into v_cap from shop where id = 1;\n\n  select coalesce(sum(l.qty), 0)::integer into v_used\n  from orders o\n  join order_lines l on l.order_id = o.id\n  where o.slot_date = p_date\n    and o.slot_time = p_time\n    and o.status <> 'annulee';\n\n  select coalesce(sum((line->>'qty')::integer), 0)::integer into v_add\n  from jsonb_array_elements(payload) as line;\n\n  v_capacity_ok := v_used + v_add <= v_cap;\n\n  select not exists (select 1 from closures c where c.day = p_date) into v_open_ok;\n\n  if v_recipes_ok and v_published_ok and v_stock_ok and v_capacity_ok and v_open_ok then\n    select coalesce(sum(r.price_cents * (line->>'qty')::integer), 0)::integer into v_total\n    from jsonb_array_elements(payload) as line\n    join recipes r on r.id = (line->>'recipeId')::integer;\n\n    insert into orders (code, slot_date, slot_time, status, notes, total_cents)\n    values (order_code, p_date, p_time, 'recue', order_notes, v_total)\n    returning id into v_id;\n\n    insert into order_lines (order_id, recipe_id, name, qty, unit_cents)\n    select v_id, r.id, r.name, (line->>'qty')::integer, r.price_cents\n    from jsonb_array_elements(payload) as line\n    join recipes r on r.id = (line->>'recipeId')::integer;\n\n    insert into order_stock (order_id, stock_item_id, quantity)\n    select v_id, rl.stock_item_id, sum(rl.quantity * (line->>'qty')::integer)::integer\n    from jsonb_array_elements(payload) as line\n    join recipe_lines rl on rl.recipe_id = (line->>'recipeId')::integer\n    group by rl.stock_item_id;\n\n    insert into stock_moves (stock_item_id, delta, reason)\n    select rl.stock_item_id,\n           -sum(rl.quantity * (line->>'qty')::integer)::integer,\n           'Commande ' || order_code\n    from jsonb_array_elements(payload) as line\n    join recipe_lines rl on rl.recipe_id = (line->>'recipeId')::integer\n    group by rl.stock_item_id;\n\n    update stock_items s\n    set quantity = s.quantity - n.need\n    from (\n      select rl.stock_item_id, sum(rl.quantity * (line->>'qty')::integer)::integer as need\n      from jsonb_array_elements(payload) as line\n      join recipe_lines rl on rl.recipe_id = (line->>'recipeId')::integer\n      group by rl.stock_item_id\n    ) as n\n    where s.id = n.stock_item_id;\n  end if;\n\n  return query\n  select v_id, v_total, order_code, v_recipes_ok, v_published_ok, v_stock_ok, v_capacity_ok, v_open_ok, v_short;\nend;\n$$;\n\ncreate or replace function cancel_comptoir_order(p_id integer)\nreturns table (previous text, updated integer)\nlanguage plpgsql\nas $$\ndeclare\n  v_status text;\n  v_code text;\n  v_updated integer := 0;\nbegin\n  select status, code into v_status, v_code from orders where id = p_id for update;\n  if v_status is null then\n    return query select null::text, 0;\n    return;\n  end if;\n\n  if v_status in ('recue', 'preparation', 'prete') then\n    update orders set status = 'annulee' where id = p_id;\n    get diagnostics v_updated = row_count;\n\n    update stock_items s\n    set quantity = s.quantity + b.qty\n    from (\n      select stock_item_id, sum(quantity)::integer as qty\n      from order_stock\n      where order_id = p_id\n      group by stock_item_id\n    ) as b\n    where s.id = b.stock_item_id;\n\n    insert into stock_moves (stock_item_id, delta, reason)\n    select stock_item_id, sum(quantity)::integer, 'Annulation ' || v_code\n    from order_stock\n    where order_id = p_id\n    group by stock_item_id;\n  end if;\n\n  return query select v_status, v_updated;\nend;\n$$;\n\ninsert into shop (\n  id, name, tagline, announcement, address, pin_code,\n  open_time, close_time, evening_open, evening_close,\n  slot_minutes, slot_capacity, closed_dows\n) values (\n  1,\n  'Maison Brume',\n  'La cuisine du jour, à retirer au comptoir.',\n  'Les tourtes et le poulet partent en début de service. Choisissez un créneau.',\n  '12 rue des Ateliers',\n  '4820',\n  '11:30',\n  '14:30',\n  '18:00',\n  '20:30',\n  30,\n  10,\n  '0,1'\n);\n\ninsert into stock_items (id, name, unit, quantity, threshold) values\n  (1, 'Potimarron', 'g', 4200, 1500),\n  (2, 'Poireaux', 'g', 2800, 800),\n  (3, 'Crème', 'ml', 1400, 400),\n  (4, 'Beurre', 'g', 280, 300),\n  (5, 'Farine', 'g', 3500, 800),\n  (6, 'Œufs', 'pièce', 24, 8),\n  (7, 'Poulet', 'pièce', 5, 4),\n  (8, 'Herbes', 'g', 60, 20),\n  (9, 'Citron', 'pièce', 4, 6),\n  (10, 'Sucre', 'g', 1600, 400),\n  (11, 'Lentilles', 'g', 2200, 500),\n  (12, 'Olives', 'g', 700, 200),\n  (13, 'Romarin', 'g', 12, 20),\n  (14, 'Yaourt', 'ml', 900, 250);\n\nselect setval('stock_items_id_seq', (select max(id) from stock_items));\n\ninsert into recipes (id, name, description, category, price_cents, prep_minutes, published, image, sort_order) values\n  (1, 'Velouté de potimarron', 'Potimarron rôti, crème et graines toastées.', 'Soupe', 900, 10, true, 'potimarron', 2),\n  (2, 'Tarte fine aux poireaux', 'Poireaux fondus, pâte brisée au beurre.', 'Tarte', 1400, 15, true, 'poireaux', 3),\n  (3, 'Poulet rôti aux herbes', 'Cuisse laquée, jus court au romarin.', 'Plat', 1850, 20, true, 'poulet', 4),\n  (4, 'Salade de lentilles', 'Lentilles vertes, herbes et huile d''olive.', 'Entrée', 1100, 10, true, 'lentilles', 1),\n  (5, 'Tarte au citron', 'Crème citron et pâte sucrée.', 'Dessert', 800, 10, true, 'citron', 6),\n  (6, 'Cake olives et romarin', 'Cake salé, olives noires et romarin.', 'Cake', 650, 5, true, 'cake', 5);\n\nselect setval('recipes_id_seq', (select max(id) from recipes));\n\ninsert into recipe_lines (recipe_id, stock_item_id, quantity) values\n  (1, 1, 200), (1, 3, 50),\n  (2, 2, 150), (2, 4, 30), (2, 5, 50), (2, 6, 1),\n  (3, 7, 1), (3, 8, 8),\n  (4, 11, 90), (4, 8, 4),\n  (5, 9, 1), (5, 4, 40), (5, 5, 30), (5, 6, 1), (5, 10, 40),\n  (6, 5, 60), (6, 6, 1), (6, 12, 25), (6, 13, 3), (6, 14, 40);\n\ninsert into stock_moves (stock_item_id, delta, reason)\nselect id, quantity, 'Inventaire d''ouverture' from stock_items;\n\nwith days as (\n  select g.d::date as d, row_number() over (order by g.d) as n\n  from generate_series(current_date, current_date + 21, interval '1 day') as g(d)\n  where extract(dow from g.d)::int not in (0, 1)\n),\npast as (\n  select g.d::date as d, row_number() over (order by g.d desc) as n\n  from generate_series(current_date - 21, current_date - 1, interval '1 day') as g(d)\n  where extract(dow from g.d)::int not in (0, 1)\n),\nseed as (\n  select * from (values\n    ('BR-1842', 1, 0, '12:00', 'preparation', 'Bien chaud', 3200),\n    ('BR-1907', 1, 0, '12:30', 'recue', 'Sauces à part', 3450),\n    ('BR-2031', 1, 0, '18:30', 'prete', '', 1950),\n    ('BR-2210', 2, 0, '12:00', 'recue', 'Sans couverts', 4050),\n    ('BR-1044', 0, 1, '12:30', 'retiree', '', 1850),\n    ('BR-1108', 0, 2, '13:00', 'retiree', '', 2300),\n    ('BR-1215', 0, 3, '18:30', 'retiree', '', 1950),\n    ('BR-1302', 0, 4, '12:00', 'retiree', '', 3750)\n  ) as v(code, day_n, past_n, slot_time, status, notes, total_cents)\n)\ninsert into orders (code, slot_date, slot_time, status, notes, total_cents)\nselect\n  s.code,\n  case\n    when s.day_n > 0 then (select d from days where n = s.day_n)\n    else (select d from past where n = s.past_n)\n  end,\n  s.slot_time,\n  s.status,\n  s.notes,\n  s.total_cents\nfrom seed as s;\n\ninsert into order_lines (order_id, recipe_id, name, qty, unit_cents)\nselect o.id, v.recipe_id, v.name, v.qty, v.unit_cents\nfrom (values\n  ('BR-1842', 1, 'Velouté de potimarron', 2, 900),\n  ('BR-1842', 2, 'Tarte fine aux poireaux', 1, 1400),\n  ('BR-1907', 3, 'Poulet rôti aux herbes', 1, 1850),\n  ('BR-1907', 5, 'Tarte au citron', 2, 800),\n  ('BR-2031', 6, 'Cake olives et romarin', 3, 650),\n  ('BR-2210', 4, 'Salade de lentilles', 2, 1100),\n  ('BR-2210', 3, 'Poulet rôti aux herbes', 1, 1850),\n  ('BR-1044', 3, 'Poulet rôti aux herbes', 1, 1850),\n  ('BR-1108', 1, 'Velouté de potimarron', 1, 900),\n  ('BR-1108', 2, 'Tarte fine aux poireaux', 1, 1400),\n  ('BR-1215', 6, 'Cake olives et romarin', 3, 650),\n  ('BR-1302', 3, 'Poulet rôti aux herbes', 1, 1850),\n  ('BR-1302', 4, 'Salade de lentilles', 1, 1100),\n  ('BR-1302', 5, 'Tarte au citron', 1, 800)\n) as v(code, recipe_id, name, qty, unit_cents)\njoin orders o on o.code = v.code;\n\ninsert into order_stock (order_id, stock_item_id, quantity)\nselect o.id, v.stock_item_id, v.quantity\nfrom (values\n  ('BR-1842', 1, 400),\n  ('BR-1842', 3, 100),\n  ('BR-1842', 2, 150),\n  ('BR-1842', 4, 30),\n  ('BR-1842', 5, 50),\n  ('BR-1842', 6, 1),\n  ('BR-1907', 7, 1),\n  ('BR-1907', 8, 8),\n  ('BR-1907', 9, 2),\n  ('BR-1907', 4, 80),\n  ('BR-1907', 5, 60),\n  ('BR-1907', 6, 2),\n  ('BR-1907', 10, 80),\n  ('BR-2031', 5, 180),\n  ('BR-2031', 6, 3),\n  ('BR-2031', 12, 75),\n  ('BR-2031', 13, 9),\n  ('BR-2031', 14, 120),\n  ('BR-2210', 11, 180),\n  ('BR-2210', 8, 16),\n  ('BR-2210', 7, 1)\n) as v(code, stock_item_id, quantity)\njoin orders o on o.code = v.code;\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
* sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
* the app has a working database even with nothing configured — the live preview
* included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
*/
var dbSource = databaseUrl ? "neon" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.t);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({ "/migrations/0002_comptoir.sql": _0002_comptoir_default });
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "neon" ? createNeonSql() : createPgliteSql();
}
/**
* Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
* otherwise the local PGLite fallback. Memoized — safe to call per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
var pinSchema = string().regex(/^\d{4}$/);
var orderSchema = object({
	slotDate: string().regex(/^\d{4}-\d{2}-\d{2}$/),
	slotTime: string().regex(/^\d{2}:\d{2}$/),
	notes: array(_enum([
		"Sans couverts",
		"Bien chaud",
		"Sauces à part",
		"Découpé"
	])).max(4),
	lines: array(object({
		recipeId: number().int().positive(),
		qty: number().int().min(1).max(12)
	})).min(1).max(8)
});
var shopSchema = object({
	pin: pinSchema,
	name: string(),
	tagline: string(),
	announcement: string(),
	address: string(),
	openTime: string(),
	closeTime: string(),
	eveningOpen: string(),
	eveningClose: string(),
	slotMinutes: union([
		literal(15),
		literal(30),
		literal(60)
	]),
	slotCapacity: number().int().min(1).max(40),
	closedDows: array(number().int().min(0).max(6)).max(7),
	newPin: string()
});
var recipeSchema = object({
	pin: pinSchema,
	id: number().int().positive().nullable(),
	name: string(),
	description: string(),
	category: string(),
	priceCents: number().int().min(50).max(5e4),
	prepMinutes: number().int().min(0).max(240),
	published: boolean(),
	image: string(),
	lines: array(object({
		stockItemId: number().int().positive(),
		quantity: number().int().min(1).max(2e4)
	})).max(12)
});
var stockSchema = object({
	pin: pinSchema,
	id: number().int().positive().nullable(),
	name: string(),
	unit: _enum([
		"g",
		"ml",
		"pièce"
	]),
	quantity: number().int().min(0).max(1e6),
	threshold: number().int().min(0).max(1e6)
});
var adjustSchema = object({
	pin: pinSchema,
	id: number().int().positive(),
	delta: number().int().min(-1e5).max(1e5),
	reason: string()
});
var statusSchema = object({
	pin: pinSchema,
	id: number().int().positive(),
	status: _enum([
		"preparation",
		"prete",
		"retiree",
		"annulee"
	])
});
var idSchema = object({
	pin: pinSchema,
	id: number().int().positive()
});
var moveSchema = object({
	pin: pinSchema,
	id: number().int().positive(),
	direction: union([literal(-1), literal(1)])
});
var closureSchema = object({
	pin: pinSchema,
	date: string().regex(/^\d{4}-\d{2}-\d{2}$/),
	closed: boolean()
});
function parse(schema, value) {
	const result = schema.safeParse(value);
	if (!result.success) throw new Error("Demande invalide.");
	return result.data;
}
function num(value) {
	const parsed = typeof value === "number" ? value : Number(value);
	return Number.isFinite(parsed) ? parsed : 0;
}
function flag(value) {
	return value === true || value === "t" || value === "true";
}
function clean(value, min, max, label) {
	const next = value.trim();
	if (next.length < min || next.length > max) throw new Error(`${label} : longueur invalide.`);
	return next;
}
function validTime(value) {
	if (!/^\d{2}:\d{2}$/.test(value)) return false;
	const [hour, minute] = value.split(":").map(Number);
	return hour <= 23 && minute <= 59;
}
function parseDows(value) {
	return value.split(",").map((part) => Number(part.trim())).filter((day) => day >= 0 && day <= 6);
}
function asStatus(value) {
	if (value === "recue" || value === "preparation" || value === "prete" || value === "retiree" || value === "annulee") return value;
	return "recue";
}
function readJson(value, map) {
	const source = typeof value === "string" ? JSON.parse(value) : value;
	if (!Array.isArray(source)) return [];
	return source.map((row) => map(row));
}
function toShop(row) {
	const shop = {
		name: row.name,
		tagline: row.tagline,
		announcement: row.announcement,
		address: row.address,
		openTime: row.open_time,
		closeTime: row.close_time,
		eveningOpen: row.evening_open || null,
		eveningClose: row.evening_close || null,
		slotMinutes: num(row.slot_minutes),
		slotCapacity: num(row.slot_capacity),
		closedDows: parseDows(row.closed_dows),
		hoursLabel: ""
	};
	shop.hoursLabel = hoursLabel(shop);
	return shop;
}
async function loadShop(sql) {
	const rows = await sql`
    select name, tagline, announcement, address, open_time, close_time,
           evening_open, evening_close, slot_minutes, slot_capacity, closed_dows
    from shop where id = 1
  `;
	if (!rows[0]) throw new Error("Comptoir non initialisé.");
	return toShop(rows[0]);
}
async function loadClosures(sql) {
	return (await sql`select day::text as day from closures order by day`).map((row) => row.day);
}
async function assertPin(sql, pin) {
	if (!flag((await sql`select (pin_code = ${pin}) as ok from shop where id = 1`)[0]?.ok)) throw new Error("Code atelier incorrect.");
}
async function gate(pin) {
	const sql = await getSql();
	await assertPin(sql, pin);
	return sql;
}
var ORDER_SQL = `
  select
    o.id,
    o.code,
    o.slot_date::text as slot_date,
    o.slot_time,
    o.status,
    o.notes,
    o.total_cents,
    to_char(o.created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as created_at,
    coalesce((
      select json_agg(json_build_object('name', l.name, 'qty', l.qty, 'unitCents', l.unit_cents) order by l.id)
      from order_lines l where l.order_id = o.id
    ), '[]'::json) as lines,
    coalesce((
      select json_agg(json_build_object('name', s.name, 'unit', s.unit, 'quantity', os.quantity) order by s.name)
      from order_stock os
      join stock_items s on s.id = os.stock_item_id
      where os.order_id = o.id
    ), '[]'::json) as stock_use
  from orders o
`;
function mapLines(value) {
	return readJson(value, (row) => ({
		name: String(row.name ?? ""),
		qty: num(row.qty),
		unitCents: num(row.unitCents)
	}));
}
function mapStockUse(value) {
	return readJson(value, (row) => ({
		name: String(row.name ?? ""),
		unit: String(row.unit ?? ""),
		quantity: num(row.quantity)
	}));
}
function mapOrder(row) {
	return {
		id: num(row.id),
		code: row.code,
		slotDate: row.slot_date,
		slotTime: row.slot_time,
		status: asStatus(row.status),
		notes: row.notes,
		totalCents: num(row.total_cents),
		createdLabel: formatStamp(row.created_at),
		lines: mapLines(row.lines),
		stockUse: mapStockUse(row.stock_use)
	};
}
async function snapshot(sql) {
	const today = parisNow().date;
	const start = formatIso(addDays(utcDate(today), -6));
	const [shop, demoRows, orderRows, stockRows, moveRows, recipeRows, lineRows, seriesRows, closureRows] = await Promise.all([
		loadShop(sql),
		sql`select (pin_code = '4820') as demo_lock from shop where id = 1`,
		sql.query(`${ORDER_SQL} order by o.slot_date desc, o.slot_time desc, o.id desc limit 400`),
		sql`
        select id, name, unit, quantity, threshold from stock_items order by name
      `,
		sql`
        select m.id, s.name, s.unit, m.delta, m.reason,
               to_char(m.created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as created_at
        from stock_moves m
        join stock_items s on s.id = m.stock_item_id
        order by m.id desc
        limit 12
      `,
		sql`
        select id, name, description, category, price_cents, prep_minutes, published, image
        from recipes order by sort_order, id
      `,
		sql`
        select rl.recipe_id, rl.stock_item_id, rl.quantity, s.name, s.unit
        from recipe_lines rl
        join stock_items s on s.id = rl.stock_item_id
        order by rl.id
      `,
		sql`
        select slot_date::text as date,
               coalesce(sum(total_cents) filter (where status <> 'annulee'), 0)::int as booked,
               coalesce(sum(total_cents) filter (where status = 'retiree'), 0)::int as paid
        from orders
        where slot_date between ${start}::date and ${today}::date
        group by slot_date
      `,
		sql`select day::text as day from closures order by day`
	]);
	const linesByRecipe = /* @__PURE__ */ new Map();
	for (const line of lineRows) {
		const bucket = linesByRecipe.get(num(line.recipe_id)) ?? [];
		bucket.push({
			stockItemId: num(line.stock_item_id),
			name: line.name,
			unit: line.unit,
			quantity: num(line.quantity)
		});
		linesByRecipe.set(num(line.recipe_id), bucket);
	}
	const byDate = new Map(seriesRows.map((row) => [row.date, row]));
	const series = Array.from({ length: 7 }, (_, index) => {
		const date = formatIso(addDays(utcDate(start), index));
		const row = byDate.get(date);
		return {
			date,
			label: axisDay(date),
			bookedCents: num(row?.booked),
			paidCents: num(row?.paid)
		};
	});
	const stock = stockRows.map((row) => ({
		id: num(row.id),
		name: row.name,
		unit: row.unit,
		quantity: num(row.quantity),
		threshold: num(row.threshold)
	}));
	const moves = moveRows.map((row) => ({
		id: num(row.id),
		name: row.name,
		unit: row.unit,
		delta: num(row.delta),
		reason: row.reason,
		createdLabel: formatStamp(row.created_at)
	}));
	const recipes = recipeRows.map((row) => ({
		id: num(row.id),
		name: row.name,
		description: row.description,
		category: row.category,
		priceCents: num(row.price_cents),
		prepMinutes: num(row.prep_minutes),
		published: flag(row.published),
		image: row.image,
		lines: linesByRecipe.get(num(row.id)) ?? []
	}));
	return {
		today,
		shop: {
			...shop,
			demoLock: flag(demoRows[0]?.demo_lock)
		},
		orders: orderRows.map(mapOrder),
		stock,
		moves,
		recipes,
		series,
		closures: closureRows.map((row) => row.day)
	};
}
var getLockState_createServerFn_handler = createServerRpc({
	id: "6ccd828cceeed61e1cebe2fa5a6e329b8c7ecb2f26c4b9503053ccb0e4c8f9e2",
	name: "getLockState",
	filename: "src/lib/comptoir/api.ts"
}, (opts) => getLockState.__executeServer(opts));
var getLockState = createServerFn({ method: "GET" }).handler(getLockState_createServerFn_handler, async () => {
	return { demoLock: flag((await (await getSql())`select (pin_code = '4820') as demo_lock from shop where id = 1`)[0]?.demo_lock) };
});
var getStorefront_createServerFn_handler = createServerRpc({
	id: "54b5a3873cc350a7ec788d8a70f0eecce658812f0383df6404cdb34ab7835c67",
	name: "getStorefront",
	filename: "src/lib/comptoir/api.ts"
}, (opts) => getStorefront.__executeServer(opts));
var getStorefront = createServerFn({ method: "GET" }).handler(getStorefront_createServerFn_handler, async () => {
	const sql = await getSql();
	const shop = await loadShop(sql);
	const closures = await loadClosures(sql);
	return {
		shop,
		menu: (await sql`
    select r.id, r.name, r.description, r.category, r.price_cents, r.prep_minutes, r.image,
      case
        when count(rl.id) = 0 then 20
        else least(20, coalesce(min(floor(s.quantity::numeric / rl.quantity))::int, 0))
      end as available
    from recipes r
    left join recipe_lines rl on rl.recipe_id = r.id
    left join stock_items s on s.id = rl.stock_item_id
    where r.published
    group by r.id
    order by r.sort_order, r.id
  `).map((row) => ({
			id: num(row.id),
			name: row.name,
			description: row.description,
			category: row.category,
			priceCents: num(row.price_cents),
			prepMinutes: num(row.prep_minutes),
			image: row.image,
			available: Math.max(0, num(row.available))
		})),
		days: upcomingDays(shop, closures, 6)
	};
});
var getSlots_createServerFn_handler = createServerRpc({
	id: "22774888c2ba2bd487e7f672d7f011397edca7dd62b335e9bd691e8b5ac6a954",
	name: "getSlots",
	filename: "src/lib/comptoir/api.ts"
}, (opts) => getSlots.__executeServer(opts));
var getSlots = createServerFn({ method: "GET" }).validator((date) => {
	if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error("Date invalide.");
	return date;
}).handler(getSlots_createServerFn_handler, async ({ data: date }) => {
	const sql = await getSql();
	const shop = await loadShop(sql);
	const closures = await loadClosures(sql);
	if (shop.closedDows.includes((/* @__PURE__ */ new Date(`${date}T12:00:00Z`)).getUTCDay()) || closures.includes(date)) return {
		date,
		closed: true,
		slots: []
	};
	const now = parisNow();
	const times = slotTimes(shop).filter((time) => date > now.date || date === now.date && toMinutes(time) >= now.minutes + 40);
	const used = await sql`
      select o.slot_time, coalesce(sum(l.qty), 0)::int as portions
      from orders o
      join order_lines l on l.order_id = o.id
      where o.slot_date = ${date}::date and o.status <> 'annulee'
      group by o.slot_time
    `;
	const byTime = new Map(used.map((row) => [row.slot_time, num(row.portions)]));
	return {
		date,
		closed: false,
		slots: times.map((time) => {
			const taken = byTime.get(time) ?? 0;
			return {
				time,
				remaining: Math.max(0, shop.slotCapacity - taken),
				capacity: shop.slotCapacity
			};
		})
	};
});
function makeCode() {
	const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
	let code = "BR-";
	for (let index = 0; index < 4; index += 1) code += alphabet[Math.floor(Math.random() * 32)];
	return code;
}
function isUnique(error) {
	const text = error instanceof Error ? error.message : String(error);
	return text.includes("unique") || text.includes("23505");
}
var placeOrder_createServerFn_handler = createServerRpc({
	id: "d8c2838f0e5e26cac2dd741775103008e580f254037ef53c1ba429c516c172c8",
	name: "placeOrder",
	filename: "src/lib/comptoir/api.ts"
}, (opts) => placeOrder.__executeServer(opts));
var placeOrder = createServerFn({ method: "POST" }).validator((input) => parse(orderSchema, input)).handler(placeOrder_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const shop = await loadShop(sql);
	const closures = await loadClosures(sql);
	if (!isBookableSlot(shop, closures, data.slotDate, data.slotTime)) throw new Error("Ce créneau n'est plus disponible.");
	const merged = /* @__PURE__ */ new Map();
	for (const line of data.lines) merged.set(line.recipeId, (merged.get(line.recipeId) ?? 0) + line.qty);
	const payload = [...merged.entries()].map(([recipeId, qty]) => ({
		recipeId,
		qty
	}));
	if (payload.some((line) => line.qty > 12)) throw new Error("Quantité trop élevée.");
	const notes = data.notes.join(" · ");
	for (let attempt = 0; attempt < 4; attempt += 1) {
		const code = makeCode();
		try {
			const row = (await sql.query("select * from place_comptoir_order($1::jsonb, $2, $3::date, $4, $5)", [
				JSON.stringify(payload),
				code,
				data.slotDate,
				data.slotTime,
				notes
			]))[0];
			if (!row) throw new Error("La commande n'a pas abouti.");
			if (!flag(row.open_ok)) throw new Error("Le comptoir est fermé ce jour-là.");
			if (!flag(row.recipes_ok) || !flag(row.published_ok)) throw new Error("Un plat n'est plus à la carte.");
			if (!flag(row.stock_ok)) throw new Error(row.short_names ? `Stock insuffisant : ${row.short_names}.` : "Stock insuffisant.");
			if (!flag(row.capacity_ok)) throw new Error("Ce créneau est complet.");
			if (row.order_id == null) throw new Error("La commande n'a pas abouti.");
			return {
				code: row.placed_code,
				totalCents: num(row.total_cents),
				slotDate: data.slotDate,
				slotTime: data.slotTime
			};
		} catch (error) {
			if (isUnique(error) && attempt < 3) continue;
			throw error;
		}
	}
	throw new Error("La commande n'a pas abouti.");
});
var getOrderByCode_createServerFn_handler = createServerRpc({
	id: "ebecdc6f54d177b4d03e54cf515eecdc14a3ddd9524d8be7de817d7d66569c4a",
	name: "getOrderByCode",
	filename: "src/lib/comptoir/api.ts"
}, (opts) => getOrderByCode.__executeServer(opts));
var getOrderByCode = createServerFn({ method: "GET" }).validator((code) => code.trim().toUpperCase()).handler(getOrderByCode_createServerFn_handler, async ({ data: code }) => {
	if (!/^[A-Z0-9-]{4,12}$/.test(code)) return null;
	const rows = await (await getSql()).query(`${ORDER_SQL} where o.code = $1`, [code]);
	const order = rows[0] ? mapOrder(rows[0]) : null;
	if (!order) return null;
	return {
		code: order.code,
		slotDate: order.slotDate,
		slotTime: order.slotTime,
		status: order.status,
		notes: order.notes,
		totalCents: order.totalCents,
		lines: order.lines
	};
});
var loadAtelier_createServerFn_handler = createServerRpc({
	id: "1c3f104ca6b57dc749d47719f76d0513f0e3588e7debf3c32407e8214ee3c40f",
	name: "loadAtelier",
	filename: "src/lib/comptoir/api.ts"
}, (opts) => loadAtelier.__executeServer(opts));
var loadAtelier = createServerFn({ method: "POST" }).validator((input) => parse(object({ pin: pinSchema }), input)).handler(loadAtelier_createServerFn_handler, async ({ data }) => snapshot(await gate(data.pin)));
var setOrderStatus_createServerFn_handler = createServerRpc({
	id: "f9f6ea229a85e66718858196333b50b10f9e54ea258527c3ae487c230eda1819",
	name: "setOrderStatus",
	filename: "src/lib/comptoir/api.ts"
}, (opts) => setOrderStatus.__executeServer(opts));
var setOrderStatus = createServerFn({ method: "POST" }).validator((input) => parse(statusSchema, input)).handler(setOrderStatus_createServerFn_handler, async ({ data }) => {
	const sql = await gate(data.pin);
	if (data.status === "annulee") {
		const row = (await sql.query("select previous, updated from cancel_comptoir_order($1)", [data.id]))[0];
		if (!row || row.previous == null) throw new Error("Commande introuvable.");
		if (num(row.updated) === 0) throw new Error("Cette commande ne peut plus être annulée.");
		return snapshot(sql);
	}
	if (!(await sql`
      update orders
      set status = ${data.status}
      where id = ${data.id}
        and (
          (status = 'recue' and ${data.status} = 'preparation')
          or (status = 'preparation' and ${data.status} = 'prete')
          or (status = 'prete' and ${data.status} = 'retiree')
        )
      returning id
    `).length) throw new Error("Cette commande ne peut pas changer d'étape.");
	return snapshot(sql);
});
var saveStock_createServerFn_handler = createServerRpc({
	id: "c81d0994fd7ad44861641502b3b27bd01a1314497b11aa1318eba7d05da7135b",
	name: "saveStock",
	filename: "src/lib/comptoir/api.ts"
}, (opts) => saveStock.__executeServer(opts));
var saveStock = createServerFn({ method: "POST" }).validator((input) => parse(stockSchema, input)).handler(saveStock_createServerFn_handler, async ({ data }) => {
	const sql = await gate(data.pin);
	const name = clean(data.name, 2, 40, "Nom");
	if (data.id == null) {
		const id = num((await sql`
        insert into stock_items (name, unit, quantity, threshold)
        values (${name}, ${data.unit}, ${data.quantity}, ${data.threshold})
        returning id
      `)[0]?.id);
		if (data.quantity > 0) await sql`insert into stock_moves (stock_item_id, delta, reason) values (${id}, ${data.quantity}, 'Ouverture')`;
		return snapshot(sql);
	}
	const current = await sql`select quantity from stock_items where id = ${data.id}`;
	if (!current[0]) throw new Error("Ingrédient introuvable.");
	await sql`
      update stock_items
      set name = ${name}, unit = ${data.unit}, quantity = ${data.quantity}, threshold = ${data.threshold}
      where id = ${data.id}
    `;
	const delta = data.quantity - num(current[0].quantity);
	if (delta !== 0) await sql`
        insert into stock_moves (stock_item_id, delta, reason)
        values (${data.id}, ${delta}, 'Correction d''inventaire')
      `;
	return snapshot(sql);
});
var adjustStock_createServerFn_handler = createServerRpc({
	id: "f5791dbf59b810d9bdcf0a87dcb2ec280d097cd009c24217e4955b408891b9bb",
	name: "adjustStock",
	filename: "src/lib/comptoir/api.ts"
}, (opts) => adjustStock.__executeServer(opts));
var adjustStock = createServerFn({ method: "POST" }).validator((input) => parse(adjustSchema, input)).handler(adjustStock_createServerFn_handler, async ({ data }) => {
	const sql = await gate(data.pin);
	if (data.delta === 0) throw new Error("Indiquez une quantité.");
	const reason = clean(data.reason.trim() || "Ajustement", 2, 40, "Motif");
	if (!(await sql.query(`with upd as (
         update stock_items
         set quantity = quantity + $2
         where id = $1 and quantity + $2 >= 0
         returning id
       )
       insert into stock_moves (stock_item_id, delta, reason)
       select id, $2, $3 from upd
       returning stock_item_id as id`, [
		data.id,
		data.delta,
		reason
	])).length) throw new Error("Ajustement impossible.");
	return snapshot(sql);
});
var deleteStock_createServerFn_handler = createServerRpc({
	id: "726e8d662e444a2fbd68f27350c582e1b76e5d66d82fe7f49bcf845183737dec",
	name: "deleteStock",
	filename: "src/lib/comptoir/api.ts"
}, (opts) => deleteStock.__executeServer(opts));
var deleteStock = createServerFn({ method: "POST" }).validator((input) => parse(idSchema, input)).handler(deleteStock_createServerFn_handler, async ({ data }) => {
	const sql = await gate(data.pin);
	const row = (await sql`
      select
        exists(select 1 from stock_items where id = ${data.id}) as present,
        exists(select 1 from recipe_lines where stock_item_id = ${data.id}) as in_recipe,
        exists(select 1 from order_stock where stock_item_id = ${data.id}) as in_order
    `)[0];
	if (!row || !flag(row.present)) throw new Error("Ingrédient introuvable.");
	if (flag(row.in_recipe) || flag(row.in_order)) throw new Error("Cet ingrédient est encore utilisé.");
	await sql`delete from stock_items where id = ${data.id}`;
	return snapshot(sql);
});
var saveRecipe_createServerFn_handler = createServerRpc({
	id: "aefddfbc03a7439c4b1ebb60bdd189429da3e213da2f6cab79819b4ef52b0112",
	name: "saveRecipe",
	filename: "src/lib/comptoir/api.ts"
}, (opts) => saveRecipe.__executeServer(opts));
var saveRecipe = createServerFn({ method: "POST" }).validator((input) => parse(recipeSchema, input)).handler(saveRecipe_createServerFn_handler, async ({ data }) => {
	const sql = await gate(data.pin);
	const name = clean(data.name, 2, 60, "Nom");
	const description = clean(data.description, 0, 180, "Description");
	const category = clean(data.category, 2, 24, "Catégorie");
	if (data.image !== "" && !DISH_KEYS.includes(data.image)) throw new Error("Photo inconnue.");
	const merged = /* @__PURE__ */ new Map();
	for (const line of data.lines) merged.set(line.stockItemId, (merged.get(line.stockItemId) ?? 0) + line.quantity);
	const lines = [...merged.entries()].map(([stockItemId, quantity]) => ({
		stockItemId,
		quantity
	}));
	if (lines.length) {
		const ids = lines.map((line) => line.stockItemId);
		if ((await sql.query("select id from stock_items where id = any($1::int[])", [ids])).length !== ids.length) throw new Error("Ingrédient inconnu.");
	}
	let recipeId = data.id;
	if (recipeId == null) {
		const maxRow = await sql`select coalesce(max(sort_order), 0)::int as max from recipes`;
		recipeId = num((await sql`
        insert into recipes (name, description, category, price_cents, prep_minutes, published, image, sort_order)
        values (
          ${name}, ${description}, ${category}, ${data.priceCents}, ${data.prepMinutes},
          ${data.published}, ${data.image}, ${num(maxRow[0]?.max) + 1}
        )
        returning id
      `)[0]?.id);
	} else {
		if (!(await sql`
        update recipes
        set name = ${name}, description = ${description}, category = ${category},
            price_cents = ${data.priceCents}, prep_minutes = ${data.prepMinutes},
            published = ${data.published}, image = ${data.image}
        where id = ${recipeId}
        returning id
      `).length) throw new Error("Recette introuvable.");
		await sql`delete from recipe_lines where recipe_id = ${recipeId}`;
	}
	for (const line of lines) await sql`
        insert into recipe_lines (recipe_id, stock_item_id, quantity)
        values (${recipeId}, ${line.stockItemId}, ${line.quantity})
      `;
	return snapshot(sql);
});
var deleteRecipe_createServerFn_handler = createServerRpc({
	id: "5e6a2873021f6d4c13f6d6ba1c47d160104a0b7a915fc683d1713d528a9e1d9f",
	name: "deleteRecipe",
	filename: "src/lib/comptoir/api.ts"
}, (opts) => deleteRecipe.__executeServer(opts));
var deleteRecipe = createServerFn({ method: "POST" }).validator((input) => parse(idSchema, input)).handler(deleteRecipe_createServerFn_handler, async ({ data }) => {
	const sql = await gate(data.pin);
	if (!(await sql`delete from recipes where id = ${data.id} returning id`).length) throw new Error("Recette introuvable.");
	return snapshot(sql);
});
var moveRecipe_createServerFn_handler = createServerRpc({
	id: "9d1e5dae6b6d6c18aebf39a69b509f04478e154cd6fbab412a5fdde5ac7b0371",
	name: "moveRecipe",
	filename: "src/lib/comptoir/api.ts"
}, (opts) => moveRecipe.__executeServer(opts));
var moveRecipe = createServerFn({ method: "POST" }).validator((input) => parse(moveSchema, input)).handler(moveRecipe_createServerFn_handler, async ({ data }) => {
	const sql = await gate(data.pin);
	const ids = (await sql`select id from recipes order by sort_order, id`).map((row) => num(row.id));
	const index = ids.indexOf(data.id);
	const target = index + data.direction;
	if (index < 0 || target < 0 || target >= ids.length) return snapshot(sql);
	const [current] = ids.splice(index, 1);
	ids.splice(target, 0, current);
	for (let position = 0; position < ids.length; position += 1) await sql`update recipes set sort_order = ${position + 1} where id = ${ids[position]}`;
	return snapshot(sql);
});
var saveShop_createServerFn_handler = createServerRpc({
	id: "94138967321fc98d54ac4489dc6e998c90aa1f07eab91a5ba486d2b2c3b68ba8",
	name: "saveShop",
	filename: "src/lib/comptoir/api.ts"
}, (opts) => saveShop.__executeServer(opts));
var saveShop = createServerFn({ method: "POST" }).validator((input) => parse(shopSchema, input)).handler(saveShop_createServerFn_handler, async ({ data }) => {
	const sql = await gate(data.pin);
	const name = clean(data.name, 2, 48, "Nom");
	const tagline = clean(data.tagline, 0, 140, "Phrase");
	const announcement = clean(data.announcement, 0, 180, "Annonce");
	const address = clean(data.address, 0, 80, "Adresse");
	if (!validTime(data.openTime) || !validTime(data.closeTime)) throw new Error("Horaires invalides.");
	if (toMinutes(data.openTime) >= toMinutes(data.closeTime)) throw new Error("Le premier service est invalide.");
	const eveningOpen = data.eveningOpen.trim();
	const eveningClose = data.eveningClose.trim();
	let eveningStart = null;
	let eveningEnd = null;
	if (eveningOpen || eveningClose) {
		if (!validTime(eveningOpen) || !validTime(eveningClose)) throw new Error("Le second service est incomplet.");
		if (toMinutes(eveningOpen) < toMinutes(data.closeTime)) throw new Error("Les services se chevauchent.");
		if (toMinutes(eveningOpen) >= toMinutes(eveningClose)) throw new Error("Le second service est invalide.");
		eveningStart = eveningOpen;
		eveningEnd = eveningClose;
	}
	const closedDows = [...new Set(data.closedDows)].sort((a, b) => a - b);
	if (closedDows.length >= 7) throw new Error("Ouvrez au moins un jour.");
	if (data.newPin !== "" && !/^\d{4}$/.test(data.newPin)) throw new Error("Le nouveau code doit comporter 4 chiffres.");
	await sql`
      update shop set
        name = ${name},
        tagline = ${tagline},
        announcement = ${announcement},
        address = ${address},
        open_time = ${data.openTime},
        close_time = ${data.closeTime},
        evening_open = ${eveningStart},
        evening_close = ${eveningEnd},
        slot_minutes = ${data.slotMinutes},
        slot_capacity = ${data.slotCapacity},
        closed_dows = ${closedDows.join(",")},
        pin_code = case when ${data.newPin} = '' then pin_code else ${data.newPin} end
      where id = 1
    `;
	return snapshot(sql);
});
var setClosure_createServerFn_handler = createServerRpc({
	id: "13826f8d8846bc7a8aa32086aeabb637d0396bbc6c8e1c00ed63921925561a2e",
	name: "setClosure",
	filename: "src/lib/comptoir/api.ts"
}, (opts) => setClosure.__executeServer(opts));
var setClosure = createServerFn({ method: "POST" }).validator((input) => parse(closureSchema, input)).handler(setClosure_createServerFn_handler, async ({ data }) => {
	const sql = await gate(data.pin);
	if (data.closed) await sql`insert into closures (day) values (${data.date}::date) on conflict (day) do nothing`;
	else await sql`delete from closures where day = ${data.date}::date`;
	return snapshot(sql);
});
//#endregion
export { adjustStock_createServerFn_handler, deleteRecipe_createServerFn_handler, deleteStock_createServerFn_handler, getLockState_createServerFn_handler, getOrderByCode_createServerFn_handler, getSlots_createServerFn_handler, getStorefront_createServerFn_handler, loadAtelier_createServerFn_handler, moveRecipe_createServerFn_handler, placeOrder_createServerFn_handler, saveRecipe_createServerFn_handler, saveShop_createServerFn_handler, saveStock_createServerFn_handler, setClosure_createServerFn_handler, setOrderStatus_createServerFn_handler };
