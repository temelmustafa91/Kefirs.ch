import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as useNavigate, x as useRouter, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as formatEUR, r as STATUS_LABEL, u as formatDay } from "./format-DcnPm31r.mjs";
import { c as Copy } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Route } from "./router-CWnMlBKp.mjs";
import { n as cn, t as Button } from "./button-CqtuPLNw.mjs";
import { t as StatusPill } from "./status-pill-qsbi7zOd.mjs";
import { t as SiteHeader } from "./site-header-DlMehv2p.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/suivi-Bb7dvLTw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STEPS = [
	"recue",
	"preparation",
	"prete",
	"retiree"
];
function SuiviPage() {
	const order = Route.useLoaderData();
	const { code } = Route.useSearch();
	const navigate = useNavigate();
	const router = useRouter();
	const [draft, setDraft] = (0, import_react.useState)(code);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-xl px-4 py-8",
		children: [order ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Code de retrait"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-5xl tracking-tight",
					children: order.code
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-11 place-items-center rounded-lg hover:bg-secondary",
					"aria-label": "Copier le code",
					onClick: () => {
						navigator.clipboard.writeText(order.code).then(() => toast.success("Code copié"), () => toast.error("Copie impossible"));
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted-foreground",
				children: "À présenter au comptoir."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6 text-lg",
				children: [
					formatDay(order.slotDate),
					" · ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: order.slotTime
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: order.status })
			}),
			order.status === "annulee" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm text-muted-foreground",
				children: "Cette commande a été annulée. Le stock a été recrédité."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-6 space-y-3",
				children: STEPS.map((step, index) => {
					const done = STEPS.indexOf(order.status) >= index;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2.5 rounded-full", done ? "bg-foreground" : "bg-border") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: done ? "text-foreground" : "text-muted-foreground",
							children: STATUS_LABEL[step]
						})]
					}, step);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-8 space-y-2 border-t border-border pt-4 text-sm",
				children: order.lines.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						line.qty,
						" × ",
						line.name
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: formatEUR(line.qty * line.unitCents)
					})]
				}, `${line.name}-${index}`))
			}),
			order.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted-foreground",
				children: order.notes
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-lg font-medium tabular-nums",
				children: formatEUR(order.totalCents)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => void router.invalidate(),
					children: "Actualiser"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "inline-flex h-11 items-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground",
					children: "Nouvelle commande"
				})]
			})
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl tracking-tight",
			children: "Suivre une commande"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-muted-foreground",
			children: code ? "Aucune commande ne correspond à ce code." : "Entrez le code remis au moment de la commande."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-10 flex gap-2",
			onSubmit: (event) => {
				event.preventDefault();
				const next = draft.trim().toUpperCase();
				if (next) navigate({
					to: "/suivi",
					search: { code: next }
				});
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: draft,
				onChange: (event) => setDraft(event.target.value.toUpperCase()),
				"aria-label": "Code de commande",
				className: "h-11 min-w-0 flex-1 rounded-lg border border-border bg-card px-3 text-base uppercase outline-none focus-visible:ring-2 focus-visible:ring-ring"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				children: "Voir"
			})]
		})]
	})] });
}
//#endregion
export { SuiviPage as component };
