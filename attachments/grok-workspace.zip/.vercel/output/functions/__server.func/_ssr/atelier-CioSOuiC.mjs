import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { C as utcDate, _ as messageOf, a as addDays, b as slotTimes, c as dowOf, d as formatEUR, f as formatIso, h as hoursLabel, i as UNITS, l as eurosInput, p as formatQty, s as dishSrc, t as DISH_KEYS, u as formatDay, w as weekStart, y as parseEuros } from "./format-DcnPm31r.mjs";
import { a as Minus, d as ChevronRight, f as ChevronLeft, h as BookOpen, i as Plus, m as Boxes, p as CalendarRange, r as Settings, s as LayoutDashboard, u as ClipboardList } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { _ as setOrderStatus, a as adjustStock, c as getLockState, d as moveRecipe, g as setClosure, h as saveStock, m as saveShop, o as deleteRecipe, p as saveRecipe, r as Route$1, s as deleteStock, u as loadAtelier } from "./router-CWnMlBKp.mjs";
import { n as cn, t as Button } from "./button-CqtuPLNw.mjs";
import { t as StatusPill } from "./status-pill-qsbi7zOd.mjs";
import { t as Modal } from "./modal-D5EsdU5u.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/atelier-CioSOuiC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var fieldClass = "h-11 w-full rounded-lg border border-border bg-card px-3 text-base text-foreground outline-none placeholder:text-muted-foreground focus-visible:ring-2 focus-visible:ring-ring";
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("text-sm font-medium", className),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn(fieldClass, className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn(fieldClass, "h-auto min-h-24 py-3", className),
		...props
	});
}
function Select({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		className: cn(fieldClass, className),
		...props
	});
}
function SectionTitle({ title, detail }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [detail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground",
		children: detail
	}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "font-display text-2xl tracking-tight",
		children: title
	})] });
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "lift rounded-3xl bg-card p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 font-display text-3xl tabular-nums tracking-tight",
			children: value
		})]
	});
}
var FILTERS = [
	{
		id: "toutes",
		label: "Toutes"
	},
	{
		id: "recue",
		label: "Reçues"
	},
	{
		id: "preparation",
		label: "En préparation"
	},
	{
		id: "prete",
		label: "Prêtes"
	},
	{
		id: "retiree",
		label: "Retirées"
	},
	{
		id: "annulee",
		label: "Annulées"
	}
];
function nextStep(status) {
	if (status === "recue") return {
		status: "preparation",
		label: "Lancer la préparation"
	};
	if (status === "preparation") return {
		status: "prete",
		label: "Marquer prête"
	};
	if (status === "prete") return {
		status: "retiree",
		label: "Marquer retirée"
	};
	return null;
}
function OrderActions({ order, pin, busy, run }) {
	const [armed, setArmed] = (0, import_react.useState)(false);
	const next = nextStep(order.status);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap gap-2",
		children: [next ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			disabled: busy,
			onClick: () => void run(() => setOrderStatus({ data: {
				pin,
				id: order.id,
				status: next.status
			} })),
			children: next.label
		}) : null, order.status !== "retiree" && order.status !== "annulee" ? armed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "outline",
			disabled: busy,
			onClick: () => void run(() => setOrderStatus({ data: {
				pin,
				id: order.id,
				status: "annulee"
			} })),
			children: "Confirmer l'annulation"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			disabled: busy,
			onClick: () => setArmed(true),
			children: "Annuler"
		}) : null]
	});
}
function OrdersView({ data, pin, busy, run }) {
	const [filter, setFilter] = (0, import_react.useState)("toutes");
	const [query, setQuery] = (0, import_react.useState)("");
	const orders = data.orders.filter((order) => {
		if (filter !== "toutes" && order.status !== filter) return false;
		if (query && !order.code.toLowerCase().includes(query.trim().toLowerCase())) return false;
		return true;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
			title: "Commandes",
			detail: "Le code tient lieu de ticket"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value: query,
			onChange: (event) => setQuery(event.target.value.toUpperCase()),
			placeholder: "Rechercher un code",
			"aria-label": "Rechercher un code",
			className: "mt-4 h-11 w-full rounded-lg border border-border bg-card px-3 text-base uppercase outline-none focus-visible:ring-2 focus-visible:ring-ring"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "scroll-x mt-3 flex gap-2",
			children: FILTERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setFilter(item.id),
				className: cn("h-11 shrink-0 rounded-full px-4 text-sm", filter === item.id ? "bg-primary text-primary-foreground" : "bg-secondary"),
				children: item.label
			}, item.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "mt-4 space-y-3",
			children: [orders.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "text-sm text-muted-foreground",
				children: "Aucune commande."
			}) : null, orders.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "lift rounded-3xl bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl",
							children: order.code
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground",
							children: [
								formatDay(order.slotDate),
								" · ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums",
									children: order.slotTime
								}),
								order.createdLabel ? ` · ${order.createdLabel}` : ""
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: order.status })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-1 text-sm",
						children: order.lines.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								line.qty,
								" × ",
								line.name
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: formatEUR(line.qty * line.unitCents)
							})]
						}, `${line.name}-${index}`))
					}),
					order.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: order.notes
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium tabular-nums",
							children: formatEUR(order.totalCents)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderActions, {
							order,
							pin,
							busy,
							run
						})]
					})
				]
			}, order.id))]
		})
	] });
}
function PlanningView(props) {
	const { data, pin, busy, run } = props;
	const [anchor, setAnchor] = (0, import_react.useState)(data.today);
	const [selected, setSelected] = (0, import_react.useState)(data.today);
	const start = weekStart(anchor);
	const days = Array.from({ length: 7 }, (_, index) => formatIso(addDays(utcDate(start), index)));
	const closedWeekday = data.shop.closedDows.includes(dowOf(selected));
	const closedDate = data.closures.includes(selected);
	const closed = closedWeekday || closedDate;
	const times = slotTimes(data.shop);
	const dayOrders = data.orders.filter((order) => order.slotDate === selected && order.status !== "annulee").sort((a, b) => a.slotTime.localeCompare(b.slotTime));
	const production = productionFor(data.orders.filter((order) => order.slotDate === selected && (order.status === "recue" || order.status === "preparation")));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				title: "Planning",
				detail: "Capacité par créneau"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "icon",
					"aria-label": "Semaine précédente",
					onClick: () => setAnchor(formatIso(addDays(utcDate(start), -7))),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "icon",
					"aria-label": "Semaine suivante",
					onClick: () => setAnchor(formatIso(addDays(utcDate(start), 7))),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid grid-cols-7 gap-1",
			children: days.map((date) => {
				const dayClosed = data.shop.closedDows.includes(dowOf(date)) || data.closures.includes(date);
				const count = data.orders.filter((order) => order.slotDate === date && order.status !== "annulee").length;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setSelected(date),
					className: cn("flex h-14 flex-col items-center justify-center rounded-lg text-sm", selected === date ? "bg-primary text-primary-foreground" : "bg-secondary", dayClosed && selected !== date && "text-muted-foreground"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: date.slice(8)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs",
						children: count || (dayClosed ? "—" : "")
					})]
				}, date);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-xl capitalize",
				children: formatDay(selected)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				disabled: busy || closedWeekday,
				onClick: () => void run(() => setClosure({ data: {
					pin,
					date: selected,
					closed: !closedDate
				} })),
				children: closedDate ? "Rouvrir ce jour" : "Fermer ce jour"
			})]
		}),
		closed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-muted-foreground",
			children: closedWeekday ? "Jour habituellement fermé." : "Fermé aux nouvelles commandes. Celles déjà prises restent à préparer."
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 space-y-4",
			children: times.map((time) => {
				const at = dayOrders.filter((order) => order.slotTime === time);
				const portions = at.reduce((sum, order) => sum + order.lines.reduce((inner, line) => inner + line.qty, 0), 0);
				const pct = Math.min(100, Math.round(portions / Math.max(1, data.shop.slotCapacity) * 100));
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums font-medium",
							children: time
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums text-muted-foreground",
							children: [
								portions,
								"/",
								data.shop.slotCapacity
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 h-1 overflow-hidden rounded-full bg-secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-foreground",
							style: { width: `${pct}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 space-y-2",
						children: at.map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-xl bg-card p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-baseline justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: order.code
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: order.lines.map((line) => `${line.qty} × ${line.name}`).join(", ")
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderActions, {
									order,
									pin,
									busy,
									run
								})
							})]
						}, order.id))
					})
				] }, time);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-xl",
					children: "À produire"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Ingrédients des commandes reçues ou en préparation."
				}),
				production.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted-foreground",
					children: "Rien à produire pour ce jour."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-border",
					children: production.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between gap-3 py-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums",
							children: [
								item.quantity,
								" ",
								item.unit
							]
						})]
					}, `${item.name}-${item.unit}`))
				})
			]
		})
	] });
}
function productionFor(orders) {
	const map = /* @__PURE__ */ new Map();
	for (const order of orders) for (const use of order.stockUse) {
		const key = `${use.name}-${use.unit}`;
		const prev = map.get(key);
		if (prev) prev.quantity += use.quantity;
		else map.set(key, { ...use });
	}
	return [...map.values()].sort((a, b) => b.quantity - a.quantity);
}
function RecipesView({ data, pin, busy, run }) {
	const [draft, setDraft] = (0, import_react.useState)(null);
	const paid = data.series.reduce((sum, point) => sum + point.paidCents, 0);
	const booked = data.series.reduce((sum, point) => sum + point.bookedCents, 0);
	function openRecipe(recipe) {
		const first = data.stock[0]?.id ?? 0;
		setDraft(recipe ? {
			id: recipe.id,
			name: recipe.name,
			description: recipe.description,
			category: recipe.category,
			price: eurosInput(recipe.priceCents),
			prepMinutes: String(recipe.prepMinutes),
			published: recipe.published,
			image: recipe.image,
			lines: recipe.lines.map((line) => ({
				stockItemId: line.stockItemId,
				quantity: String(line.quantity)
			}))
		} : {
			id: null,
			name: "",
			description: "",
			category: "Plat",
			price: "",
			prepMinutes: "15",
			published: true,
			image: "",
			lines: first ? [{
				stockItemId: first,
				quantity: "1"
			}] : []
		});
	}
	async function save() {
		if (!draft) return;
		const priceCents = parseEuros(draft.price);
		const prepMinutes = Number(draft.prepMinutes);
		if (priceCents == null) {
			toast.error("Prix invalide.");
			return;
		}
		if (!Number.isInteger(prepMinutes) || prepMinutes < 0) {
			toast.error("Temps de préparation invalide.");
			return;
		}
		const lines = draft.lines.map((line) => ({
			stockItemId: line.stockItemId,
			quantity: Number(line.quantity)
		}));
		if (lines.some((line) => !Number.isInteger(line.quantity) || line.quantity < 1)) {
			toast.error("Quantité d'ingrédient invalide.");
			return;
		}
		try {
			if (!await run(() => saveRecipe({ data: {
				pin,
				id: draft.id,
				name: draft.name,
				description: draft.description,
				category: draft.category,
				priceCents,
				prepMinutes,
				published: draft.published,
				image: draft.image,
				lines
			} }))) return;
			setDraft(null);
			toast.success("Recette enregistrée");
		} catch {}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "lift rounded-3xl bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl tracking-tight",
						children: "Recettes encaissées"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "Sur 7 jours, commandes retirées. L'engagé inclut ce qui n'est pas encore passé au comptoir."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm text-muted-foreground",
							children: "Encaissé"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-3xl tabular-nums",
							children: formatEUR(paid)
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm text-muted-foreground",
							children: "Engagé"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-3xl tabular-nums",
							children: formatEUR(booked)
						})] })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
					title: "Fiches techniques",
					detail: "Ce qui part en cuisine et à la carte"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => openRecipe(),
					children: "Ajouter"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-3",
				children: data.recipes.map((recipe, index) => {
					const src = dishSrc(recipe.image);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "lift flex gap-3 rounded-3xl bg-card p-3",
						children: [src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src,
							alt: "",
							className: "h-20 w-24 shrink-0 rounded-xl object-cover"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-20 w-24 shrink-0 place-items-center rounded-xl bg-secondary text-sm text-muted-foreground",
							children: recipe.category
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-start justify-between gap-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-xl",
										children: recipe.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted-foreground",
										children: [
											recipe.category,
											" · ",
											formatEUR(recipe.priceCents),
											" · ",
											recipe.published ? "À la carte" : "Masquée"
										]
									})] })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted-foreground",
									children: recipe.lines.length ? recipe.lines.map((line) => `${line.quantity} ${line.unit} ${line.name}`).join(" · ") : "Sans ingrédient lié"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex flex-wrap gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											onClick: () => openRecipe(recipe),
											children: "Modifier"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											disabled: busy || index === 0,
											onClick: () => void run(() => moveRecipe({ data: {
												pin,
												id: recipe.id,
												direction: -1
											} })),
											children: "Monter"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											disabled: busy || index === data.recipes.length - 1,
											onClick: () => void run(() => moveRecipe({ data: {
												pin,
												id: recipe.id,
												direction: 1
											} })),
											children: "Descendre"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "ghost",
											disabled: busy,
											onClick: () => void run(() => deleteRecipe({ data: {
												pin,
												id: recipe.id
											} })),
											children: "Retirer"
										})
									]
								})
							]
						})]
					}, recipe.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
				open: draft != null,
				onOpenChange: (next) => !next && setDraft(null),
				title: draft?.id ? "Recette" : "Nouvelle recette",
				children: draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "space-y-3",
					onSubmit: (event) => {
						event.preventDefault();
						save();
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "recipe-name",
							children: "Nom"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "recipe-name",
							className: "mt-1",
							value: draft.name,
							onChange: (event) => setDraft({
								...draft,
								name: event.target.value
							})
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "recipe-category",
								children: "Catégorie"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "recipe-category",
								className: "mt-1",
								list: "recipe-categories",
								value: draft.category,
								onChange: (event) => setDraft({
									...draft,
									category: event.target.value
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
								id: "recipe-categories",
								children: [
									"Entrée",
									"Soupe",
									"Tarte",
									"Plat",
									"Cake",
									"Dessert"
								].map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: category }, category))
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "recipe-description",
							children: "Description"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "recipe-description",
							className: "mt-1",
							value: draft.description,
							onChange: (event) => setDraft({
								...draft,
								description: event.target.value
							})
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "recipe-price",
								children: "Prix (€)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "recipe-price",
								className: "mt-1",
								inputMode: "decimal",
								value: draft.price,
								onChange: (event) => setDraft({
									...draft,
									price: event.target.value
								})
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "recipe-prep",
								children: "Préparation (min)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "recipe-prep",
								className: "mt-1",
								inputMode: "numeric",
								value: draft.prepMinutes,
								onChange: (event) => setDraft({
									...draft,
									prepMinutes: event.target.value
								})
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "switch",
							"aria-checked": draft.published,
							onClick: () => setDraft({
								...draft,
								published: !draft.published
							}),
							className: cn("h-11 rounded-lg px-4 text-sm", draft.published ? "bg-primary text-primary-foreground" : "bg-secondary"),
							children: draft.published ? "À la carte" : "Masquée"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "scroll-x flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setDraft({
									...draft,
									image: ""
								}),
								className: cn("h-16 shrink-0 rounded-lg px-3 text-sm", draft.image === "" ? "bg-primary text-primary-foreground" : "bg-secondary"),
								children: "Sans photo"
							}), DISH_KEYS.map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": key,
								onClick: () => setDraft({
									...draft,
									image: key
								}),
								className: cn("h-16 w-20 shrink-0 overflow-hidden rounded-lg", draft.image === key && "ring-2 ring-ring"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: dishSrc(key) ?? "",
									alt: "",
									className: "h-full w-full object-cover"
								})
							}, key))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [draft.lines.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
										"aria-label": "Ingrédient",
										value: line.stockItemId,
										onChange: (event) => {
											const lines = draft.lines.slice();
											lines[index] = {
												...line,
												stockItemId: Number(event.target.value)
											};
											setDraft({
												...draft,
												lines
											});
										},
										children: data.stock.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
											value: item.id,
											children: [
												item.name,
												" (",
												item.unit,
												")"
											]
										}, item.id))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										"aria-label": "Quantité pour une portion",
										className: "w-24",
										inputMode: "numeric",
										value: line.quantity,
										onChange: (event) => {
											const lines = draft.lines.slice();
											lines[index] = {
												...line,
												quantity: event.target.value
											};
											setDraft({
												...draft,
												lines
											});
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "outline",
										size: "icon",
										"aria-label": "Retirer l'ingrédient",
										onClick: () => setDraft({
											...draft,
											lines: draft.lines.filter((_, lineIndex) => lineIndex !== index)
										}),
										children: "–"
									})
								]
							}, index)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								disabled: data.stock.length === 0,
								onClick: () => setDraft({
									...draft,
									lines: [...draft.lines, {
										stockItemId: data.stock[0]?.id ?? 0,
										quantity: "1"
									}]
								}),
								children: "Ajouter un ingrédient"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							className: "w-full",
							disabled: busy,
							children: "Enregistrer"
						})
					]
				}) : null
			})
		]
	});
}
var DAYS = [
	{
		id: 1,
		label: "Lundi"
	},
	{
		id: 2,
		label: "Mardi"
	},
	{
		id: 3,
		label: "Mercredi"
	},
	{
		id: 4,
		label: "Jeudi"
	},
	{
		id: 5,
		label: "Vendredi"
	},
	{
		id: 6,
		label: "Samedi"
	},
	{
		id: 0,
		label: "Dimanche"
	}
];
function SettingsView({ data, pin, busy, run, onPin }) {
	const shop = data.shop;
	const [name, setName] = (0, import_react.useState)(shop.name);
	const [tagline, setTagline] = (0, import_react.useState)(shop.tagline);
	const [announcement, setAnnouncement] = (0, import_react.useState)(shop.announcement);
	const [address, setAddress] = (0, import_react.useState)(shop.address);
	const [openTime, setOpenTime] = (0, import_react.useState)(shop.openTime);
	const [closeTime, setCloseTime] = (0, import_react.useState)(shop.closeTime);
	const [evening, setEvening] = (0, import_react.useState)(Boolean(shop.eveningOpen && shop.eveningClose));
	const [eveningOpen, setEveningOpen] = (0, import_react.useState)(shop.eveningOpen ?? "18:00");
	const [eveningClose, setEveningClose] = (0, import_react.useState)(shop.eveningClose ?? "20:30");
	const [slotMinutes, setSlotMinutes] = (0, import_react.useState)(shop.slotMinutes);
	const [slotCapacity, setSlotCapacity] = (0, import_react.useState)(String(shop.slotCapacity));
	const [openDays, setOpenDays] = (0, import_react.useState)(DAYS.map((day) => day.id).filter((day) => !shop.closedDows.includes(day)));
	const [newPin, setNewPin] = (0, import_react.useState)("");
	const [confirmPin, setConfirmPin] = (0, import_react.useState)("");
	const preview = hoursLabel({
		openTime,
		closeTime,
		eveningOpen: evening ? eveningOpen : null,
		eveningClose: evening ? eveningClose : null,
		slotMinutes,
		closedDows: DAYS.map((day) => day.id).filter((day) => !openDays.includes(day))
	});
	async function save() {
		if (newPin !== confirmPin) {
			toast.error("Les codes ne correspondent pas.");
			return;
		}
		const capacity = Number(slotCapacity);
		if (!Number.isInteger(capacity)) {
			toast.error("Capacité invalide.");
			return;
		}
		const minutes = slotMinutes === 15 || slotMinutes === 60 ? slotMinutes : 30;
		try {
			if (!await run(() => saveShop({ data: {
				pin,
				name,
				tagline,
				announcement,
				address,
				openTime,
				closeTime,
				eveningOpen: evening ? eveningOpen : "",
				eveningClose: evening ? eveningClose : "",
				slotMinutes: minutes,
				slotCapacity: capacity,
				closedDows: DAYS.map((day) => day.id).filter((day) => !openDays.includes(day)),
				newPin
			} }))) return;
			if (newPin) onPin(newPin);
			setNewPin("");
			setConfirmPin("");
			toast.success("Application mise à jour");
		} catch {}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "space-y-4",
		onSubmit: (event) => {
			event.preventDefault();
			save();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				title: "Application",
				detail: "Ce que voient les clients, et le code de l'atelier"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Comptoir est la seule porte de commande. Le nom, les horaires et l'annonce se règlent ici."
			}),
			data.shop.demoLock ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-warn",
				children: "Le code de départ 4820 est encore actif."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Nom du comptoir",
				value: name,
				onChange: setName
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Phrase",
				value: tagline,
				onChange: setTagline
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor: "announcement",
				children: "Annonce"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				id: "announcement",
				className: "mt-1",
				value: announcement,
				onChange: (event) => setAnnouncement(event.target.value)
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Adresse",
				value: address,
				onChange: setAddress
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimeField, {
					label: "Ouverture",
					value: openTime,
					onChange: setOpenTime
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimeField, {
					label: "Fermeture",
					value: closeTime,
					onChange: setCloseTime
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				role: "switch",
				"aria-checked": evening,
				onClick: () => setEvening((value) => !value),
				className: "h-11 rounded-lg bg-secondary px-4 text-sm",
				children: evening ? "Second service actif" : "Ajouter un second service"
			}),
			evening ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimeField, {
					label: "Second service",
					value: eveningOpen,
					onChange: setEveningOpen
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimeField, {
					label: "Fin",
					value: eveningClose,
					onChange: setEveningClose
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "slot",
					children: "Créneau"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					id: "slot",
					className: "mt-1",
					value: String(slotMinutes),
					onChange: (event) => setSlotMinutes(Number(event.target.value)),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "15",
							children: "15 min"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "30",
							children: "30 min"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "60",
							children: "60 min"
						})
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "capacity",
					children: "Portions par créneau"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "capacity",
					className: "mt-1",
					inputMode: "numeric",
					value: slotCapacity,
					onChange: (event) => setSlotCapacity(event.target.value)
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
				className: "text-sm font-medium",
				children: "Jours d'ouverture"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 grid grid-cols-2 gap-2",
				children: DAYS.map((day) => {
					const checked = openDays.includes(day.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex h-11 items-center gap-2 rounded-lg bg-secondary px-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked,
							onChange: () => setOpenDays((current) => checked ? current.filter((id) => id !== day.id) : [...current, day.id])
						}), day.label]
					}, day.id);
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: ["Les clients verront : ", preview]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "new-pin",
					children: "Nouveau code"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "new-pin",
					className: "mt-1",
					inputMode: "numeric",
					maxLength: 4,
					value: newPin,
					onChange: (event) => setNewPin(event.target.value)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "confirm-pin",
					children: "Confirmer"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "confirm-pin",
					className: "mt-1",
					inputMode: "numeric",
					maxLength: 4,
					value: confirmPin,
					onChange: (event) => setConfirmPin(event.target.value)
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				disabled: busy,
				children: "Enregistrer"
			})
		]
	});
}
function Field({ label, value, onChange }) {
	const id = label.replace(/\s+/g, "-").toLowerCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
		htmlFor: id,
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
		id,
		className: "mt-1",
		value,
		onChange: (event) => onChange(event.target.value)
	})] });
}
function TimeField({ label, value, onChange }) {
	const id = label.replace(/\s+/g, "-").toLowerCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
		htmlFor: id,
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
		id,
		className: "mt-1",
		type: "time",
		value,
		onChange: (event) => onChange(event.target.value)
	})] });
}
var empty = {
	id: null,
	name: "",
	unit: "g",
	quantity: "0",
	threshold: "0"
};
function StockView({ data, pin, busy, run }) {
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [armed, setArmed] = (0, import_react.useState)(null);
	function openItem(item) {
		setDraft(item ? {
			id: item.id,
			name: item.name,
			unit: UNITS.includes(item.unit) ? item.unit : "g",
			quantity: String(item.quantity),
			threshold: String(item.threshold)
		} : empty);
	}
	async function save() {
		if (!draft) return;
		const quantity = Number(draft.quantity);
		const threshold = Number(draft.threshold);
		if (!Number.isInteger(quantity) || quantity < 0 || !Number.isInteger(threshold) || threshold < 0) {
			toast.error("Quantités invalides.");
			return;
		}
		try {
			if (!await run(() => saveStock({ data: {
				pin,
				id: draft.id,
				name: draft.name,
				unit: draft.unit,
				quantity,
				threshold
			} }))) return;
			setDraft(null);
			toast.success("Stock enregistré");
		} catch {}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				title: "Stocks",
				detail: "Ingrédients et seuils"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => openItem(),
				children: "Ajouter"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 divide-y divide-border",
			children: data.stock.map((item) => {
				const low = item.quantity <= item.threshold;
				const scale = Math.max(item.threshold * 2, item.quantity, 1);
				const pct = Math.min(100, Math.round(item.quantity / scale * 100));
				const step = item.unit === "pièce" ? 1 : 50;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: item.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: low ? "text-sm text-destructive tabular-nums" : "text-sm text-muted-foreground tabular-nums",
								children: [
									formatQty(item.quantity),
									" ",
									item.unit,
									" · seuil ",
									formatQty(item.threshold)
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "icon",
									"aria-label": `Retirer ${step} ${item.unit}`,
									disabled: busy,
									onClick: () => void run(() => adjustStock({ data: {
										pin,
										id: item.id,
										delta: -step,
										reason: "Ajustement"
									} })),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "icon",
									"aria-label": `Ajouter ${step} ${item.unit}`,
									disabled: busy,
									onClick: () => void run(() => adjustStock({ data: {
										pin,
										id: item.id,
										delta: step,
										reason: "Ajustement"
									} })),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 h-1 overflow-hidden rounded-full bg-secondary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: low ? "h-full bg-destructive" : "h-full bg-foreground",
								style: { width: `${pct}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => openItem(item),
								children: "Modifier"
							}), armed === item.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								disabled: busy,
								onClick: () => void run(() => deleteStock({ data: {
									pin,
									id: item.id
								} })).then((ok) => {
									if (ok) setArmed(null);
								}),
								children: "Confirmer"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: () => setArmed(item.id),
								children: "Retirer"
							})]
						})
					]
				}, item.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-xl",
				children: "Mouvements"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 divide-y divide-border",
				children: data.moves.map((move) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-baseline justify-between gap-3 py-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [move.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [" · ", move.reason]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums",
						children: [
							move.delta > 0 ? "+" : "",
							formatQty(move.delta),
							" ",
							move.unit
						]
					})]
				}, move.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Modal, {
			open: draft != null,
			onOpenChange: (next) => !next && setDraft(null),
			title: draft?.id ? "Ingrédient" : "Nouvel ingrédient",
			children: draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-3",
				onSubmit: (event) => {
					event.preventDefault();
					save();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "stock-name",
						children: "Nom"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "stock-name",
						className: "mt-1",
						value: draft.name,
						onChange: (event) => setDraft({
							...draft,
							name: event.target.value
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "stock-unit",
							children: "Unité"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							id: "stock-unit",
							className: "mt-1",
							value: draft.unit,
							onChange: (event) => setDraft({
								...draft,
								unit: event.target.value
							}),
							children: UNITS.map((unit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: unit,
								children: unit
							}, unit))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Changer l'unité ne convertit pas la quantité."
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "stock-qty",
							children: "Quantité"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "stock-qty",
							className: "mt-1",
							inputMode: "numeric",
							value: draft.quantity,
							onChange: (event) => setDraft({
								...draft,
								quantity: event.target.value
							})
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "stock-threshold",
							children: "Seuil"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "stock-threshold",
							className: "mt-1",
							inputMode: "numeric",
							value: draft.threshold,
							onChange: (event) => setDraft({
								...draft,
								threshold: event.target.value
							})
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "w-full",
						disabled: busy,
						children: "Enregistrer"
					})
				]
			}) : null
		})
	] });
}
function TodayView(props) {
	const { data, pin, busy, run } = props;
	const active = data.orders.filter((order) => (order.status === "recue" || order.status === "preparation" || order.status === "prete") && order.slotDate >= data.today).sort((a, b) => a.slotDate.localeCompare(b.slotDate) || a.slotTime.localeCompare(b.slotTime));
	const toPrep = data.orders.filter((order) => order.status === "recue" || order.status === "preparation").reduce((sum, order) => sum + order.lines.reduce((inner, line) => inner + line.qty, 0), 0);
	const booked = data.series.reduce((sum, point) => sum + point.bookedCents, 0);
	const paid = data.series.reduce((sum, point) => sum + point.paidCents, 0);
	const alerts = data.stock.filter((item) => item.quantity <= item.threshold);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				title: "Aujourd'hui",
				detail: formatDay(data.today)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "À honorer",
						value: String(active.length)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Portions à préparer",
						value: String(toPrep)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Engagé, 7 jours",
						value: formatEUR(booked)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Encaissé, 7 jours",
						value: formatEUR(paid)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-xl",
					children: "Recettes engagées"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Commandes non annulées, par jour de retrait."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartSlot, { series: data.series })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-xl",
				children: "File du service"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-3 space-y-3",
				children: [active.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-sm text-muted-foreground",
					children: "Aucune commande à servir."
				}) : null, active.slice(0, 6).map((order) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "lift rounded-3xl bg-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xl",
								children: order.code
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted-foreground tabular-nums",
								children: [
									formatDay(order.slotDate),
									" · ",
									order.slotTime
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: order.lines.map((line) => `${line.qty} × ${line.name}`).join(", ")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderActions, {
								order,
								pin,
								busy,
								run
							})
						})
					]
				}, order.id))]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-xl",
				children: "Sous le seuil"
			}), alerts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Aucun ingrédient sous son seuil."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 divide-y divide-border",
				children: alerts.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-baseline justify-between gap-3 py-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums text-destructive",
						children: [
							formatQty(item.quantity),
							" ",
							item.unit
						]
					})]
				}, item.id))
			})] })
		]
	});
}
function ChartSlot({ series }) {
	const [Chart, setChart] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		import("./revenue-chart-Br24VjHj.mjs").then((mod) => setChart(() => mod.RevenueChart));
	}, []);
	if (!Chart) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-4 h-40 rounded-xl bg-secondary" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chart, { series })
	});
}
var PIN_KEY = "comptoir-atelier-pin";
var NAV = [
	{
		id: "jour",
		label: "Aujourd'hui",
		icon: LayoutDashboard
	},
	{
		id: "commandes",
		label: "Commandes",
		icon: ClipboardList
	},
	{
		id: "planning",
		label: "Planning",
		icon: CalendarRange
	},
	{
		id: "stocks",
		label: "Stocks",
		icon: Boxes
	},
	{
		id: "recettes",
		label: "Recettes",
		icon: BookOpen
	},
	{
		id: "application",
		label: "Application",
		icon: Settings
	}
];
function AtelierApp({ section }) {
	const navigate = useNavigate();
	const [phase, setPhase] = (0, import_react.useState)("boot");
	const [demo, setDemo] = (0, import_react.useState)(false);
	const [code, setCode] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	const [pin, setPin] = (0, import_react.useState)("");
	const [data, setData] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const ticket = (0, import_react.useRef)(0);
	const busyRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		let cancel = false;
		const saved = sessionStorage.getItem(PIN_KEY) ?? "";
		getLockState().then(async (state) => {
			if (cancel) return;
			setDemo(state.demoLock);
			if (/^\d{4}$/.test(saved)) try {
				const next = await loadAtelier({ data: { pin: saved } });
				if (cancel) return;
				setPin(saved);
				setData(next);
				setPhase("app");
				return;
			} catch {
				sessionStorage.removeItem(PIN_KEY);
			}
			if (!cancel) setPhase("lock");
		}).catch(() => {
			if (!cancel) setPhase("lock");
		});
		return () => {
			cancel = true;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (phase !== "app" || !pin) return;
		const id = window.setInterval(() => {
			if (document.visibilityState !== "visible" || busyRef.current) return;
			const seen = ticket.current;
			loadAtelier({ data: { pin } }).then((next) => {
				if (ticket.current === seen) setData(next);
			}).catch(() => void 0);
		}, 15e3);
		return () => window.clearInterval(id);
	}, [phase, pin]);
	async function run(work) {
		busyRef.current = true;
		setBusy(true);
		ticket.current += 1;
		try {
			const next = await work();
			ticket.current += 1;
			setData(next);
			return true;
		} catch (caught) {
			toast.error(messageOf(caught));
			return false;
		} finally {
			busyRef.current = false;
			setBusy(false);
		}
	}
	function lock() {
		sessionStorage.removeItem(PIN_KEY);
		setPin("");
		setData(null);
		setPhase("lock");
		setCode("");
	}
	if (phase === "boot" || phase === "app" && !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm tracking-widest text-muted-foreground",
			children: "COMPTOIR"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-4xl tracking-tight",
			children: "Atelier"
		})] })
	});
	if (phase === "lock" || !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm tracking-widest text-muted-foreground",
					children: "COMPTOIR"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-4xl tracking-tight",
					children: "Atelier"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted-foreground",
					children: "Stocks, recettes, planning et commandes."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-8 space-y-3",
					onSubmit: (event) => {
						event.preventDefault();
						if (!/^\d{4}$/.test(code)) {
							setError("Code à 4 chiffres.");
							return;
						}
						setPending(true);
						setError("");
						loadAtelier({ data: { pin: code } }).then((next) => {
							sessionStorage.setItem(PIN_KEY, code);
							setPin(code);
							setData(next);
							setPhase("app");
						}).catch((caught) => setError(messageOf(caught))).finally(() => setPending(false));
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "pin",
							children: "Code atelier"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "pin",
							inputMode: "numeric",
							autoComplete: "off",
							maxLength: 4,
							value: code,
							onChange: (event) => setCode(event.target.value.replace(/\D/g, "").slice(0, 4))
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-destructive",
							children: error
						}) : null,
						demo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "Code de départ : 4820. À changer dans Application."
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							className: "w-full",
							disabled: pending,
							children: "Entrer"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "mt-6 inline-flex h-11 items-center text-sm",
					children: "Retour à la carte"
				})
			]
		})
	});
	const desk = {
		data,
		pin,
		busy,
		run,
		onPin: (next) => {
			sessionStorage.setItem(PIN_KEY, next);
			setPin(next);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "safe-top border-b border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm tracking-widest text-muted-foreground",
				children: "COMPTOIR"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-lg leading-tight",
				children: data.shop.name
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "inline-flex h-11 items-center rounded-lg px-3 text-sm hover:bg-secondary",
					children: "La carte"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: lock,
					children: "Verrouiller"
				})]
			})]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-6xl gap-6 px-4 py-6 lg:grid-cols-[14rem_minmax(0,1fr)] lg:px-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "scroll-x flex gap-2 lg:flex-col lg:overflow-visible",
			children: NAV.map((item) => {
				const Icon = item.icon;
				const active = section === item.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					"aria-current": active ? "page" : void 0,
					onClick: () => void navigate({
						to: "/atelier",
						search: { section: item.id }
					}),
					className: cn("inline-flex h-11 shrink-0 items-center gap-2 rounded-lg px-3 text-sm font-medium", active ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-4",
						"aria-hidden": "true"
					}), item.label]
				}, item.id);
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [
				section === "jour" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TodayView, { ...desk }) : null,
				section === "commandes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrdersView, { ...desk }) : null,
				section === "planning" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanningView, { ...desk }) : null,
				section === "stocks" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StockView, { ...desk }) : null,
				section === "recettes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecipesView, { ...desk }) : null,
				section === "application" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsView, { ...desk }) : null
			]
		})]
	})] });
}
function AtelierPage() {
	const { section } = Route$1.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AtelierApp, { section });
}
//#endregion
export { AtelierPage as component };
