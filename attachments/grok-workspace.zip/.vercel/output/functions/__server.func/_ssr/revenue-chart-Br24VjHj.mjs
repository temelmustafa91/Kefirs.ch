import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as formatEUR } from "./format-DcnPm31r.mjs";
import { a as Tooltip, i as Bar, n as YAxis, r as XAxis, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/revenue-chart-Br24VjHj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RevenueChart({ series }) {
	const ref = (0, import_react.useRef)(null);
	const [width, setWidth] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const node = ref.current;
		if (!node) return;
		const update = () => setWidth(node.clientWidth);
		update();
		const observer = new ResizeObserver(update);
		observer.observe(node);
		return () => observer.disconnect();
	}, []);
	const data = series.map((point) => ({
		...point,
		euros: point.bookedCents / 100
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: "h-40 w-full text-muted-foreground",
		children: width > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
			width,
			height: 160,
			data,
			barCategoryGap: "28%",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
					dataKey: "label",
					tickLine: false,
					axisLine: false,
					tick: {
						fill: "currentColor",
						fontSize: 12
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { hide: true }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
					cursor: { fill: "color-mix(in oklab, currentColor 8%, transparent)" },
					formatter: (value) => [formatEUR(Math.round(Number(value) * 100)), "Engagé"],
					contentStyle: {
						background: "var(--color-card)",
						border: "1px solid var(--color-border)",
						borderRadius: 12,
						color: "var(--color-foreground)"
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
					dataKey: "euros",
					fill: "var(--color-foreground)",
					radius: [
						6,
						6,
						0,
						0
					],
					maxBarSize: 28
				})
			]
		}) : null
	});
}
//#endregion
export { RevenueChart };
