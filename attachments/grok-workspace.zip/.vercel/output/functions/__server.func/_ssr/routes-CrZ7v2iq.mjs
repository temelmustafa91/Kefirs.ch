import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as useNavigate, x as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { _ as messageOf, d as formatEUR, n as NOTE_PRESETS, s as dishSrc } from "./format-DcnPm31r.mjs";
import { a as Minus, i as Plus, l as Clock, o as MapPin } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { f as placeOrder, i as Route$2, l as getSlots } from "./router-CWnMlBKp.mjs";
import { n as cn, t as Button } from "./button-CqtuPLNw.mjs";
import { t as Modal } from "./modal-D5EsdU5u.mjs";
import { t as SiteHeader } from "./site-header-DlMehv2p.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CrZ7v2iq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var memory = /* @__PURE__ */ new Map();
var useCart = create()(persist((set, get) => ({
	lines: [],
	setQty: (recipeId, qty) => {
		const lines = get().lines.filter((line) => line.recipeId !== recipeId);
		if (qty > 0) lines.push({
			recipeId,
			qty
		});
		set({ lines });
	},
	clear: () => set({ lines: [] })
}), {
	name: "comptoir-cart",
	skipHydration: true,
	storage: createJSONStorage(() => typeof window === "undefined" ? {
		getItem: (key) => memory.get(key) ?? null,
		setItem: (key, value) => {
			memory.set(key, value);
		},
		removeItem: (key) => {
			memory.delete(key);
		}
	} : localStorage)
}));
function Storefront({ data }) {
	const router = useRouter();
	const navigate = useNavigate();
	const lines = useCart((state) => state.lines);
	const setQty = useCart((state) => state.setQty);
	const clear = useCart((state) => state.clear);
	const [category, setCategory] = (0, import_react.useState)("Tout");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [date, setDate] = (0, import_react.useState)(data.days[0]?.date ?? "");
	const [time, setTime] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)([]);
	const [slots, setSlots] = (0, import_react.useState)(null);
	const [pending, setPending] = (0, import_react.useState)(false);
	const [nonce, setNonce] = (0, import_react.useState)(0);
	const [code, setCode] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		useCart.persist.rehydrate();
	}, []);
	(0, import_react.useEffect)(() => {
		if (!data.days.some((day) => day.date === date)) {
			setDate(data.days[0]?.date ?? "");
			setTime("");
		}
	}, [data.days, date]);
	(0, import_react.useEffect)(() => {
		if (!open || !date) return;
		let cancel = false;
		setSlots(null);
		getSlots({ data: date }).then((next) => {
			if (!cancel) setSlots(next);
		}).catch((error) => {
			if (!cancel) toast.error(messageOf(error));
		});
		return () => {
			cancel = true;
		};
	}, [
		open,
		date,
		nonce
	]);
	const categories = (0, import_react.useMemo)(() => ["Tout", ...new Set(data.menu.map((item) => item.category))], [data.menu]);
	const visible = data.menu.filter((item) => category === "Tout" || item.category === category);
	const detailed = lines.map((line) => {
		const item = data.menu.find((entry) => entry.id === line.recipeId);
		if (!item) return null;
		const qty = Math.min(line.qty, item.available);
		return qty > 0 ? {
			item,
			qty
		} : null;
	}).filter((line) => line != null);
	const portions = detailed.reduce((sum, line) => sum + line.qty, 0);
	const total = detailed.reduce((sum, line) => sum + line.qty * line.item.priceCents, 0);
	async function confirm() {
		if (!date || !time || detailed.length === 0) return;
		setPending(true);
		try {
			const order = await placeOrder({ data: {
				slotDate: date,
				slotTime: time,
				notes: notes.filter((note) => NOTE_PRESETS.includes(note)),
				lines: detailed.map((line) => ({
					recipeId: line.item.id,
					qty: line.qty
				}))
			} });
			clear();
			setOpen(false);
			await router.invalidate();
			await navigate({
				to: "/suivi",
				search: { code: order.code }
			});
		} catch (error) {
			toast.error(messageOf(error));
			setNonce((value) => value + 1);
			await router.invalidate();
		} finally {
			setPending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: portions > 0 ? "pb-28" : "",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-5xl px-4 py-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm tracking-widest text-muted-foreground",
						children: "COMPTOIR"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 max-w-xl font-display text-4xl tracking-tight sm:text-5xl",
						children: data.shop.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-xl text-lg text-muted-foreground",
						children: data.shop.tagline
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 flex flex-wrap gap-x-4 gap-y-2 text-sm text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
								className: "size-4",
								"aria-hidden": "true"
							}), data.shop.address]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, {
								className: "size-4",
								"aria-hidden": "true"
							}), data.shop.hoursLabel]
						})]
					}),
					data.shop.announcement ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-xl border-l-2 border-foreground pl-4",
						children: data.shop.announcement
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "scroll-x mt-8 flex gap-2",
						children: categories.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setCategory(entry),
							className: cn("h-11 shrink-0 rounded-full px-4 text-sm font-medium", category === entry ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"),
							children: entry
						}, entry))
					}),
					visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-10 text-muted-foreground",
						children: "Rien à la carte pour le moment."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
						children: visible.map((item, index) => {
							const qty = lines.find((line) => line.recipeId === item.id)?.qty ?? 0;
							const src = dishSrc(item.image);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "lift flex h-full flex-col overflow-hidden rounded-3xl bg-card",
								children: [src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src,
									alt: item.name,
									className: "aspect-[4/3] w-full object-cover",
									loading: index < 2 ? "eager" : "lazy"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex aspect-[4/3] items-end bg-secondary p-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-2xl tracking-tight",
										children: item.name
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-1 flex-col p-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted-foreground",
											children: item.category
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "mt-1 font-display text-2xl tracking-tight",
											children: item.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 flex-1 text-sm text-muted-foreground",
											children: item.description
										}),
										item.available === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-3 text-sm text-destructive",
											children: "Épuisé"
										}) : item.available <= 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-3 text-sm text-warn",
											children: ["Plus que ", item.available]
										}) : null,
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-4 flex items-center justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-medium tabular-nums",
												children: formatEUR(item.priceCents)
											}), qty > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
												value: qty,
												max: item.available,
												onChange: (next) => setQty(item.id, next)
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												disabled: item.available === 0,
												onClick: () => setQty(item.id, 1),
												children: "Ajouter"
											})]
										})
									]
								})]
							}) }, item.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-16 max-w-md border-t border-border pt-8",
						onSubmit: (event) => {
							event.preventDefault();
							const next = code.trim().toUpperCase();
							if (next) navigate({
								to: "/suivi",
								search: { code: next }
							});
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl tracking-tight",
								children: "Déjà commandé"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: "Le code reçu à la commande est le ticket de retrait. Comptoir est la seule porte."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: code,
									onChange: (event) => setCode(event.target.value.toUpperCase()),
									placeholder: "BR-1842",
									"aria-label": "Code de commande",
									className: "h-11 min-w-0 flex-1 rounded-lg border border-border bg-card px-3 text-base uppercase outline-none focus-visible:ring-2 focus-visible:ring-ring"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									children: "Suivre"
								})]
							})
						]
					})
				]
			}),
			portions > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "dock fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [
							portions,
							" portion",
							portions > 1 ? "s" : ""
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium tabular-nums",
						children: formatEUR(total)
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => setOpen(true),
						children: "Choisir un créneau"
					})]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Modal, {
				open,
				onOpenChange: setOpen,
				title: "Retrait",
				description: "Choisissez un créneau. Aucun nom n'est demandé : le code suffit au comptoir.",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2 text-sm",
						children: detailed.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								line.qty,
								" × ",
								line.item.name
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: formatEUR(line.qty * line.item.priceCents)
							})]
						}, line.item.id))
					}),
					data.days.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-muted-foreground",
						children: "Aucun créneau ouvert pour le moment."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "scroll-x mt-4 flex gap-2",
						children: data.days.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setDate(day.date);
								setTime("");
							},
							className: cn("h-11 shrink-0 rounded-full px-4 text-sm", date === day.date ? "bg-primary text-primary-foreground" : "bg-secondary"),
							children: day.label
						}, day.date))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid grid-cols-2 gap-2",
						children: slots == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "col-span-2 text-sm text-muted-foreground",
							children: "Créneaux…"
						}) : slots.closed || slots.slots.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "col-span-2 text-sm text-muted-foreground",
							children: "Plus de créneau ce jour-là."
						}) : slots.slots.map((slot) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: slot.remaining <= 0,
							onClick: () => setTime(slot.time),
							className: cn("flex h-11 items-center justify-between rounded-lg px-3 text-sm disabled:opacity-40", time === slot.time ? "bg-primary text-primary-foreground" : "bg-secondary"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: slot.time
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: slot.remaining > 0 ? slot.remaining : "complet" })]
						}, slot.time))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: NOTE_PRESETS.map((note) => {
							const active = notes.includes(note);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": active,
								onClick: () => setNotes((current) => active ? current.filter((item) => item !== note) : [...current, note]),
								className: cn("h-11 rounded-full px-3 text-sm", active ? "bg-primary text-primary-foreground" : "bg-secondary"),
								children: note
							}, note);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sticky bottom-0 -mx-4 mt-4 border-t border-border bg-background px-4 py-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							disabled: pending || !time || detailed.length === 0,
							onClick: () => void confirm(),
							children: pending ? "Enregistrement…" : `Confirmer · ${formatEUR(total)}`
						})
					})
				]
			})
		]
	});
}
function Stepper({ value, max, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "grid size-11 place-items-center rounded-lg bg-secondary",
				"aria-label": "Retirer une portion",
				onClick: () => onChange(Math.max(0, value - 1)),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-8 text-center tabular-nums",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "grid size-11 place-items-center rounded-lg bg-secondary disabled:opacity-40",
				"aria-label": "Ajouter une portion",
				disabled: value >= max,
				onClick: () => onChange(Math.min(max, value + 1)),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
			})
		]
	});
}
function Home() {
	const data = Route$2.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Storefront, { data });
}
//#endregion
export { Home as component };
