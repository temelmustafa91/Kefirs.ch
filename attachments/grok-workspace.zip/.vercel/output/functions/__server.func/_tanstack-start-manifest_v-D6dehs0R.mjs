//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D6dehs0R.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/atelier",
			"/suivi"
		],
		preloads: ["/assets/index-BwqsRr_7.js", "/assets/jsx-runtime-D3jfb0Ew.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BwqsRr_7.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CVwRglVK.js",
			"/assets/modal-CYEC5gW3.js",
			"/assets/button-CM4ys5ZK.js",
			"/assets/site-header-V_b_cGXz.js"
		]
	},
	"/atelier": {
		filePath: "/workspace/src/routes/atelier.tsx",
		children: void 0,
		preloads: [
			"/assets/atelier-DmmsJgwo.js",
			"/assets/modal-CYEC5gW3.js",
			"/assets/button-CM4ys5ZK.js",
			"/assets/status-pill-DLawhQ2y.js"
		]
	},
	"/suivi": {
		filePath: "/workspace/src/routes/suivi.tsx",
		children: void 0,
		preloads: [
			"/assets/suivi-CaEtrIi1.js",
			"/assets/button-CM4ys5ZK.js",
			"/assets/status-pill-DLawhQ2y.js",
			"/assets/site-header-V_b_cGXz.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
