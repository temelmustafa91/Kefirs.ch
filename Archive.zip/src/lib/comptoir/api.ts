import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql, type Sql } from "@/lib/db";
import {
  DISH_KEYS,
  addDays,
  axisDay,
  formatIso,
  formatStamp,
  hoursLabel,
  isBookableSlot,
  parisNow,
  slotTimes,
  toMinutes,
  upcomingDays,
  utcDate,
} from "@/lib/comptoir/format";
import type {
  AtelierOrder,
  MenuItem,
  OrderLine,
  PlacedOrder,
  PublicOrder,
  Recipe,
  RecipeLine,
  SeriesPoint,
  ShopPublic,
  SlotsData,
  Snapshot,
  Status,
  StockItem,
  StockMove,
  StockUse,
  StorefrontData,
} from "@/lib/comptoir/types";

const pinSchema = z.string().regex(/^\d{4}$/);

const orderSchema = z.object({
  slotDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  slotTime: z.string().regex(/^\d{2}:\d{2}$/),
  notes: z
    .array(
      z.union([
        z.enum(["Bien frais", "Sans pulpe", "Peu pétillant"]),
        z.string().regex(/^Reprise de ([1-9]|1\d|2[0-4]) bouteilles$/),
      ]),
    )
    .max(5),
  lines: z
    .array(
      z.object({
        recipeId: z.number().int().positive(),
        qty: z.number().int().min(1).max(12),
      }),
    )
    .min(1)
    .max(8),
});

const shopSchema = z.object({
  pin: pinSchema,
  name: z.string(),
  tagline: z.string(),
  announcement: z.string(),
  address: z.string(),
  openTime: z.string(),
  closeTime: z.string(),
  eveningOpen: z.string(),
  eveningClose: z.string(),
  slotMinutes: z.union([z.literal(15), z.literal(30), z.literal(60)]),
  slotCapacity: z.number().int().min(1).max(40),
  closedDows: z.array(z.number().int().min(0).max(6)).max(7),
  newPin: z.string(),
});

const recipeSchema = z.object({
  pin: pinSchema,
  id: z.number().int().positive().nullable(),
  name: z.string(),
  description: z.string(),
  category: z.string(),
  priceCents: z.number().int().min(50).max(50000),
  prepMinutes: z.number().int().min(0).max(240),
  published: z.boolean(),
  image: z.string(),
  lines: z
    .array(
      z.object({
        stockItemId: z.number().int().positive(),
        quantity: z.number().int().min(1).max(20000),
      }),
    )
    .max(12),
});

const stockSchema = z.object({
  pin: pinSchema,
  id: z.number().int().positive().nullable(),
  name: z.string(),
  unit: z.enum(["g", "ml", "pièce"]),
  quantity: z.number().int().min(0).max(1000000),
  threshold: z.number().int().min(0).max(1000000),
});

const adjustSchema = z.object({
  pin: pinSchema,
  id: z.number().int().positive(),
  delta: z.number().int().min(-100000).max(100000),
  reason: z.string(),
});

const statusSchema = z.object({
  pin: pinSchema,
  id: z.number().int().positive(),
  status: z.enum(["preparation", "prete", "retiree", "annulee"]),
});

const idSchema = z.object({
  pin: pinSchema,
  id: z.number().int().positive(),
});

const moveSchema = z.object({
  pin: pinSchema,
  id: z.number().int().positive(),
  direction: z.union([z.literal(-1), z.literal(1)]),
});

const closureSchema = z.object({
  pin: pinSchema,
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  closed: z.boolean(),
});

function parse<T>(
  schema: { safeParse: (value: unknown) => { success: true; data: T } | { success: false } },
  value: unknown,
): T {
  const result = schema.safeParse(value);
  if (!result.success) throw new Error("Demande invalide.");
  return result.data;
}

function num(value: unknown): number {
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function flag(value: unknown): boolean {
  return value === true || value === "t" || value === "true";
}

function clean(value: string, min: number, max: number, label: string): string {
  const next = value.trim();
  if (next.length < min || next.length > max) throw new Error(`${label} : longueur invalide.`);
  return next;
}

function validTime(value: string): boolean {
  if (!/^\d{2}:\d{2}$/.test(value)) return false;
  const [hour, minute] = value.split(":").map(Number);
  return hour <= 23 && minute <= 59;
}

function parseDows(value: string): number[] {
  return value
    .split(",")
    .map((part) => Number(part.trim()))
    .filter((day) => day >= 0 && day <= 6);
}

function asStatus(value: unknown): Status {
  if (
    value === "recue" ||
    value === "preparation" ||
    value === "prete" ||
    value === "retiree" ||
    value === "annulee"
  ) {
    return value;
  }
  return "recue";
}

function readJson<T>(value: unknown, map: (row: Record<string, unknown>) => T): T[] {
  const source = typeof value === "string" ? (JSON.parse(value) as unknown) : value;
  if (!Array.isArray(source)) return [];
  return source.map((row) => map(row as Record<string, unknown>));
}

type ShopRow = {
  name: string;
  tagline: string;
  announcement: string;
  address: string;
  open_time: string;
  close_time: string;
  evening_open: string | null;
  evening_close: string | null;
  slot_minutes: number;
  slot_capacity: number;
  closed_dows: string;
};

function toShop(row: ShopRow): ShopPublic {
  const shop = {
    name: row.name,
    tagline: row.tagline,
    announcement: row.announcement,
    address: row.address,
    openTime: row.open_time,
    closeTime: row.close_time,
    eveningOpen: row.evening_open || null,
    eveningClose: row.evening_close || null,
    slotMinutes: num(row.slot_minutes),
    slotCapacity: num(row.slot_capacity),
    closedDows: parseDows(row.closed_dows),
    hoursLabel: "",
  };
  shop.hoursLabel = hoursLabel(shop);
  return shop;
}

async function loadShop(sql: Sql): Promise<ShopPublic> {
  const rows = await sql<ShopRow>`
    select name, tagline, announcement, address, open_time, close_time,
           evening_open, evening_close, slot_minutes, slot_capacity, closed_dows
    from shop where id = 1
  `;
  if (!rows[0]) throw new Error("FermenStation non initialisée.");
  return toShop(rows[0]);
}

async function loadClosures(sql: Sql): Promise<string[]> {
  const rows = await sql<{ day: string }>`select day::text as day from closures order by day`;
  return rows.map((row) => row.day);
}

async function assertPin(sql: Sql, pin: string) {
  const rows = await sql<{ ok: boolean }>`select (pin_code = ${pin}) as ok from shop where id = 1`;
  if (!flag(rows[0]?.ok)) throw new Error("Code atelier incorrect.");
}

async function gate(pin: string): Promise<Sql> {
  const sql = await getSql();
  await assertPin(sql, pin);
  return sql;
}

const ORDER_SQL = `
  select
    o.id,
    o.code,
    o.slot_date::text as slot_date,
    o.slot_time,
    o.status,
    o.notes,
    o.total_cents,
    to_char(o.created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as created_at,
    coalesce((
      select json_agg(json_build_object('recipeId', l.recipe_id, 'name', l.name, 'qty', l.qty, 'unitCents', l.unit_cents) order by l.id)
      from order_lines l where l.order_id = o.id
    ), '[]'::json) as lines,
    coalesce((
      select json_agg(json_build_object('name', s.name, 'unit', s.unit, 'quantity', os.quantity) order by s.name)
      from order_stock os
      join stock_items s on s.id = os.stock_item_id
      where os.order_id = o.id
    ), '[]'::json) as stock_use
  from orders o
`;

type OrderRow = {
  id: number;
  code: string;
  slot_date: string;
  slot_time: string;
  status: string;
  notes: string;
  total_cents: number;
  created_at: string;
  lines: unknown;
  stock_use: unknown;
};

function mapLines(value: unknown): OrderLine[] {
  return readJson(value, (row) => ({
    name: String(row.name ?? ""),
    qty: num(row.qty),
    unitCents: num(row.unitCents),
    recipeId: row.recipeId == null || row.recipeId === "" ? null : num(row.recipeId),
  }));
}

function mapStockUse(value: unknown): StockUse[] {
  return readJson(value, (row) => ({
    name: String(row.name ?? ""),
    unit: String(row.unit ?? ""),
    quantity: num(row.quantity),
  }));
}

function mapOrder(row: OrderRow): AtelierOrder {
  return {
    id: num(row.id),
    code: row.code,
    slotDate: row.slot_date,
    slotTime: row.slot_time,
    status: asStatus(row.status),
    notes: row.notes,
    totalCents: num(row.total_cents),
    createdLabel: formatStamp(row.created_at),
    lines: mapLines(row.lines),
    stockUse: mapStockUse(row.stock_use),
  };
}

async function snapshot(sql: Sql): Promise<Snapshot> {
  const today = parisNow().date;
  const start = formatIso(addDays(utcDate(today), -6));
  const [shop, demoRows, orderRows, stockRows, moveRows, recipeRows, lineRows, seriesRows, closureRows] =
    await Promise.all([
      loadShop(sql),
      sql<{ demo_lock: boolean }>`select (pin_code = '4820') as demo_lock from shop where id = 1`,
      sql.query<OrderRow>(`${ORDER_SQL} order by o.slot_date desc, o.slot_time desc, o.id desc limit 400`),
      sql<{ id: number; name: string; unit: string; quantity: number; threshold: number }>`
        select id, name, unit, quantity, threshold from stock_items order by name
      `,
      sql<{ id: number; name: string; unit: string; delta: number; reason: string; created_at: string }>`
        select m.id, s.name, s.unit, m.delta, m.reason,
               to_char(m.created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as created_at
        from stock_moves m
        join stock_items s on s.id = m.stock_item_id
        order by m.id desc
        limit 12
      `,
      sql<{
        id: number;
        name: string;
        description: string;
        category: string;
        price_cents: number;
        prep_minutes: number;
        published: boolean;
        image: string;
      }>`
        select id, name, description, category, price_cents, prep_minutes, published, image
        from recipes order by sort_order, id
      `,
      sql<{ recipe_id: number; stock_item_id: number; quantity: number; name: string; unit: string }>`
        select rl.recipe_id, rl.stock_item_id, rl.quantity, s.name, s.unit
        from recipe_lines rl
        join stock_items s on s.id = rl.stock_item_id
        order by rl.id
      `,
      sql<{ date: string; booked: number; paid: number }>`
        select slot_date::text as date,
               coalesce(sum(total_cents) filter (where status <> 'annulee'), 0)::int as booked,
               coalesce(sum(total_cents) filter (where status = 'retiree'), 0)::int as paid
        from orders
        where slot_date between ${start}::date and ${today}::date
        group by slot_date
      `,
      sql<{ day: string }>`select day::text as day from closures order by day`,
    ]);

  const linesByRecipe = new Map<number, RecipeLine[]>();
  for (const line of lineRows) {
    const bucket = linesByRecipe.get(num(line.recipe_id)) ?? [];
    bucket.push({
      stockItemId: num(line.stock_item_id),
      name: line.name,
      unit: line.unit,
      quantity: num(line.quantity),
    });
    linesByRecipe.set(num(line.recipe_id), bucket);
  }

  const byDate = new Map(seriesRows.map((row) => [row.date, row]));
  const series: SeriesPoint[] = Array.from({ length: 7 }, (_, index) => {
    const date = formatIso(addDays(utcDate(start), index));
    const row = byDate.get(date);
    return {
      date,
      label: axisDay(date),
      bookedCents: num(row?.booked),
      paidCents: num(row?.paid),
    };
  });

  const stock: StockItem[] = stockRows.map((row) => ({
    id: num(row.id),
    name: row.name,
    unit: row.unit,
    quantity: num(row.quantity),
    threshold: num(row.threshold),
  }));

  const moves: StockMove[] = moveRows.map((row) => ({
    id: num(row.id),
    name: row.name,
    unit: row.unit,
    delta: num(row.delta),
    reason: row.reason,
    createdLabel: formatStamp(row.created_at),
  }));

  const recipes: Recipe[] = recipeRows.map((row) => ({
    id: num(row.id),
    name: row.name,
    description: row.description,
    category: row.category,
    priceCents: num(row.price_cents),
    prepMinutes: num(row.prep_minutes),
    published: flag(row.published),
    image: row.image,
    lines: linesByRecipe.get(num(row.id)) ?? [],
  }));

  return {
    today,
    shop: { ...shop, demoLock: flag(demoRows[0]?.demo_lock) },
    orders: orderRows.map(mapOrder),
    stock,
    moves,
    recipes,
    series,
    closures: closureRows.map((row) => row.day),
  };
}

export const getLockState = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await getSql();
  const rows = await sql<{ demo_lock: boolean }>`select (pin_code = '4820') as demo_lock from shop where id = 1`;
  return { demoLock: flag(rows[0]?.demo_lock) };
});

export const getStorefront = createServerFn({ method: "GET" }).handler(async (): Promise<StorefrontData> => {
  const sql = await getSql();
  const shop = await loadShop(sql);
  const closures = await loadClosures(sql);
  const rows = await sql<{
    id: number;
    name: string;
    description: string;
    category: string;
    price_cents: number;
    prep_minutes: number;
    image: string;
    available: number;
  }>`
    select r.id, r.name, r.description, r.category, r.price_cents, r.prep_minutes, r.image,
      case
        when count(rl.id) = 0 then 20
        else least(20, coalesce(min(floor(s.quantity::numeric / rl.quantity))::int, 0))
      end as available
    from recipes r
    left join recipe_lines rl on rl.recipe_id = r.id
    left join stock_items s on s.id = rl.stock_item_id
    where r.published
    group by r.id
    order by r.sort_order, r.id
  `;
  const menu: MenuItem[] = rows.map((row) => ({
    id: num(row.id),
    name: row.name,
    description: row.description,
    category: row.category,
    priceCents: num(row.price_cents),
    prepMinutes: num(row.prep_minutes),
    image: row.image,
    available: Math.max(0, num(row.available)),
  }));
  return { shop, menu, days: upcomingDays(shop, closures, 6) };
});

export const getSlots = createServerFn({ method: "GET" })
  .validator((date: string) => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error("Date invalide.");
    return date;
  })
  .handler(async ({ data: date }): Promise<SlotsData> => {
    const sql = await getSql();
    const shop = await loadShop(sql);
    const closures = await loadClosures(sql);
    const closed = shop.closedDows.includes(new Date(`${date}T12:00:00Z`).getUTCDay()) || closures.includes(date);
    if (closed) return { date, closed: true, slots: [] };
    const now = parisNow();
    const times = slotTimes(shop).filter(
      (time) => date > now.date || (date === now.date && toMinutes(time) >= now.minutes + 40),
    );
    const used = await sql<{ slot_time: string; portions: number }>`
      select o.slot_time, coalesce(sum(l.qty), 0)::int as portions
      from orders o
      join order_lines l on l.order_id = o.id
      where o.slot_date = ${date}::date and o.status <> 'annulee'
      group by o.slot_time
    `;
    const byTime = new Map(used.map((row) => [row.slot_time, num(row.portions)]));
    return {
      date,
      closed: false,
      slots: times.map((time) => {
        const taken = byTime.get(time) ?? 0;
        return {
          time,
          remaining: Math.max(0, shop.slotCapacity - taken),
          capacity: shop.slotCapacity,
        };
      }),
    };
  });

function makeCode(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "FS-";
  for (let index = 0; index < 4; index += 1) {
    code += alphabet[Math.floor(Math.random() * alphabet.length)];
  }
  return code;
}

function isUnique(error: unknown): boolean {
  const text = error instanceof Error ? error.message : String(error);
  return text.includes("unique") || text.includes("23505");
}

export const placeOrder = createServerFn({ method: "POST" })
  .validator((input: unknown) => parse(orderSchema, input))
  .handler(async ({ data }): Promise<PlacedOrder> => {
    const sql = await getSql();
    const shop = await loadShop(sql);
    const closures = await loadClosures(sql);
    if (!isBookableSlot(shop, closures, data.slotDate, data.slotTime)) {
      throw new Error("Cette tournée n'est plus disponible.");
    }
    const merged = new Map<number, number>();
    for (const line of data.lines) merged.set(line.recipeId, (merged.get(line.recipeId) ?? 0) + line.qty);
    const payload = [...merged.entries()].map(([recipeId, qty]) => ({ recipeId, qty }));
    if (payload.some((line) => line.qty > 12)) throw new Error("Quantité trop élevée.");
    const notes = data.notes.join(" · ");

    for (let attempt = 0; attempt < 4; attempt += 1) {
      const code = makeCode();
      try {
        const rows = await sql.query<{
          order_id: number | null;
          total_cents: number;
          placed_code: string;
          recipes_ok: boolean;
          published_ok: boolean;
          stock_ok: boolean;
          capacity_ok: boolean;
          open_ok: boolean;
          short_names: string | null;
        }>("select * from place_comptoir_order($1::jsonb, $2, $3::date, $4, $5)", [
          JSON.stringify(payload),
          code,
          data.slotDate,
          data.slotTime,
          notes,
        ]);
        const row = rows[0];
        if (!row) throw new Error("La commande n'a pas abouti.");
        if (!flag(row.open_ok)) throw new Error("La station est fermée ce jour-là.");
        if (!flag(row.recipes_ok) || !flag(row.published_ok)) throw new Error("Une bouteille n'est plus à la carte.");
        if (!flag(row.stock_ok)) {
          throw new Error(row.short_names ? `Stock insuffisant : ${row.short_names}.` : "Stock insuffisant.");
        }
        if (!flag(row.capacity_ok)) throw new Error("Cette tournée est complète.");
        if (row.order_id == null) throw new Error("La commande n'a pas abouti.");
        return {
          code: row.placed_code,
          totalCents: num(row.total_cents),
          slotDate: data.slotDate,
          slotTime: data.slotTime,
        };
      } catch (error) {
        if (isUnique(error) && attempt < 3) continue;
        throw error;
      }
    }
    throw new Error("La commande n'a pas abouti.");
  });

export const getOrderByCode = createServerFn({ method: "GET" })
  .validator((code: string) => code.trim().toUpperCase())
  .handler(async ({ data: code }): Promise<PublicOrder | null> => {
    if (!/^[A-Z0-9-]{4,12}$/.test(code)) return null;
    const sql = await getSql();
    const rows = await sql.query<OrderRow>(`${ORDER_SQL} where o.code = $1`, [code]);
    const order = rows[0] ? mapOrder(rows[0]) : null;
    if (!order) return null;
    return {
      code: order.code,
      slotDate: order.slotDate,
      slotTime: order.slotTime,
      status: order.status,
      notes: order.notes,
      totalCents: order.totalCents,
      lines: order.lines,
    };
  });

export const loadAtelier = createServerFn({ method: "POST" })
  .validator((input: unknown) => parse(z.object({ pin: pinSchema }), input))
  .handler(async ({ data }) => snapshot(await gate(data.pin)));

export const setOrderStatus = createServerFn({ method: "POST" })
  .validator((input: unknown) => parse(statusSchema, input))
  .handler(async ({ data }) => {
    const sql = await gate(data.pin);
    if (data.status === "annulee") {
      const rows = await sql.query<{ previous: string | null; updated: number }>(
        "select previous, updated from cancel_comptoir_order($1)",
        [data.id],
      );
      const row = rows[0];
      if (!row || row.previous == null) throw new Error("Commande introuvable.");
      if (num(row.updated) === 0) throw new Error("Cette commande ne peut plus être annulée.");
      return snapshot(sql);
    }
    const updated = await sql<{ id: number }>`
      update orders
      set status = ${data.status}
      where id = ${data.id}
        and (
          (status = 'recue' and ${data.status} = 'preparation')
          or (status = 'preparation' and ${data.status} = 'prete')
          or (status = 'prete' and ${data.status} = 'retiree')
        )
      returning id
    `;
    if (!updated.length) throw new Error("Cette commande ne peut pas changer d'étape.");
    return snapshot(sql);
  });

export const saveStock = createServerFn({ method: "POST" })
  .validator((input: unknown) => parse(stockSchema, input))
  .handler(async ({ data }) => {
    const sql = await gate(data.pin);
    const name = clean(data.name, 2, 40, "Nom");
    if (data.id == null) {
      const inserted = await sql<{ id: number }>`
        insert into stock_items (name, unit, quantity, threshold)
        values (${name}, ${data.unit}, ${data.quantity}, ${data.threshold})
        returning id
      `;
      const id = num(inserted[0]?.id);
      if (data.quantity > 0) {
        await sql`insert into stock_moves (stock_item_id, delta, reason) values (${id}, ${data.quantity}, 'Ouverture')`;
      }
      return snapshot(sql);
    }
    const current = await sql<{ quantity: number }>`select quantity from stock_items where id = ${data.id}`;
    if (!current[0]) throw new Error("Ingrédient introuvable.");
    await sql`
      update stock_items
      set name = ${name}, unit = ${data.unit}, quantity = ${data.quantity}, threshold = ${data.threshold}
      where id = ${data.id}
    `;
    const delta = data.quantity - num(current[0].quantity);
    if (delta !== 0) {
      await sql`
        insert into stock_moves (stock_item_id, delta, reason)
        values (${data.id}, ${delta}, 'Correction d''inventaire')
      `;
    }
    return snapshot(sql);
  });

export const adjustStock = createServerFn({ method: "POST" })
  .validator((input: unknown) => parse(adjustSchema, input))
  .handler(async ({ data }) => {
    const sql = await gate(data.pin);
    if (data.delta === 0) throw new Error("Indiquez une quantité.");
    const reason = clean(data.reason.trim() || "Ajustement", 2, 40, "Motif");
    const rows = await sql.query<{ id: number }>(
      `with upd as (
         update stock_items
         set quantity = quantity + $2
         where id = $1 and quantity + $2 >= 0
         returning id
       )
       insert into stock_moves (stock_item_id, delta, reason)
       select id, $2, $3 from upd
       returning stock_item_id as id`,
      [data.id, data.delta, reason],
    );
    if (!rows.length) throw new Error("Ajustement impossible.");
    return snapshot(sql);
  });

export const deleteStock = createServerFn({ method: "POST" })
  .validator((input: unknown) => parse(idSchema, input))
  .handler(async ({ data }) => {
    const sql = await gate(data.pin);
    const state = await sql<{ present: boolean; in_recipe: boolean; in_order: boolean }>`
      select
        exists(select 1 from stock_items where id = ${data.id}) as present,
        exists(select 1 from recipe_lines where stock_item_id = ${data.id}) as in_recipe,
        exists(select 1 from order_stock where stock_item_id = ${data.id}) as in_order
    `;
    const row = state[0];
    if (!row || !flag(row.present)) throw new Error("Ingrédient introuvable.");
    if (flag(row.in_recipe) || flag(row.in_order)) throw new Error("Cet ingrédient est encore utilisé.");
    await sql`delete from stock_items where id = ${data.id}`;
    return snapshot(sql);
  });

export const saveRecipe = createServerFn({ method: "POST" })
  .validator((input: unknown) => parse(recipeSchema, input))
  .handler(async ({ data }) => {
    const sql = await gate(data.pin);
    const name = clean(data.name, 2, 60, "Nom");
    const description = clean(data.description, 0, 180, "Description");
    const category = clean(data.category, 2, 24, "Catégorie");
    if (data.image !== "" && !(DISH_KEYS as readonly string[]).includes(data.image)) {
      throw new Error("Photo inconnue.");
    }
    const merged = new Map<number, number>();
    for (const line of data.lines) merged.set(line.stockItemId, (merged.get(line.stockItemId) ?? 0) + line.quantity);
    const lines = [...merged.entries()].map(([stockItemId, quantity]) => ({ stockItemId, quantity }));
    if (lines.length) {
      const ids = lines.map((line) => line.stockItemId);
      const found = await sql.query<{ id: number }>("select id from stock_items where id = any($1::int[])", [ids]);
      if (found.length !== ids.length) throw new Error("Ingrédient inconnu.");
    }
    let recipeId = data.id;
    if (recipeId == null) {
      const maxRow = await sql<{ max: number }>`select coalesce(max(sort_order), 0)::int as max from recipes`;
      const inserted = await sql<{ id: number }>`
        insert into recipes (name, description, category, price_cents, prep_minutes, published, image, sort_order)
        values (
          ${name}, ${description}, ${category}, ${data.priceCents}, ${data.prepMinutes},
          ${data.published}, ${data.image}, ${num(maxRow[0]?.max) + 1}
        )
        returning id
      `;
      recipeId = num(inserted[0]?.id);
    } else {
      const updated = await sql<{ id: number }>`
        update recipes
        set name = ${name}, description = ${description}, category = ${category},
            price_cents = ${data.priceCents}, prep_minutes = ${data.prepMinutes},
            published = ${data.published}, image = ${data.image}
        where id = ${recipeId}
        returning id
      `;
      if (!updated.length) throw new Error("Recette introuvable.");
      await sql`delete from recipe_lines where recipe_id = ${recipeId}`;
    }
    for (const line of lines) {
      await sql`
        insert into recipe_lines (recipe_id, stock_item_id, quantity)
        values (${recipeId}, ${line.stockItemId}, ${line.quantity})
      `;
    }
    return snapshot(sql);
  });

export const deleteRecipe = createServerFn({ method: "POST" })
  .validator((input: unknown) => parse(idSchema, input))
  .handler(async ({ data }) => {
    const sql = await gate(data.pin);
    const removed = await sql<{ id: number }>`delete from recipes where id = ${data.id} returning id`;
    if (!removed.length) throw new Error("Recette introuvable.");
    return snapshot(sql);
  });

export const moveRecipe = createServerFn({ method: "POST" })
  .validator((input: unknown) => parse(moveSchema, input))
  .handler(async ({ data }) => {
    const sql = await gate(data.pin);
    const list = await sql<{ id: number }>`select id from recipes order by sort_order, id`;
    const ids = list.map((row) => num(row.id));
    const index = ids.indexOf(data.id);
    const target = index + data.direction;
    if (index < 0 || target < 0 || target >= ids.length) return snapshot(sql);
    const [current] = ids.splice(index, 1);
    ids.splice(target, 0, current);
    for (let position = 0; position < ids.length; position += 1) {
      await sql`update recipes set sort_order = ${position + 1} where id = ${ids[position]}`;
    }
    return snapshot(sql);
  });

export const saveShop = createServerFn({ method: "POST" })
  .validator((input: unknown) => parse(shopSchema, input))
  .handler(async ({ data }) => {
    const sql = await gate(data.pin);
    const name = clean(data.name, 2, 48, "Nom");
    const tagline = clean(data.tagline, 0, 140, "Phrase");
    const announcement = clean(data.announcement, 0, 180, "Annonce");
    const address = clean(data.address, 0, 80, "Adresse");
    if (!validTime(data.openTime) || !validTime(data.closeTime)) throw new Error("Horaires invalides.");
    if (toMinutes(data.openTime) >= toMinutes(data.closeTime)) throw new Error("Le premier service est invalide.");
    const eveningOpen = data.eveningOpen.trim();
    const eveningClose = data.eveningClose.trim();
    let eveningStart: string | null = null;
    let eveningEnd: string | null = null;
    if (eveningOpen || eveningClose) {
      if (!validTime(eveningOpen) || !validTime(eveningClose)) throw new Error("Le second service est incomplet.");
      if (toMinutes(eveningOpen) < toMinutes(data.closeTime)) throw new Error("Les services se chevauchent.");
      if (toMinutes(eveningOpen) >= toMinutes(eveningClose)) throw new Error("Le second service est invalide.");
      eveningStart = eveningOpen;
      eveningEnd = eveningClose;
    }
    const closedDows = [...new Set(data.closedDows)].sort((a, b) => a - b);
    if (closedDows.length >= 7) throw new Error("Ouvrez au moins un jour.");
    if (data.newPin !== "" && !/^\d{4}$/.test(data.newPin)) {
      throw new Error("Le nouveau code doit comporter 4 chiffres.");
    }
    await sql`
      update shop set
        name = ${name},
        tagline = ${tagline},
        announcement = ${announcement},
        address = ${address},
        open_time = ${data.openTime},
        close_time = ${data.closeTime},
        evening_open = ${eveningStart},
        evening_close = ${eveningEnd},
        slot_minutes = ${data.slotMinutes},
        slot_capacity = ${data.slotCapacity},
        closed_dows = ${closedDows.join(",")},
        pin_code = case when ${data.newPin} = '' then pin_code else ${data.newPin} end
      where id = 1
    `;
    return snapshot(sql);
  });

export const setClosure = createServerFn({ method: "POST" })
  .validator((input: unknown) => parse(closureSchema, input))
  .handler(async ({ data }) => {
    const sql = await gate(data.pin);
    if (data.closed) {
      await sql`insert into closures (day) values (${data.date}::date) on conflict (day) do nothing`;
    } else {
      await sql`delete from closures where day = ${data.date}::date`;
    }
    return snapshot(sql);
  });
