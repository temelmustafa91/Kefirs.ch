import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

type Line = { recipeId: number; qty: number };

type CartState = {
  lines: Line[];
  last: Line[];
  setQty: (recipeId: number, qty: number) => void;
  remember: (lines: Line[]) => void;
  clear: () => void;
};

const memory = new Map<string, string>();

export const useCart = create<CartState>()(
  persist(
    (set, get) => ({
      lines: [],
      last: [],
      setQty: (recipeId, qty) => {
        const lines = get().lines.filter((line) => line.recipeId !== recipeId);
        if (qty > 0) lines.push({ recipeId, qty });
        set({ lines });
      },
      remember: (lines) => set({ last: lines.filter((line) => line.qty > 0) }),
      clear: () => set({ lines: [] }),
    }),
    {
      name: "comptoir-cart",
      skipHydration: true,
      storage: createJSONStorage(() =>
        typeof window === "undefined"
          ? {
              getItem: (key) => memory.get(key) ?? null,
              setItem: (key, value) => {
                memory.set(key, value);
              },
              removeItem: (key) => {
                memory.delete(key);
              },
            }
          : localStorage,
      ),
    },
  ),
);
