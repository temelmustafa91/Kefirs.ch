export const NOTE_PRESETS = ["Bien frais", "Sans pulpe", "Peu pétillant"] as const;

export const DISH_KEYS = ["figue", "gingembre", "rouges", "hibiscus", "pomme", "passion"] as const;

export const UNITS = ["g", "ml", "pièce"] as const;
export type Unit = (typeof UNITS)[number];

export const LEAD_MINUTES = 40;

export const STATUS_LABEL = {
  recue: "Commandée",
  preparation: "En préparation",
  prete: "En livraison",
  retiree: "Livrée",
  annulee: "Annulée",
} as const;

const DAY_NAMES = ["dim", "lun", "mar", "mer", "jeu", "ven", "sam"];

export function dishSrc(key: string): string | null {
  return (DISH_KEYS as readonly string[]).includes(key) ? `/menu/${key}.jpg` : null;
}

export function formatEUR(cents: number): string {
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(cents / 100);
}

export function formatQty(value: number): string {
  return new Intl.NumberFormat("fr-FR").format(value);
}

export function eurosInput(cents: number): string {
  return (cents / 100).toFixed(2).replace(".", ",");
}

export function parseEuros(value: string): number | null {
  const cleaned = value.trim().replace(/\s/g, "").replace(",", ".");
  if (!/^\d+(\.\d{1,2})?$/.test(cleaned)) return null;
  const cents = Math.round(Number(cleaned) * 100);
  if (cents < 50 || cents > 50000) return null;
  return cents;
}

export function parisNow(): { date: string; minutes: number } {
  const parts = Object.fromEntries(
    new Intl.DateTimeFormat("en-GB", {
      timeZone: "Europe/Paris",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hourCycle: "h23",
    })
      .formatToParts(new Date())
      .map((part) => [part.type, part.value]),
  );
  return {
    date: `${parts.year}-${parts.month}-${parts.day}`,
    minutes: Number(parts.hour) * 60 + Number(parts.minute),
  };
}

export function utcDate(iso: string): Date {
  const [year, month, day] = iso.split("-").map(Number);
  return new Date(Date.UTC(year, (month ?? 1) - 1, day ?? 1));
}

export function addDays(date: Date, days: number): Date {
  const next = new Date(date);
  next.setUTCDate(next.getUTCDate() + days);
  return next;
}

export function formatIso(date: Date): string {
  return date.toISOString().slice(0, 10);
}

export function formatDay(iso: string): string {
  return new Intl.DateTimeFormat("fr-FR", {
    weekday: "short",
    day: "numeric",
    month: "short",
    timeZone: "UTC",
  }).format(utcDate(iso));
}

export function axisDay(iso: string): string {
  const [, month, day] = iso.split("-");
  return `${day}/${month}`;
}

export function formatStamp(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return new Intl.DateTimeFormat("fr-FR", {
    timeZone: "Europe/Paris",
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

export function passageLabel(time: string): string {
  return toMinutes(time) < 15 * 60 ? "Matin" : "Après-midi";
}

export function toMinutes(time: string): number {
  const [hour, minute] = time.split(":").map(Number);
  return hour * 60 + minute;
}

export function fromMinutes(value: number): string {
  const hour = Math.floor(value / 60);
  const minute = value % 60;
  return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
}

export function timesBetween(start: string, end: string, step: number): string[] {
  const out: string[] = [];
  for (let cursor = toMinutes(start); cursor <= toMinutes(end); cursor += step) {
    out.push(fromMinutes(cursor));
  }
  return out;
}

type Hours = {
  openTime: string;
  closeTime: string;
  eveningOpen: string | null;
  eveningClose: string | null;
  slotMinutes: number;
  closedDows: number[];
};

export function slotTimes(shop: Hours): string[] {
  const morning = timesBetween(shop.openTime, shop.closeTime, shop.slotMinutes);
  if (!shop.eveningOpen || !shop.eveningClose) return morning;
  return [...new Set([...morning, ...timesBetween(shop.eveningOpen, shop.eveningClose, shop.slotMinutes)])];
}

export function hoursLabel(shop: Hours): string {
  const open = [0, 1, 2, 3, 4, 5, 6].filter((day) => !shop.closedDows.includes(day));
  const groups: number[][] = [];
  for (const day of open) {
    const last = groups.at(-1);
    if (last && day === last.at(-1)! + 1) last.push(day);
    else groups.push([day]);
  }
  const days =
    groups.length === 0
      ? "fermé"
      : groups
          .map((group) =>
            group.length === 1 ? DAY_NAMES[group[0]] : `${DAY_NAMES[group[0]]}–${DAY_NAMES[group.at(-1)!]}`,
          )
          .join(", ");
  const evening = shop.eveningOpen && shop.eveningClose ? ` · ${shop.eveningOpen}–${shop.eveningClose}` : "";
  return `${days} · ${shop.openTime}–${shop.closeTime}${evening}`;
}

export function dowOf(iso: string): number {
  return utcDate(iso).getUTCDay();
}

export function weekStart(iso: string): string {
  const date = utcDate(iso);
  const dow = date.getUTCDay();
  const delta = dow === 0 ? -6 : 1 - dow;
  return formatIso(addDays(date, delta));
}

export function messageOf(error: unknown): string {
  if (error instanceof Error && error.message) return error.message;
  if (typeof error === "string" && error) return error;
  return "Une erreur est survenue.";
}

export function isBookableSlot(
  shop: Hours,
  closures: string[],
  date: string,
  time: string,
): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^\d{2}:\d{2}$/.test(time)) return false;
  if (shop.closedDows.includes(dowOf(date)) || closures.includes(date)) return false;
  if (!slotTimes(shop).includes(time)) return false;
  const now = parisNow();
  if (date < now.date) return false;
  if (date === now.date && toMinutes(time) < now.minutes + LEAD_MINUTES) return false;
  return true;
}

export function upcomingDays(shop: Hours, closures: string[], count: number): { date: string; label: string }[] {
  const now = parisNow();
  const closed = new Set(closures);
  const out: { date: string; label: string }[] = [];
  const start = utcDate(now.date);
  for (let index = 0; index < 28 && out.length < count; index += 1) {
    const date = formatIso(addDays(start, index));
    if (shop.closedDows.includes(dowOf(date)) || closed.has(date)) continue;
    const slots = slotTimes(shop).filter(
      (time) => date !== now.date || toMinutes(time) >= now.minutes + LEAD_MINUTES,
    );
    if (slots.length === 0) continue;
    out.push({ date, label: formatDay(date) });
  }
  return out;
}
