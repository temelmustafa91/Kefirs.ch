export const SECTIONS = ["jour", "commandes", "planning", "stocks", "recettes", "application"] as const;
export type Section = (typeof SECTIONS)[number];

export function isSection(value: unknown): value is Section {
  return typeof value === "string" && (SECTIONS as readonly string[]).includes(value);
}

export const STATUSES = ["recue", "preparation", "prete", "retiree", "annulee"] as const;
export type Status = (typeof STATUSES)[number];

export type ShopPublic = {
  name: string;
  tagline: string;
  announcement: string;
  address: string;
  openTime: string;
  closeTime: string;
  eveningOpen: string | null;
  eveningClose: string | null;
  slotMinutes: number;
  slotCapacity: number;
  closedDows: number[];
  hoursLabel: string;
};

export type MenuItem = {
  id: number;
  name: string;
  description: string;
  category: string;
  priceCents: number;
  prepMinutes: number;
  image: string;
  available: number;
};

export type StorefrontData = {
  shop: ShopPublic;
  menu: MenuItem[];
  days: { date: string; label: string }[];
};

export type Slot = { time: string; remaining: number; capacity: number };
export type SlotsData = { date: string; closed: boolean; slots: Slot[] };

export type OrderLine = { recipeId: number | null; name: string; qty: number; unitCents: number };
export type StockUse = { name: string; unit: string; quantity: number };

export type PublicOrder = {
  code: string;
  slotDate: string;
  slotTime: string;
  status: Status;
  notes: string;
  totalCents: number;
  lines: OrderLine[];
};

export type AtelierOrder = PublicOrder & {
  id: number;
  createdLabel: string;
  stockUse: StockUse[];
};

export type StockItem = {
  id: number;
  name: string;
  unit: string;
  quantity: number;
  threshold: number;
};

export type StockMove = {
  id: number;
  name: string;
  unit: string;
  delta: number;
  reason: string;
  createdLabel: string;
};

export type RecipeLine = {
  stockItemId: number;
  name: string;
  unit: string;
  quantity: number;
};

export type Recipe = {
  id: number;
  name: string;
  description: string;
  category: string;
  priceCents: number;
  prepMinutes: number;
  published: boolean;
  image: string;
  lines: RecipeLine[];
};

export type SeriesPoint = {
  date: string;
  label: string;
  bookedCents: number;
  paidCents: number;
};

export type Snapshot = {
  today: string;
  shop: ShopPublic & { demoLock: boolean };
  orders: AtelierOrder[];
  stock: StockItem[];
  moves: StockMove[];
  recipes: Recipe[];
  series: SeriesPoint[];
  closures: string[];
};

export type PlacedOrder = {
  code: string;
  totalCents: number;
  slotDate: string;
  slotTime: string;
};
