import { createFileRoute } from "@tanstack/react-router";
import { AtelierApp } from "@/components/atelier/atelier-app";
import { isSection, type Section } from "@/lib/comptoir/types";

export const Route = createFileRoute("/atelier")({
  validateSearch: (search: Record<string, unknown>): { section: Section } => ({
    section: isSection(search.section) ? search.section : "jour",
  }),
  component: AtelierPage,
  head: () => ({ meta: [{ title: "Atelier — FermenStation" }] }),
});

function AtelierPage() {
  const { section } = Route.useSearch();
  return <AtelierApp section={section} />;
}
