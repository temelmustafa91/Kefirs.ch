import { useState } from "react";
import { createFileRoute, Link, useNavigate, useRouter } from "@tanstack/react-router";
import { Copy } from "lucide-react";
import { toast } from "sonner";
import { SiteHeader } from "@/components/site-header";
import { StatusPill } from "@/components/status-pill";
import { Button } from "@/components/ui/button";
import { getOrderByCode } from "@/lib/comptoir/api";
import { useCart } from "@/lib/comptoir/cart";
import { STATUS_LABEL, formatDay, formatEUR, passageLabel } from "@/lib/comptoir/format";
import type { Status } from "@/lib/comptoir/types";
import { cn } from "@/lib/utils";

const STEPS: Status[] = ["recue", "preparation", "prete", "retiree"];

export const Route = createFileRoute("/suivi")({
  validateSearch: (search: Record<string, unknown>) => ({
    code: typeof search.code === "string" ? search.code : "",
  }),
  loaderDeps: ({ search }) => ({ code: search.code }),
  loader: ({ deps }) => (deps.code ? getOrderByCode({ data: deps.code }) : null),
  component: SuiviPage,
  head: () => ({ meta: [{ title: "Suivi — FermenStation" }] }),
});

function SuiviPage() {
  const order = Route.useLoaderData();
  const { code } = Route.useSearch();
  const navigate = useNavigate();
  const router = useRouter();
  const [draft, setDraft] = useState(code);
  const setQty = useCart((state) => state.setQty);
  const clear = useCart((state) => state.clear);

  return (
    <div>
      <SiteHeader />
      <main className="mx-auto max-w-xl px-4 py-8">
        {order ? (
          <article>
            <p className="text-sm text-muted-foreground">Bon de livraison</p>
            <div className="mt-2 flex items-center gap-2">
              <h1 className="font-display text-5xl tracking-tight">{order.code}</h1>
              <button
                type="button"
                className="grid size-11 place-items-center rounded-lg hover:bg-secondary"
                aria-label="Copier le code"
                onClick={() => {
                  void navigator.clipboard.writeText(order.code).then(
                    () => toast.success("Code copié"),
                    () => toast.error("Copie impossible"),
                  );
                }}
              >
                <Copy className="size-4" />
              </button>
            </div>
            <p className="mt-3 text-muted-foreground">Le livreur a ce code. Rien d'autre à donner.</p>
            <p className="mt-6 text-lg">
              {formatDay(order.slotDate)} · {passageLabel(order.slotTime)}
            </p>
            <div className="mt-3">
              <StatusPill status={order.status} />
            </div>
            {order.status === "annulee" ? (
              <p className="mt-6 text-sm text-muted-foreground">Cette commande a été annulée. Le stock a été recrédité.</p>
            ) : (
              <ol className="mt-6 space-y-3">
                {STEPS.map((step, index) => {
                  const current = STEPS.indexOf(order.status);
                  const done = current >= index;
                  return (
                    <li key={step} className="flex items-center gap-3">
                      <span className={cn("size-2.5 rounded-full", done ? "bg-foreground" : "bg-border")} />
                      <span className={done ? "text-foreground" : "text-muted-foreground"}>{STATUS_LABEL[step]}</span>
                    </li>
                  );
                })}
              </ol>
            )}
            <ul className="mt-8 space-y-2 border-t border-border pt-4 text-sm">
              {order.lines.map((line, index) => (
                <li key={`${line.name}-${index}`} className="flex justify-between gap-3">
                  <span>
                    {line.qty} × {line.name}
                  </span>
                  <span className="tabular-nums">{formatEUR(line.qty * line.unitCents)}</span>
                </li>
              ))}
            </ul>
            {order.notes ? <p className="mt-3 text-sm text-muted-foreground">{order.notes}</p> : null}
            <p className="mt-4 text-lg font-medium tabular-nums">{formatEUR(order.totalCents)}</p>
            <div className="mt-6 flex flex-wrap gap-2">
              <Button variant="outline" onClick={() => void router.invalidate()}>
                Actualiser
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  clear();
                  for (const line of order.lines) {
                    if (line.recipeId) setQty(line.recipeId, line.qty);
                  }
                  void navigate({ to: "/" });
                }}
              >
                Recommander
              </Button>
              <Link to="/" className="inline-flex h-11 items-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground">
                Nouvelle commande
              </Link>
            </div>
          </article>
        ) : (
          <div>
            <h1 className="font-display text-4xl tracking-tight">Suivre une commande</h1>
            <p className="mt-3 text-muted-foreground">
              {code ? "Aucune commande ne correspond à ce code." : "Entrez le code remis au moment de la commande."}
            </p>
          </div>
        )}

        <form
          className="mt-10 flex gap-2"
          onSubmit={(event) => {
            event.preventDefault();
            const next = draft.trim().toUpperCase();
            if (next) void navigate({ to: "/suivi", search: { code: next } });
          }}
        >
          <input
            value={draft}
            onChange={(event) => setDraft(event.target.value.toUpperCase())}
            aria-label="Code de commande"
            className="h-11 min-w-0 flex-1 rounded-lg border border-border bg-card px-3 text-base uppercase outline-none focus-visible:ring-2 focus-visible:ring-ring"
          />
          <Button type="submit">Voir</Button>
        </form>
      </main>
    </div>
  );
}
