import type { Snapshot } from "@/lib/comptoir/types";

export type DeskProps = {
  data: Snapshot;
  pin: string;
  busy: boolean;
  run: (work: () => Promise<Snapshot>) => Promise<boolean>;
  onPin: (pin: string) => void;
};

export function SectionTitle({ title, detail }: { title: string; detail?: string }) {
  return (
    <div>
      {detail ? <p className="text-sm text-muted-foreground">{detail}</p> : null}
      <h2 className="font-display text-2xl tracking-tight">{title}</h2>
    </div>
  );
}

export function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="lift rounded-3xl bg-card p-4">
      <p className="text-sm text-muted-foreground">{label}</p>
      <p className="mt-2 font-display text-3xl tabular-nums tracking-tight">{value}</p>
    </div>
  );
}
