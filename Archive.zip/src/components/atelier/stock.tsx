import { useState } from "react";
import { Minus, Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input, Label, Select } from "@/components/ui/field";
import { Modal } from "@/components/ui/modal";
import { adjustStock, deleteStock, saveStock } from "@/lib/comptoir/api";
import { UNITS, formatQty, type Unit } from "@/lib/comptoir/format";
import type { StockItem } from "@/lib/comptoir/types";
import { SectionTitle, type DeskProps } from "@/components/atelier/bits";

type Draft = { id: number | null; name: string; unit: Unit; quantity: string; threshold: string };

const empty: Draft = { id: null, name: "", unit: "g", quantity: "0", threshold: "0" };

export function StockView({ data, pin, busy, run }: DeskProps) {
  const [draft, setDraft] = useState<Draft | null>(null);
  const [armed, setArmed] = useState<number | null>(null);

  function openItem(item?: StockItem) {
    setDraft(
      item
        ? {
            id: item.id,
            name: item.name,
            unit: (UNITS as readonly string[]).includes(item.unit) ? (item.unit as Unit) : "g",
            quantity: String(item.quantity),
            threshold: String(item.threshold),
          }
        : empty,
    );
  }

  async function save() {
    if (!draft) return;
    const quantity = Number(draft.quantity);
    const threshold = Number(draft.threshold);
    if (!Number.isInteger(quantity) || quantity < 0 || !Number.isInteger(threshold) || threshold < 0) {
      toast.error("Quantités invalides.");
      return;
    }
    try {
      const ok = await run(() =>
        saveStock({
          data: { pin, id: draft.id, name: draft.name, unit: draft.unit, quantity, threshold },
        }),
      );
      if (!ok) return;
      setDraft(null);
      toast.success("Stock enregistré");
    } catch {
      /* toasted */
    }
  }

  return (
    <div>
      <div className="flex items-end justify-between gap-3">
        <SectionTitle title="Stocks" detail="Ingrédients et seuils" />
        <Button onClick={() => openItem()}>Ajouter</Button>
      </div>
      <ul className="mt-4 divide-y divide-border">
        {data.stock.map((item) => {
          const low = item.quantity <= item.threshold;
          const scale = Math.max(item.threshold * 2, item.quantity, 1);
          const pct = Math.min(100, Math.round((item.quantity / scale) * 100));
          const step = item.unit === "pièce" ? 1 : 50;
          return (
            <li key={item.id} className="py-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-medium">{item.name}</p>
                  <p className={low ? "text-sm text-destructive tabular-nums" : "text-sm text-muted-foreground tabular-nums"}>
                    {formatQty(item.quantity)} {item.unit} · seuil {formatQty(item.threshold)}
                  </p>
                </div>
                <div className="flex items-center">
                  <Button
                    variant="outline"
                    size="icon"
                    aria-label={`Retirer ${step} ${item.unit}`}
                    disabled={busy}
                    onClick={() =>
                      void run(() => adjustStock({ data: { pin, id: item.id, delta: -step, reason: "Ajustement" } }))
                    }
                  >
                    <Minus className="size-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    aria-label={`Ajouter ${step} ${item.unit}`}
                    disabled={busy}
                    onClick={() =>
                      void run(() => adjustStock({ data: { pin, id: item.id, delta: step, reason: "Ajustement" } }))
                    }
                  >
                    <Plus className="size-4" />
                  </Button>
                </div>
              </div>
              <div className="mt-2 h-1 overflow-hidden rounded-full bg-secondary">
                <div className={low ? "h-full bg-destructive" : "h-full bg-foreground"} style={{ width: `${pct}%` }} />
              </div>
              <div className="mt-2 flex gap-2">
                <Button variant="ghost" onClick={() => openItem(item)}>
                  Modifier
                </Button>
                {armed === item.id ? (
                  <Button
                    variant="ghost"
                    disabled={busy}
                    onClick={() =>
                      void run(() => deleteStock({ data: { pin, id: item.id } })).then((ok) => {
                    if (ok) setArmed(null);
                  })
                    }
                  >
                    Confirmer
                  </Button>
                ) : (
                  <Button variant="ghost" onClick={() => setArmed(item.id)}>
                    Retirer
                  </Button>
                )}
              </div>
            </li>
          );
        })}
      </ul>
      <section className="mt-8">
        <h3 className="font-display text-xl">Mouvements</h3>
        <ul className="mt-2 divide-y divide-border">
          {data.moves.map((move) => (
            <li key={move.id} className="flex items-baseline justify-between gap-3 py-3 text-sm">
              <span>
                {move.name}
                <span className="text-muted-foreground"> · {move.reason}</span>
              </span>
              <span className="tabular-nums">
                {move.delta > 0 ? "+" : ""}
                {formatQty(move.delta)} {move.unit}
              </span>
            </li>
          ))}
        </ul>
      </section>
      <Modal open={draft != null} onOpenChange={(next) => !next && setDraft(null)} title={draft?.id ? "Ingrédient" : "Nouvel ingrédient"}>
        {draft ? (
          <form
            className="space-y-3"
            onSubmit={(event) => {
              event.preventDefault();
              void save();
            }}
          >
            <div>
              <Label htmlFor="stock-name">Nom</Label>
              <Input id="stock-name" className="mt-1" value={draft.name} onChange={(event) => setDraft({ ...draft, name: event.target.value })} />
            </div>
            <div>
              <Label htmlFor="stock-unit">Unité</Label>
              <Select
                id="stock-unit"
                className="mt-1"
                value={draft.unit}
                onChange={(event) => setDraft({ ...draft, unit: event.target.value as Unit })}
              >
                {UNITS.map((unit) => (
                  <option key={unit} value={unit}>
                    {unit}
                  </option>
                ))}
              </Select>
              <p className="mt-1 text-sm text-muted-foreground">Changer l'unité ne convertit pas la quantité.</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="stock-qty">Quantité</Label>
                <Input id="stock-qty" className="mt-1" inputMode="numeric" value={draft.quantity} onChange={(event) => setDraft({ ...draft, quantity: event.target.value })} />
              </div>
              <div>
                <Label htmlFor="stock-threshold">Seuil</Label>
                <Input id="stock-threshold" className="mt-1" inputMode="numeric" value={draft.threshold} onChange={(event) => setDraft({ ...draft, threshold: event.target.value })} />
              </div>
            </div>
            <Button type="submit" className="w-full" disabled={busy}>
              Enregistrer
            </Button>
          </form>
        ) : null}
      </Modal>
    </div>
  );
}
