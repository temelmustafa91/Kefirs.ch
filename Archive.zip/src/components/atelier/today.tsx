import { useEffect, useState, type ReactNode } from "react";
import { formatDay, formatEUR, formatQty, passageLabel } from "@/lib/comptoir/format";
import type { SeriesPoint } from "@/lib/comptoir/types";
import { SectionTitle, Stat, type DeskProps } from "@/components/atelier/bits";
import { OrderActions } from "@/components/atelier/orders";

export function TodayView(props: DeskProps) {
  const { data, pin, busy, run } = props;
  const active = data.orders
    .filter(
      (order) =>
        (order.status === "recue" || order.status === "preparation" || order.status === "prete") &&
        order.slotDate >= data.today,
    )
    .sort((a, b) => a.slotDate.localeCompare(b.slotDate) || a.slotTime.localeCompare(b.slotTime));
  const toPrep = data.orders
    .filter((order) => order.status === "recue" || order.status === "preparation")
    .reduce((sum, order) => sum + order.lines.reduce((inner, line) => inner + line.qty, 0), 0);
  const booked = data.series.reduce((sum, point) => sum + point.bookedCents, 0);
  const paid = data.series.reduce((sum, point) => sum + point.paidCents, 0);
  const alerts = data.stock.filter((item) => item.quantity <= item.threshold);

  return (
    <div className="space-y-8">
      <SectionTitle title="Aujourd'hui" detail={formatDay(data.today)} />
      <div className="grid gap-3 sm:grid-cols-2">
        <Stat label="À honorer" value={String(active.length)} />
        <Stat label="Bouteilles à préparer" value={String(toPrep)} />
        <Stat label="Engagé, 7 jours" value={formatEUR(booked)} />
        <Stat label="Encaissé, 7 jours" value={formatEUR(paid)} />
      </div>
      <section>
        <h3 className="font-display text-xl">Recettes engagées</h3>
        <p className="mt-1 text-sm text-muted-foreground">Commandes non annulées, par jour de livraison.</p>
        <ChartSlot series={data.series} />
      </section>
      <section>
        <h3 className="font-display text-xl">Tournée</h3>
        <ul className="mt-3 space-y-3">
          {active.length === 0 ? <li className="text-sm text-muted-foreground">Aucune livraison en attente.</li> : null}
          {active.slice(0, 6).map((order) => (
            <li key={order.id} className="lift rounded-3xl bg-card p-4">
              <div className="flex items-baseline justify-between gap-3">
                <p className="font-display text-xl">{order.code}</p>
                <p className="text-sm text-muted-foreground tabular-nums">
                  {formatDay(order.slotDate)} · {passageLabel(order.slotTime)}
                </p>
              </div>
              <p className="mt-1 text-sm text-muted-foreground">
                {order.lines.map((line) => `${line.qty} × ${line.name}`).join(", ")}
              </p>
              <div className="mt-3">
                <OrderActions order={order} pin={pin} busy={busy} run={run} />
              </div>
            </li>
          ))}
        </ul>
      </section>
      <section>
        <h3 className="font-display text-xl">Sous le seuil</h3>
        {alerts.length === 0 ? (
          <p className="mt-2 text-sm text-muted-foreground">Aucun ingrédient sous son seuil.</p>
        ) : (
          <ul className="mt-3 divide-y divide-border">
            {alerts.map((item) => (
              <li key={item.id} className="flex items-baseline justify-between gap-3 py-3 text-sm">
                <span>{item.name}</span>
                <span className="tabular-nums text-destructive">
                  {formatQty(item.quantity)} {item.unit}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function ChartSlot({ series }: { series: SeriesPoint[] }) {
  const [Chart, setChart] = useState<((props: { series: SeriesPoint[] }) => ReactNode) | null>(null);
  useEffect(() => {
    void import("@/components/atelier/revenue-chart").then((mod) => setChart(() => mod.RevenueChart));
  }, []);
  if (!Chart) return <div className="mt-4 h-40 rounded-xl bg-secondary" />;
  return (
    <div className="mt-4">
      <Chart series={series} />
    </div>
  );
}
