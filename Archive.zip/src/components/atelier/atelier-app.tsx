import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { BookOpen, Boxes, CalendarRange, ClipboardList, LayoutDashboard, Settings } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/field";
import { getLockState, loadAtelier } from "@/lib/comptoir/api";
import { messageOf } from "@/lib/comptoir/format";
import type { Section, Snapshot } from "@/lib/comptoir/types";
import { cn } from "@/lib/utils";
import { OrdersView } from "@/components/atelier/orders";
import { PlanningView } from "@/components/atelier/planning";
import { RecipesView } from "@/components/atelier/recipes";
import { SettingsView } from "@/components/atelier/settings";
import { StockView } from "@/components/atelier/stock";
import { TodayView } from "@/components/atelier/today";

const PIN_KEY = "comptoir-atelier-pin";

const NAV: { id: Section; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "jour", label: "Aujourd'hui", icon: LayoutDashboard },
  { id: "commandes", label: "Commandes", icon: ClipboardList },
  { id: "planning", label: "Planning", icon: CalendarRange },
  { id: "stocks", label: "Stocks", icon: Boxes },
  { id: "recettes", label: "Recettes", icon: BookOpen },
  { id: "application", label: "Application", icon: Settings },
];

export function AtelierApp({ section }: { section: Section }) {
  const navigate = useNavigate();
  const [phase, setPhase] = useState<"boot" | "lock" | "app">("boot");
  const [demo, setDemo] = useState(false);
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);
  const [pin, setPin] = useState("");
  const [data, setData] = useState<Snapshot | null>(null);
  const [busy, setBusy] = useState(false);
  const ticket = useRef(0);
  const busyRef = useRef(false);

  useEffect(() => {
    let cancel = false;
    const saved = sessionStorage.getItem(PIN_KEY) ?? "";
    getLockState()
      .then(async (state) => {
        if (cancel) return;
        setDemo(state.demoLock);
        if (/^\d{4}$/.test(saved)) {
          try {
            const next = await loadAtelier({ data: { pin: saved } });
            if (cancel) return;
            setPin(saved);
            setData(next);
            setPhase("app");
            return;
          } catch {
            sessionStorage.removeItem(PIN_KEY);
          }
        }
        if (!cancel) setPhase("lock");
      })
      .catch(() => {
        if (!cancel) setPhase("lock");
      });
    return () => {
      cancel = true;
    };
  }, []);

  useEffect(() => {
    if (phase !== "app" || !pin) return;
    const id = window.setInterval(() => {
      if (document.visibilityState !== "visible" || busyRef.current) return;
      const seen = ticket.current;
      void loadAtelier({ data: { pin } })
        .then((next) => {
          if (ticket.current === seen) setData(next);
        })
        .catch(() => undefined);
    }, 15000);
    return () => window.clearInterval(id);
  }, [phase, pin]);

  async function run(work: () => Promise<Snapshot>) {
    busyRef.current = true;
    setBusy(true);
    ticket.current += 1;
    try {
      const next = await work();
      ticket.current += 1;
      setData(next);
      return true;
    } catch (caught) {
      toast.error(messageOf(caught));
      return false;
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }

  function lock() {
    sessionStorage.removeItem(PIN_KEY);
    setPin("");
    setData(null);
    setPhase("lock");
    setCode("");
  }

  if (phase === "boot" || (phase === "app" && !data)) {
    return (
      <main className="grid min-h-dvh place-items-center px-6">
        <div>
          <p className="text-sm tracking-widest text-muted-foreground">FERMENSTATION</p>
          <h1 className="mt-2 font-display text-4xl tracking-tight">Atelier</h1>
        </div>
      </main>
    );
  }

  if (phase === "lock" || !data) {
    return (
      <main className="grid min-h-dvh place-items-center px-4">
        <div className="w-full max-w-sm">
          <p className="text-sm tracking-widest text-muted-foreground">FERMENSTATION</p>
          <h1 className="mt-2 font-display text-4xl tracking-tight">Atelier</h1>
          <p className="mt-3 text-sm text-muted-foreground">Stocks, recettes, planning et commandes.</p>
          <form
            className="mt-8 space-y-3"
            onSubmit={(event) => {
              event.preventDefault();
              if (!/^\d{4}$/.test(code)) {
                setError("Code à 4 chiffres.");
                return;
              }
              setPending(true);
              setError("");
              void loadAtelier({ data: { pin: code } })
                .then((next) => {
                  sessionStorage.setItem(PIN_KEY, code);
                  setPin(code);
                  setData(next);
                  setPhase("app");
                })
                .catch((caught: unknown) => setError(messageOf(caught)))
                .finally(() => setPending(false));
            }}
          >
            <Label htmlFor="pin">Code atelier</Label>
            <Input
              id="pin"
              inputMode="numeric"
              autoComplete="off"
              maxLength={4}
              value={code}
              onChange={(event) => setCode(event.target.value.replace(/\D/g, "").slice(0, 4))}
            />
            {error ? <p className="text-sm text-destructive">{error}</p> : null}
            {demo ? <p className="text-sm text-muted-foreground">Code de départ : 4820. À changer dans Application.</p> : null}
            <Button type="submit" className="w-full" disabled={pending}>
              Entrer
            </Button>
          </form>
          <Link to="/" className="mt-6 inline-flex h-11 items-center text-sm">
            Retour à la carte
          </Link>
        </div>
      </main>
    );
  }

  const desk = {
    data,
    pin,
    busy,
    run,
    onPin: (next: string) => {
      sessionStorage.setItem(PIN_KEY, next);
      setPin(next);
    },
  };

  return (
    <div>
      <header className="safe-top border-b border-border">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3">
          <div>
            <p className="text-sm tracking-widest text-muted-foreground">FERMENSTATION</p>
            <p className="font-display text-lg leading-tight">{data.shop.name}</p>
          </div>
          <div className="flex items-center gap-1">
            <Link to="/" className="inline-flex h-11 items-center rounded-lg px-3 text-sm hover:bg-secondary">
              La carte
            </Link>
            <Button variant="ghost" onClick={lock}>
              Verrouiller
            </Button>
          </div>
        </div>
      </header>
      <div className="mx-auto grid max-w-6xl gap-6 px-4 py-6 lg:grid-cols-[14rem_minmax(0,1fr)] lg:px-8">
        <nav className="scroll-x flex gap-2 lg:flex-col lg:overflow-visible">
          {NAV.map((item) => {
            const Icon = item.icon;
            const active = section === item.id;
            return (
              <button
                key={item.id}
                type="button"
                aria-current={active ? "page" : undefined}
                onClick={() => void navigate({ to: "/atelier", search: { section: item.id } })}
                className={cn(
                  "inline-flex h-11 shrink-0 items-center gap-2 rounded-lg px-3 text-sm font-medium",
                  active ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground",
                )}
              >
                <Icon className="size-4" aria-hidden="true" />
                {item.label}
              </button>
            );
          })}
        </nav>
        <div className="min-w-0">
          {section === "jour" ? <TodayView {...desk} /> : null}
          {section === "commandes" ? <OrdersView {...desk} /> : null}
          {section === "planning" ? <PlanningView {...desk} /> : null}
          {section === "stocks" ? <StockView {...desk} /> : null}
          {section === "recettes" ? <RecipesView {...desk} /> : null}
          {section === "application" ? <SettingsView {...desk} /> : null}
        </div>
      </div>
    </div>
  );
}
