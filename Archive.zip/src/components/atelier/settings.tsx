import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input, Label, Select, Textarea } from "@/components/ui/field";
import { saveShop } from "@/lib/comptoir/api";
import { hoursLabel } from "@/lib/comptoir/format";
import { SectionTitle, type DeskProps } from "@/components/atelier/bits";

const DAYS = [
  { id: 1, label: "Lundi" },
  { id: 2, label: "Mardi" },
  { id: 3, label: "Mercredi" },
  { id: 4, label: "Jeudi" },
  { id: 5, label: "Vendredi" },
  { id: 6, label: "Samedi" },
  { id: 0, label: "Dimanche" },
];

export function SettingsView({ data, pin, busy, run, onPin }: DeskProps) {
  const shop = data.shop;
  const [name, setName] = useState(shop.name);
  const [tagline, setTagline] = useState(shop.tagline);
  const [announcement, setAnnouncement] = useState(shop.announcement);
  const [address, setAddress] = useState(shop.address);
  const [openTime, setOpenTime] = useState(shop.openTime);
  const [closeTime, setCloseTime] = useState(shop.closeTime);
  const [evening, setEvening] = useState(Boolean(shop.eveningOpen && shop.eveningClose));
  const [eveningOpen, setEveningOpen] = useState(shop.eveningOpen ?? "18:00");
  const [eveningClose, setEveningClose] = useState(shop.eveningClose ?? "20:30");
  const [slotMinutes, setSlotMinutes] = useState(shop.slotMinutes);
  const [slotCapacity, setSlotCapacity] = useState(String(shop.slotCapacity));
  const [openDays, setOpenDays] = useState(DAYS.map((day) => day.id).filter((day) => !shop.closedDows.includes(day)));
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");

  const preview = hoursLabel({
    openTime,
    closeTime,
    eveningOpen: evening ? eveningOpen : null,
    eveningClose: evening ? eveningClose : null,
    slotMinutes,
    closedDows: DAYS.map((day) => day.id).filter((day) => !openDays.includes(day)),
  });

  async function save() {
    if (newPin !== confirmPin) {
      toast.error("Les codes ne correspondent pas.");
      return;
    }
    const capacity = Number(slotCapacity);
    if (!Number.isInteger(capacity)) {
      toast.error("Capacité invalide.");
      return;
    }
    const minutes = slotMinutes === 15 || slotMinutes === 60 ? slotMinutes : 30;
    try {
      const ok = await run(() =>
        saveShop({
          data: {
            pin,
            name,
            tagline,
            announcement,
            address,
            openTime,
            closeTime,
            eveningOpen: evening ? eveningOpen : "",
            eveningClose: evening ? eveningClose : "",
            slotMinutes: minutes,
            slotCapacity: capacity,
            closedDows: DAYS.map((day) => day.id).filter((day) => !openDays.includes(day)),
            newPin,
          },
        }),
      );
      if (!ok) return;
      if (newPin) onPin(newPin);
      setNewPin("");
      setConfirmPin("");
      toast.success("Application mise à jour");
    } catch {
      /* toasted */
    }
  }

  return (
    <form
      className="space-y-4"
      onSubmit={(event) => {
        event.preventDefault();
        void save();
      }}
    >
      <SectionTitle title="Application" detail="Ce que voient les clients, et le code de l'atelier" />
      <p className="text-sm text-muted-foreground">
        FermenStation est la seule porte de commande. Le nom, les horaires et l'annonce se règlent ici.
      </p>
      {data.shop.demoLock ? (
        <p className="text-sm text-warn">Le code de départ 4820 est encore actif.</p>
      ) : null}
      <Field label="Nom de la station" value={name} onChange={setName} />
      <Field label="Phrase" value={tagline} onChange={setTagline} />
      <div>
        <Label htmlFor="announcement">Annonce</Label>
        <Textarea id="announcement" className="mt-1" value={announcement} onChange={(event) => setAnnouncement(event.target.value)} />
      </div>
      <Field label="Adresse" value={address} onChange={setAddress} />
      <div className="grid grid-cols-2 gap-3">
        <TimeField label="Ouverture" value={openTime} onChange={setOpenTime} />
        <TimeField label="Fermeture" value={closeTime} onChange={setCloseTime} />
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={evening}
        onClick={() => setEvening((value) => !value)}
        className="h-11 rounded-lg bg-secondary px-4 text-sm"
      >
        {evening ? "Second service actif" : "Ajouter un second service"}
      </button>
      {evening ? (
        <div className="grid grid-cols-2 gap-3">
          <TimeField label="Second service" value={eveningOpen} onChange={setEveningOpen} />
          <TimeField label="Fin" value={eveningClose} onChange={setEveningClose} />
        </div>
      ) : null}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label htmlFor="slot">Créneau</Label>
          <Select
            id="slot"
            className="mt-1"
            value={String(slotMinutes)}
            onChange={(event) => setSlotMinutes(Number(event.target.value))}
          >
            <option value="15">15 min</option>
            <option value="30">30 min</option>
            <option value="60">60 min</option>
          </Select>
        </div>
        <div>
          <Label htmlFor="capacity">Bouteilles par passage</Label>
          <Input id="capacity" className="mt-1" inputMode="numeric" value={slotCapacity} onChange={(event) => setSlotCapacity(event.target.value)} />
        </div>
      </div>
      <fieldset>
        <legend className="text-sm font-medium">Jours d'ouverture</legend>
        <div className="mt-2 grid grid-cols-2 gap-2">
          {DAYS.map((day) => {
            const checked = openDays.includes(day.id);
            return (
              <label key={day.id} className="flex h-11 items-center gap-2 rounded-lg bg-secondary px-3 text-sm">
                <input
                  type="checkbox"
                  checked={checked}
                  onChange={() =>
                    setOpenDays((current) => (checked ? current.filter((id) => id !== day.id) : [...current, day.id]))
                  }
                />
                {day.label}
              </label>
            );
          })}
        </div>
      </fieldset>
      <p className="text-sm text-muted-foreground">Les clients verront : {preview}</p>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label htmlFor="new-pin">Nouveau code</Label>
          <Input id="new-pin" className="mt-1" inputMode="numeric" maxLength={4} value={newPin} onChange={(event) => setNewPin(event.target.value)} />
        </div>
        <div>
          <Label htmlFor="confirm-pin">Confirmer</Label>
          <Input id="confirm-pin" className="mt-1" inputMode="numeric" maxLength={4} value={confirmPin} onChange={(event) => setConfirmPin(event.target.value)} />
        </div>
      </div>
      <Button type="submit" disabled={busy}>
        Enregistrer
      </Button>
    </form>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  const id = label.replace(/\s+/g, "-").toLowerCase();
  return (
    <div>
      <Label htmlFor={id}>{label}</Label>
      <Input id={id} className="mt-1" value={value} onChange={(event) => onChange(event.target.value)} />
    </div>
  );
}

function TimeField({ label, value, onChange }: { label: string; value: string; onChange: (value: string) => void }) {
  const id = label.replace(/\s+/g, "-").toLowerCase();
  return (
    <div>
      <Label htmlFor={id}>{label}</Label>
      <Input id={id} className="mt-1" type="time" value={value} onChange={(event) => onChange(event.target.value)} />
    </div>
  );
}
