import { useState } from "react";
import { StatusPill } from "@/components/status-pill";
import { Button } from "@/components/ui/button";
import { setOrderStatus } from "@/lib/comptoir/api";
import { formatDay, formatEUR } from "@/lib/comptoir/format";
import type { AtelierOrder, Status } from "@/lib/comptoir/types";
import { cn } from "@/lib/utils";
import { SectionTitle, type DeskProps } from "@/components/atelier/bits";

const FILTERS: { id: "toutes" | Status; label: string }[] = [
  { id: "toutes", label: "Toutes" },
  { id: "recue", label: "Commandées" },
  { id: "preparation", label: "En préparation" },
  { id: "prete", label: "En livraison" },
  { id: "retiree", label: "Livrées" },
  { id: "annulee", label: "Annulées" },
];

export function nextStep(status: Status): { status: Status; label: string } | null {
  if (status === "recue") return { status: "preparation", label: "Lancer la préparation" };
  if (status === "preparation") return { status: "prete", label: "Passer en livraison" };
  if (status === "prete") return { status: "retiree", label: "Marquer livrée" };
  return null;
}

export function OrderActions({
  order,
  pin,
  busy,
  run,
}: {
  order: AtelierOrder;
  pin: string;
  busy: boolean;
  run: DeskProps["run"];
}) {
  const [armed, setArmed] = useState(false);
  const next = nextStep(order.status);
  return (
    <div className="flex flex-wrap gap-2">
      {next ? (
        <Button
          disabled={busy}
          onClick={() => void run(() => setOrderStatus({ data: { pin, id: order.id, status: next.status } }))}
        >
          {next.label}
        </Button>
      ) : null}
      {order.status !== "retiree" && order.status !== "annulee" ? (
        armed ? (
          <Button
            variant="outline"
            disabled={busy}
            onClick={() => void run(() => setOrderStatus({ data: { pin, id: order.id, status: "annulee" } }))}
          >
            Confirmer l'annulation
          </Button>
        ) : (
          <Button variant="ghost" disabled={busy} onClick={() => setArmed(true)}>
            Annuler
          </Button>
        )
      ) : null}
    </div>
  );
}

export function OrdersView({ data, pin, busy, run }: DeskProps) {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["id"]>("toutes");
  const [query, setQuery] = useState("");
  const orders = data.orders.filter((order) => {
    if (filter !== "toutes" && order.status !== filter) return false;
    if (query && !order.code.toLowerCase().includes(query.trim().toLowerCase())) return false;
    return true;
  });

  return (
    <div>
      <SectionTitle title="Commandes" detail="Le code tient lieu de ticket" />
      <input
        value={query}
        onChange={(event) => setQuery(event.target.value.toUpperCase())}
        placeholder="Rechercher un code"
        aria-label="Rechercher un code"
        className="mt-4 h-11 w-full rounded-lg border border-border bg-card px-3 text-base uppercase outline-none focus-visible:ring-2 focus-visible:ring-ring"
      />
      <div className="scroll-x mt-3 flex gap-2">
        {FILTERS.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setFilter(item.id)}
            className={cn(
              "h-11 shrink-0 rounded-full px-4 text-sm",
              filter === item.id ? "bg-primary text-primary-foreground" : "bg-secondary",
            )}
          >
            {item.label}
          </button>
        ))}
      </div>
      <ul className="mt-4 space-y-3">
        {orders.length === 0 ? <li className="text-sm text-muted-foreground">Aucune commande.</li> : null}
        {orders.map((order) => (
          <li key={order.id} className="lift rounded-3xl bg-card p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-display text-xl">{order.code}</p>
                <p className="text-sm text-muted-foreground">
                  {formatDay(order.slotDate)} · <span className="tabular-nums">{order.slotTime}</span>
                  {order.createdLabel ? ` · ${order.createdLabel}` : ""}
                </p>
              </div>
              <StatusPill status={order.status} />
            </div>
            <ul className="mt-3 space-y-1 text-sm">
              {order.lines.map((line, index) => (
                <li key={`${line.name}-${index}`} className="flex justify-between gap-3">
                  <span>
                    {line.qty} × {line.name}
                  </span>
                  <span className="tabular-nums">{formatEUR(line.qty * line.unitCents)}</span>
                </li>
              ))}
            </ul>
            {order.notes ? <p className="mt-2 text-sm text-muted-foreground">{order.notes}</p> : null}
            <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
              <p className="font-medium tabular-nums">{formatEUR(order.totalCents)}</p>
              <OrderActions order={order} pin={pin} busy={busy} run={run} />
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
