import { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { setClosure } from "@/lib/comptoir/api";
import { addDays, dowOf, formatDay, formatIso, slotTimes, utcDate, weekStart } from "@/lib/comptoir/format";
import type { AtelierOrder } from "@/lib/comptoir/types";
import { cn } from "@/lib/utils";
import { SectionTitle, type DeskProps } from "@/components/atelier/bits";
import { OrderActions } from "@/components/atelier/orders";

export function PlanningView(props: DeskProps) {
  const { data, pin, busy, run } = props;
  const [anchor, setAnchor] = useState(data.today);
  const [selected, setSelected] = useState(data.today);
  const start = weekStart(anchor);
  const days = Array.from({ length: 7 }, (_, index) => formatIso(addDays(utcDate(start), index)));
  const closedWeekday = data.shop.closedDows.includes(dowOf(selected));
  const closedDate = data.closures.includes(selected);
  const closed = closedWeekday || closedDate;
  const times = slotTimes(data.shop);
  const dayOrders = data.orders
    .filter((order) => order.slotDate === selected && order.status !== "annulee")
    .sort((a, b) => a.slotTime.localeCompare(b.slotTime));
  const production = productionFor(
    data.orders.filter((order) => order.slotDate === selected && (order.status === "recue" || order.status === "preparation")),
  );

  return (
    <div>
      <div className="flex items-end justify-between gap-3">
        <SectionTitle title="Planning" detail="Capacité par passage" />
        <div className="flex gap-1">
          <Button
            variant="outline"
            size="icon"
            aria-label="Semaine précédente"
            onClick={() => setAnchor(formatIso(addDays(utcDate(start), -7)))}
          >
            <ChevronLeft className="size-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            aria-label="Semaine suivante"
            onClick={() => setAnchor(formatIso(addDays(utcDate(start), 7)))}
          >
            <ChevronRight className="size-4" />
          </Button>
        </div>
      </div>
      <div className="mt-4 grid grid-cols-7 gap-1">
        {days.map((date) => {
          const dayClosed = data.shop.closedDows.includes(dowOf(date)) || data.closures.includes(date);
          const count = data.orders.filter((order) => order.slotDate === date && order.status !== "annulee").length;
          return (
            <button
              key={date}
              type="button"
              onClick={() => setSelected(date)}
              className={cn(
                "flex h-14 flex-col items-center justify-center rounded-lg text-sm",
                selected === date ? "bg-primary text-primary-foreground" : "bg-secondary",
                dayClosed && selected !== date && "text-muted-foreground",
              )}
            >
              <span className="tabular-nums">{date.slice(8)}</span>
              <span className="text-xs">{count || (dayClosed ? "—" : "")}</span>
            </button>
          );
        })}
      </div>
      <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
        <h3 className="font-display text-xl capitalize">{formatDay(selected)}</h3>
        <Button
          variant="outline"
          disabled={busy || closedWeekday}
          onClick={() => void run(() => setClosure({ data: { pin, date: selected, closed: !closedDate } }))}
        >
          {closedDate ? "Rouvrir ce jour" : "Fermer ce jour"}
        </Button>
      </div>
      {closed ? (
        <p className="mt-3 text-sm text-muted-foreground">
          {closedWeekday ? "Jour habituellement fermé." : "Fermé aux nouvelles commandes. Celles déjà prises restent à préparer."}
        </p>
      ) : null}
      <ul className="mt-4 space-y-4">
        {times.map((time) => {
          const at = dayOrders.filter((order) => order.slotTime === time);
          const portions = at.reduce((sum, order) => sum + order.lines.reduce((inner, line) => inner + line.qty, 0), 0);
          const pct = Math.min(100, Math.round((portions / Math.max(1, data.shop.slotCapacity)) * 100));
          return (
            <li key={time}>
              <div className="flex items-baseline justify-between gap-3 text-sm">
                <span className="tabular-nums font-medium">{time}</span>
                <span className="tabular-nums text-muted-foreground">
                  {portions}/{data.shop.slotCapacity}
                </span>
              </div>
              <div className="mt-1 h-1 overflow-hidden rounded-full bg-secondary">
                <div className="h-full bg-foreground" style={{ width: `${pct}%` }} />
              </div>
              <ul className="mt-2 space-y-2">
                {at.map((order) => (
                  <li key={order.id} className="rounded-xl bg-card p-3">
                    <div className="flex items-baseline justify-between gap-3">
                      <p className="font-medium">{order.code}</p>
                      <p className="text-sm text-muted-foreground">
                        {order.lines.map((line) => `${line.qty} × ${line.name}`).join(", ")}
                      </p>
                    </div>
                    <div className="mt-2">
                      <OrderActions order={order} pin={pin} busy={busy} run={run} />
                    </div>
                  </li>
                ))}
              </ul>
            </li>
          );
        })}
      </ul>
      <section className="mt-8">
        <h3 className="font-display text-xl">À produire</h3>
        <p className="mt-1 text-sm text-muted-foreground">Ingrédients des commandes reçues ou en préparation.</p>
        {production.length === 0 ? (
          <p className="mt-3 text-sm text-muted-foreground">Rien à produire pour ce jour.</p>
        ) : (
          <ul className="mt-3 divide-y divide-border">
            {production.map((item) => (
              <li key={`${item.name}-${item.unit}`} className="flex justify-between gap-3 py-3 text-sm">
                <span>{item.name}</span>
                <span className="tabular-nums">
                  {item.quantity} {item.unit}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function productionFor(orders: AtelierOrder[]) {
  const map = new Map<string, { name: string; unit: string; quantity: number }>();
  for (const order of orders) {
    for (const use of order.stockUse) {
      const key = `${use.name}-${use.unit}`;
      const prev = map.get(key);
      if (prev) prev.quantity += use.quantity;
      else map.set(key, { ...use });
    }
  }
  return [...map.values()].sort((a, b) => b.quantity - a.quantity);
}
