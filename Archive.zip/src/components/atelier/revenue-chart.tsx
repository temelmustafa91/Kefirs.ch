import { useEffect, useRef, useState } from "react";
import { Bar, BarChart, Tooltip, XAxis, YAxis } from "recharts";
import { formatEUR } from "@/lib/comptoir/format";
import type { SeriesPoint } from "@/lib/comptoir/types";

export function RevenueChart({ series }: { series: SeriesPoint[] }) {
  const ref = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(0);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const update = () => setWidth(node.clientWidth);
    update();
    const observer = new ResizeObserver(update);
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  const data = series.map((point) => ({ ...point, euros: point.bookedCents / 100 }));

  return (
    <div ref={ref} className="h-40 w-full text-muted-foreground">
      {width > 0 ? (
        <BarChart width={width} height={160} data={data} barCategoryGap="28%">
          <XAxis dataKey="label" tickLine={false} axisLine={false} tick={{ fill: "currentColor", fontSize: 12 }} />
          <YAxis hide />
          <Tooltip
            cursor={{ fill: "color-mix(in oklab, currentColor 8%, transparent)" }}
            formatter={(value) => [formatEUR(Math.round(Number(value) * 100)), "Engagé"]}
            contentStyle={{
              background: "var(--color-card)",
              border: "1px solid var(--color-border)",
              borderRadius: 12,
              color: "var(--color-foreground)",
            }}
          />
          <Bar dataKey="euros" fill="var(--color-foreground)" radius={[6, 6, 0, 0]} maxBarSize={28} />
        </BarChart>
      ) : null}
    </div>
  );
}
