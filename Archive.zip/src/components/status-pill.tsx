import { STATUS_LABEL } from "@/lib/comptoir/format";
import type { Status } from "@/lib/comptoir/types";
import { cn } from "@/lib/utils";

const tone: Record<Status, string> = {
  recue: "bg-foreground",
  preparation: "bg-warn",
  prete: "bg-ok",
  retiree: "bg-muted-foreground",
  annulee: "bg-destructive",
};

export function StatusPill({ status }: { status: Status }) {
  return (
    <span className="inline-flex h-8 items-center gap-2 rounded-full bg-secondary px-3 text-sm">
      <span className={cn("size-1.5 rounded-full", tone[status])} />
      {STATUS_LABEL[status]}
    </span>
  );
}
