import { useEffect, useMemo, useState } from "react";
import { useNavigate, useRouter } from "@tanstack/react-router";
import { Clock, MapPin, Minus, Plus } from "lucide-react";
import { toast } from "sonner";
import { SiteHeader } from "@/components/site-header";
import { Button } from "@/components/ui/button";
import { Modal } from "@/components/ui/modal";
import { getSlots, placeOrder } from "@/lib/comptoir/api";
import { useCart } from "@/lib/comptoir/cart";
import { dishSrc, formatEUR, messageOf } from "@/lib/comptoir/format";
import type { MenuItem, Slot, SlotsData, StorefrontData } from "@/lib/comptoir/types";
import { cn } from "@/lib/utils";

export function Storefront({ data }: { data: StorefrontData }) {
  const router = useRouter();
  const navigate = useNavigate();
  const lines = useCart((state) => state.lines);
  const last = useCart((state) => state.last);
  const setQty = useCart((state) => state.setQty);
  const remember = useCart((state) => state.remember);
  const clear = useCart((state) => state.clear);
  const [open, setOpen] = useState(false);
  const [date, setDate] = useState(data.days[0]?.date ?? "");
  const [time, setTime] = useState("");
  const [empties, setEmpties] = useState(0);
  const [slots, setSlots] = useState<SlotsData | null>(null);
  const [pending, setPending] = useState(false);
  const [nonce, setNonce] = useState(0);

  useEffect(() => {
    void useCart.persist.rehydrate();
  }, []);

  useEffect(() => {
    if (!data.days.some((day) => day.date === date)) {
      setDate(data.days[0]?.date ?? "");
      setTime("");
    }
  }, [data.days, date]);

  useEffect(() => {
    if (!open || !date) return;
    let cancel = false;
    setSlots(null);
    getSlots({ data: date })
      .then((next) => {
        if (!cancel) setSlots(next);
      })
      .catch((error: unknown) => {
        if (!cancel) toast.error(messageOf(error));
      });
    return () => {
      cancel = true;
    };
  }, [open, date, nonce]);

  useEffect(() => {
    if (!open || !slots) return;
    const next = deliveryWindows(slots.slots, data.shop);
    if (!next.some((window) => window.time === time)) setTime(next[0]?.time ?? "");
  }, [open, slots, data.shop, time]);

  function apply(next: { recipeId: number; qty: number }[]) {
    clear();
    for (const line of next) {
      const item = data.menu.find((entry) => entry.id === line.recipeId);
      if (item && item.available > 0) setQty(item.id, Math.min(line.qty, item.available));
    }
  }

  const groups = useMemo(() => {
    const map = new Map<string, MenuItem[]>();
    for (const item of data.menu) {
      const bucket = map.get(item.category) ?? [];
      bucket.push(item);
      map.set(item.category, bucket);
    }
    return [...map.entries()];
  }, [data.menu]);
  const suggestion = useMemo(() => {
    if (last.length > 0) return last;
    return data.menu
      .filter((item) => item.available > 0)
      .slice(0, 3)
      .map((item) => ({ recipeId: item.id, qty: Math.min(2, item.available) }));
  }, [data.menu, last]);
  const detailed = lines
    .map((line) => {
      const item = data.menu.find((entry) => entry.id === line.recipeId);
      if (!item) return null;
      const qty = Math.min(line.qty, item.available);
      return qty > 0 ? { item, qty } : null;
    })
    .filter((line): line is { item: MenuItem; qty: number } => line != null);
  const portions = detailed.reduce((sum, line) => sum + line.qty, 0);
  const total = detailed.reduce((sum, line) => sum + line.qty * line.item.priceCents, 0);
  const windows = slots ? deliveryWindows(slots.slots, data.shop) : [];

  async function confirm() {
    if (!date || !time || detailed.length === 0) return;
    setPending(true);
    try {
      const order = await placeOrder({
        data: {
          slotDate: date,
          slotTime: time,
          notes: empties > 0 ? [`Reprise de ${empties} bouteilles`] : [],
          lines: detailed.map((line) => ({ recipeId: line.item.id, qty: line.qty })),
        },
      });
      remember(detailed.map((line) => ({ recipeId: line.item.id, qty: line.qty })));
      clear();
      setOpen(false);
      setEmpties(0);
      await router.invalidate();
      await navigate({ to: "/suivi", search: { code: order.code } });
    } catch (error) {
      toast.error(messageOf(error));
      setNonce((value) => value + 1);
      await router.invalidate();
    } finally {
      setPending(false);
    }
  }

  return (
    <div className={portions > 0 ? "pb-28" : ""}>
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-4 py-6">
        <img
          src="/brand/fermenstation.jpg"
          alt="Affiche FermenStation. Laissez le vide sidéral derrière vous. Découvrez la fermentation infinie."
          className="h-36 w-full rounded-2xl object-cover object-[center_42%] sm:h-44"
        />
        <p className="mt-6 text-sm tracking-widest text-muted-foreground">COMMANDE</p>
        <h1 className="mt-1 font-display text-4xl tracking-tight">{data.shop.name}</h1>
        <p className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
          <span className="inline-flex items-center gap-2">
            <MapPin className="size-4" aria-hidden="true" />
            {data.shop.address}
          </span>
          <span className="inline-flex items-center gap-2">
            <Clock className="size-4" aria-hidden="true" />
            {data.shop.hoursLabel}
          </span>
        </p>

        {suggestion.length > 0 ? (
          <button
            type="button"
            className="mt-6 w-full rounded-2xl bg-card p-4 text-left"
            onClick={() => apply(suggestion)}
          >
            <p className="text-sm text-muted-foreground">{last.length > 0 ? "Dernière commande" : "Pour démarrer"}</p>
            <p className="mt-1 font-display text-2xl tracking-tight">
              {last.length > 0 ? "Reprendre telle quelle" : "Une caisse mixte"}
            </p>
            <p className="mt-1 text-sm text-muted-foreground">{describe(suggestion, data.menu)}</p>
          </button>
        ) : null}

        {data.menu.length === 0 ? (
          <p className="mt-10 text-muted-foreground">Rien à commander pour le moment.</p>
        ) : (
          <div className="mt-8 space-y-8">
            {groups.map(([category, items]) => (
              <section key={category}>
                <h2 className="text-sm tracking-widest text-muted-foreground">{category.toUpperCase()}</h2>
                <ul className="mt-2 divide-y divide-border">
                  {items.map((item) => {
                    const qty = lines.find((line) => line.recipeId === item.id)?.qty ?? 0;
                    const src = dishSrc(item.image);
                    return (
                      <li key={item.id} className="flex items-center gap-3 py-3">
                        {src ? (
                          <img src={src} alt="" className="size-14 shrink-0 rounded-lg object-cover" />
                        ) : (
                          <span className="size-14 shrink-0 rounded-lg bg-secondary" />
                        )}
                        <div className="min-w-0 flex-1">
                          <p className="truncate font-medium">{item.name}</p>
                          <p className="text-sm text-muted-foreground tabular-nums">
                            {formatEUR(item.priceCents)}
                            {item.available === 0 ? " · épuisé" : item.available <= 4 ? ` · plus que ${item.available}` : ""}
                          </p>
                        </div>
                        <button
                          type="button"
                          className="hidden h-11 shrink-0 rounded-lg bg-secondary px-3 text-sm font-medium disabled:opacity-40 sm:inline"
                          disabled={item.available < 1}
                          onClick={() => setQty(item.id, Math.min(6, item.available))}
                        >
                          Caisse
                        </button>
                        <Stepper value={qty} max={item.available} onChange={(next) => setQty(item.id, next)} />
                      </li>
                    );
                  })}
                </ul>
              </section>
            ))}
          </div>
        )}
      </main>

      {portions > 0 ? (
        <div className="dock fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background">
          <div className="mx-auto flex max-w-3xl items-center justify-between gap-3 px-4 py-3">
            <div>
              <p className="text-sm text-muted-foreground">
                {portions} bouteille{portions > 1 ? "s" : ""}
              </p>
              <p className="font-medium tabular-nums">{formatEUR(total)}</p>
            </div>
            <Button onClick={() => setOpen(true)}>Commander</Button>
          </div>
        </div>
      ) : null}

      <Modal
        open={open}
        onOpenChange={setOpen}
        title="Passage"
        description="Un matin ou un après-midi. Les vides repartent avec la tournée."
      >
        <ul className="space-y-2 text-sm">
          {detailed.map((line) => (
            <li key={line.item.id} className="flex items-center justify-between gap-3">
              <span>
                {line.qty} × {line.item.name}
              </span>
              <span className="tabular-nums">{formatEUR(line.qty * line.item.priceCents)}</span>
            </li>
          ))}
        </ul>
        {portions < 6 ? <p className="mt-3 text-sm text-muted-foreground">Moins d'une caisse : la tournée passe quand même.</p> : null}
        {data.days.length === 0 ? (
          <p className="mt-4 text-sm text-muted-foreground">Aucune tournée ouverte pour le moment.</p>
        ) : (
          <>
            <div className="scroll-x mt-4 flex gap-2">
              {data.days.map((day) => (
                <button
                  key={day.date}
                  type="button"
                  onClick={() => {
                    setDate(day.date);
                    setTime("");
                  }}
                  className={cn(
                    "h-11 shrink-0 rounded-full px-4 text-sm",
                    date === day.date ? "bg-primary text-primary-foreground" : "bg-secondary",
                  )}
                >
                  {day.label}
                </button>
              ))}
            </div>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {slots == null ? (
                <p className="text-sm text-muted-foreground">Tournées…</p>
              ) : slots.closed || windows.length === 0 ? (
                <p className="text-sm text-muted-foreground">Plus de passage ce jour-là.</p>
              ) : (
                windows.map((window) => (
                  <button
                    key={window.time}
                    type="button"
                    onClick={() => setTime(window.time)}
                    className={cn(
                      "flex h-14 items-center justify-between rounded-lg px-3 text-left text-sm",
                      time === window.time ? "bg-primary text-primary-foreground" : "bg-secondary",
                    )}
                  >
                    <span>
                      <span className="block font-medium">{window.label}</span>
                      <span className="tabular-nums opacity-80">{window.detail}</span>
                    </span>
                    <span>{window.remaining}</span>
                  </button>
                ))
              )}
            </div>
          </>
        )}
        <div className="mt-4 flex items-center justify-between gap-3">
          <p className="text-sm">Vides à reprendre</p>
          <Stepper value={empties} max={24} onChange={setEmpties} minusLabel="Retirer une bouteille vide" plusLabel="Ajouter une bouteille vide" />
        </div>
        <div className="sticky bottom-0 -mx-4 mt-4 border-t border-border bg-background px-4 py-3">
          <Button className="w-full" disabled={pending || !time || detailed.length === 0} onClick={() => void confirm()}>
            {pending ? "Enregistrement…" : `Confirmer · ${formatEUR(total)}`}
          </Button>
        </div>
      </Modal>
    </div>
  );
}

function describe(lines: { recipeId: number; qty: number }[], menu: MenuItem[]): string {
  return lines
    .map((line) => {
      const item = menu.find((entry) => entry.id === line.recipeId);
      return item ? `${line.qty} ${item.name}` : null;
    })
    .filter((line): line is string => line != null)
    .join(" · ");
}

function deliveryWindows(
  slots: Slot[],
  shop: StorefrontData["shop"],
): { time: string; label: string; detail: string; remaining: number }[] {
  const morning = slots.find((slot) => slot.time < "15:00" && slot.remaining > 0);
  const afternoon = slots.find((slot) => slot.time >= "15:00" && slot.remaining > 0);
  const windows: { time: string; label: string; detail: string; remaining: number }[] = [];
  if (morning) {
    windows.push({
      time: morning.time,
      label: "Matin",
      detail: `${shop.openTime}–${shop.closeTime}`,
      remaining: morning.remaining,
    });
  }
  if (afternoon) {
    windows.push({
      time: afternoon.time,
      label: "Après-midi",
      detail: shop.eveningOpen && shop.eveningClose ? `${shop.eveningOpen}–${shop.eveningClose}` : afternoon.time,
      remaining: afternoon.remaining,
    });
  }
  return windows;
}

function Stepper({
  value,
  max,
  onChange,
  minusLabel = "Retirer une bouteille",
  plusLabel = "Ajouter une bouteille",
}: {
  value: number;
  max: number;
  onChange: (qty: number) => void;
  minusLabel?: string;
  plusLabel?: string;
}) {
  return (
    <div className="flex items-center">
      <button
        type="button"
        className="grid size-11 place-items-center rounded-lg bg-secondary disabled:opacity-40"
        aria-label={minusLabel}
        disabled={value <= 0}
        onClick={() => onChange(Math.max(0, value - 1))}
      >
        <Minus className="size-4" />
      </button>
      <span className="w-8 text-center tabular-nums">{value}</span>
      <button
        type="button"
        className="grid size-11 place-items-center rounded-lg bg-secondary disabled:opacity-40"
        aria-label={plusLabel}
        disabled={value >= max}
        onClick={() => onChange(Math.min(max, value + 1))}
      >
        <Plus className="size-4" />
      </button>
    </div>
  );
}
