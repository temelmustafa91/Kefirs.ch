import { Link } from "@tanstack/react-router";

export function SiteHeader() {
  return (
    <header className="safe-top border-b border-border">
      <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-4">
        <Link to="/" className="font-display text-xl tracking-tight sm:text-2xl">
          FermenStation
        </Link>
        <nav className="flex items-center gap-1 text-sm">
          <Link to="/suivi" search={{ code: "" }} className="inline-flex h-11 items-center rounded-lg px-3 hover:bg-secondary">
            Suivre
          </Link>
          <Link
            to="/atelier"
            search={{ section: "jour" }}
            className="inline-flex h-11 items-center rounded-lg px-3 hover:bg-secondary"
          >
            Atelier
          </Link>
        </nav>
      </div>
    </header>
  );
}
